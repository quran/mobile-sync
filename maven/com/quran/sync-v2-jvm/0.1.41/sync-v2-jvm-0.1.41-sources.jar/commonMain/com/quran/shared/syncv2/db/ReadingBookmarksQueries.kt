@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import app.cash.sqldelight.ExecutableQuery
import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class ReadingBookmarksQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> all(mapper: (
    local_id: Long,
    slot: Long,
    name: String?,
    location_type: String?,
    location_key: Long?,
    location_verse: Long?,
    mushaf_id: Long?,
    metadata: String?,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = Query(-871_678_188, arrayOf("reading_bookmark"), driver, "readingBookmarks.sq", "all", "SELECT reading_bookmark.local_id, reading_bookmark.slot, reading_bookmark.name, reading_bookmark.location_type, reading_bookmark.location_key, reading_bookmark.location_verse, reading_bookmark.mushaf_id, reading_bookmark.metadata, reading_bookmark.created_at, reading_bookmark.updated_at FROM reading_bookmark ORDER BY slot") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2),
      cursor.getString(3),
      cursor.getLong(4),
      cursor.getLong(5),
      cursor.getLong(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun all(): Query<Reading_bookmark> = all(::Reading_bookmark)

  public fun <T : Any> bySlot(slot: Long, mapper: (
    local_id: Long,
    slot: Long,
    name: String?,
    location_type: String?,
    location_key: Long?,
    location_verse: Long?,
    mushaf_id: Long?,
    metadata: String?,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = BySlotQuery(slot) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2),
      cursor.getString(3),
      cursor.getLong(4),
      cursor.getLong(5),
      cursor.getLong(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun bySlot(slot: Long): Query<Reading_bookmark> = bySlot(slot, ::Reading_bookmark)

  public fun lastInsertId(): ExecutableQuery<Long> = Query(-1_461_670_313, driver, "readingBookmarks.sq", "lastInsertId", "SELECT last_insert_rowid()") { cursor ->
    cursor.getLong(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun insert(
    slot: Long,
    name: String?,
    location_type: String?,
    location_key: Long?,
    location_verse: Long?,
    mushaf_id: Long?,
    metadata: String?,
    created_at: Long,
    updated_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-561_437_594, """INSERT INTO reading_bookmark(slot, name, location_type, location_key, location_verse, mushaf_id, metadata, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""", 9) {
          var parameterIndex = 0
          bindLong(parameterIndex++, slot)
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, location_type)
          bindLong(parameterIndex++, location_key)
          bindLong(parameterIndex++, location_verse)
          bindLong(parameterIndex++, mushaf_id)
          bindString(parameterIndex++, metadata)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
        }
    notifyQueries(-561_437_594) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertWithId(
    local_id: Long?,
    slot: Long,
    name: String?,
    location_type: String?,
    location_key: Long?,
    location_verse: Long?,
    mushaf_id: Long?,
    metadata: String?,
    created_at: Long,
    updated_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(575_491_207, """INSERT INTO reading_bookmark(local_id, slot, name, location_type, location_key, location_verse, mushaf_id, metadata, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", 10) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
          bindLong(parameterIndex++, slot)
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, location_type)
          bindLong(parameterIndex++, location_key)
          bindLong(parameterIndex++, location_verse)
          bindLong(parameterIndex++, mushaf_id)
          bindString(parameterIndex++, metadata)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
        }
    notifyQueries(575_491_207) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun update(
    slot: Long,
    name: String?,
    location_type: String?,
    location_key: Long?,
    location_verse: Long?,
    mushaf_id: Long?,
    metadata: String?,
    created_at: Long,
    updated_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-216_491_402, """UPDATE reading_bookmark SET slot = ?, name = ?, location_type = ?, location_key = ?, location_verse = ?, mushaf_id = ?, metadata = ?, created_at = ?, updated_at = ? WHERE local_id = ?""", 10) {
          var parameterIndex = 0
          bindLong(parameterIndex++, slot)
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, location_type)
          bindLong(parameterIndex++, location_key)
          bindLong(parameterIndex++, location_verse)
          bindLong(parameterIndex++, mushaf_id)
          bindString(parameterIndex++, metadata)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-216_491_402) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun park(local_id: Long): QueryResult<Long> {
    val result = driver.execute(-1_251_783_465, """UPDATE reading_bookmark SET slot = CASE WHEN local_id >= 0 THEN -2 * local_id - 1 ELSE 2 * local_id END WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-1_251_783_465) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun delete(local_id: Long): QueryResult<Long> {
    val result = driver.execute(-713_103_528, """DELETE FROM reading_bookmark WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-713_103_528) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  private inner class BySlotQuery<out T : Any>(
    public val slot: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-752_629_598, """SELECT reading_bookmark.local_id, reading_bookmark.slot, reading_bookmark.name, reading_bookmark.location_type, reading_bookmark.location_key, reading_bookmark.location_verse, reading_bookmark.mushaf_id, reading_bookmark.metadata, reading_bookmark.created_at, reading_bookmark.updated_at FROM reading_bookmark WHERE slot = ?""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, slot)
    }

    override fun toString(): String = "readingBookmarks.sq:bySlot"
  }
}
