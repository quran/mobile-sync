@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long
import kotlin.String

public data class Note(
  public val local_id: Long,
  public val body: String,
  public val created_at: Long,
  public val updated_at: Long,
  public val archived_at: Long?,
)
