@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long

public data class Note_range(
  public val note_local_id: Long,
  public val position: Long,
  public val start_sura: Long,
  public val start_ayah: Long,
  public val end_sura: Long,
  public val end_ayah: Long,
)
