@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db.syncv2

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.quran.shared.syncv2.db.CollectionsQueries
import com.quran.shared.syncv2.db.NotesQueries
import com.quran.shared.syncv2.db.ReadingBookmarksQueries
import com.quran.shared.syncv2.db.SessionsQueries
import com.quran.shared.syncv2.db.SyncV2Database
import com.quran.shared.syncv2.db.Sync_itemQueries
import com.quran.shared.syncv2.db.Sync_runQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<SyncV2Database>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = SyncV2DatabaseImpl.Schema

internal fun KClass<SyncV2Database>.newInstance(driver: SqlDriver): SyncV2Database = SyncV2DatabaseImpl(driver)

private class SyncV2DatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    SyncV2Database {
  override val collectionsQueries: CollectionsQueries = CollectionsQueries(driver)

  override val notesQueries: NotesQueries = NotesQueries(driver)

  override val readingBookmarksQueries: ReadingBookmarksQueries = ReadingBookmarksQueries(driver)

  override val sessionsQueries: SessionsQueries = SessionsQueries(driver)

  override val sync_itemQueries: Sync_itemQueries = Sync_itemQueries(driver)

  override val sync_runQueries: Sync_runQueries = Sync_runQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE collection(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  name TEXT NOT NULL,
          |  -- lower(trim(name)) like the server; NULL for Favorites so a user collection may share its name.
          |  name_key TEXT,
          |  is_default INTEGER NOT NULL DEFAULT 0,
          |  -- The server's isSystem (Favorites, highlights): app-facing lists hide these.
          |  is_system INTEGER NOT NULL DEFAULT 0,
          |  -- No rename or delete: system collections and the older apps' protected color collections (from GET data).
          |  is_read_only INTEGER NOT NULL DEFAULT 0,
          |  created_at INTEGER NOT NULL,
          |  updated_at INTEGER NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE collection_ayah(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  collection_local_id INTEGER NOT NULL REFERENCES collection(local_id) ON DELETE CASCADE,
          |  sura INTEGER NOT NULL,
          |  ayah INTEGER NOT NULL,
          |  created_at INTEGER NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE remote_ayah_bookmark(
          |  bookmark_id TEXT NOT NULL PRIMARY KEY,
          |  sura INTEGER NOT NULL,
          |  ayah INTEGER NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE note(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  body TEXT NOT NULL,
          |  created_at INTEGER NOT NULL,
          |  updated_at INTEGER NOT NULL,
          |  archived_at INTEGER
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE note_range(
          |  note_local_id INTEGER NOT NULL REFERENCES note(local_id) ON DELETE CASCADE,
          |  position INTEGER NOT NULL,
          |  start_sura INTEGER NOT NULL,
          |  start_ayah INTEGER NOT NULL,
          |  end_sura INTEGER NOT NULL,
          |  end_ayah INTEGER NOT NULL,
          |  PRIMARY KEY (note_local_id, position)
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE reading_bookmark(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  slot INTEGER NOT NULL,
          |  name TEXT,
          |  location_type TEXT,
          |  location_key INTEGER,
          |  location_verse INTEGER,
          |  mushaf_id INTEGER,
          |  -- The server's opaque metadata as JSON, without the `source` the server manages.
          |  metadata TEXT,
          |  created_at INTEGER NOT NULL,
          |  updated_at INTEGER NOT NULL,
          |  CHECK (
          |    (location_type IS NULL AND location_key IS NULL AND location_verse IS NULL AND mushaf_id IS NULL) OR
          |    (location_type IS NOT NULL AND location_key IS NOT NULL)
          |  )
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE reading_session(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  sura INTEGER NOT NULL,
          |  ayah INTEGER NOT NULL,
          |  created_at INTEGER NOT NULL,
          |  updated_at INTEGER NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE sync_item(
          |  resource TEXT NOT NULL,
          |  local_id INTEGER NOT NULL,
          |  remote_id TEXT,
          |  base_json TEXT,
          |  held_reason TEXT,
          |  held_json TEXT,
          |  held_until INTEGER,
          |  PRIMARY KEY (resource, local_id)
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE sync_meta(
          |  key TEXT NOT NULL PRIMARY KEY,
          |  value TEXT NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE sync_run(
          |  id INTEGER PRIMARY KEY AUTOINCREMENT,
          |  started_at INTEGER NOT NULL,
          |  ended_at INTEGER NOT NULL,
          |  triggered_by TEXT NOT NULL,
          |  result TEXT NOT NULL,
          |  attempts INTEGER NOT NULL,
          |  pushed INTEGER NOT NULL,
          |  pulled INTEGER NOT NULL,
          |  held INTEGER NOT NULL,
          |  error_kind TEXT,
          |  error_http_status INTEGER,
          |  error_server_code TEXT,
          |  error_message TEXT
          |)
          """.trimMargin(), 0)
      driver.execute(null, "CREATE UNIQUE INDEX collection_name_key_idx ON collection(name_key)", 0)
      driver.execute(null, "CREATE UNIQUE INDEX collection_ayah_idx ON collection_ayah(collection_local_id, sura, ayah)", 0)
      driver.execute(null, "CREATE INDEX collection_ayah_verse_idx ON collection_ayah(sura, ayah)", 0)
      driver.execute(null, "CREATE INDEX note_created_idx ON note(created_at)", 0)
      driver.execute(null, "CREATE INDEX note_range_start_idx ON note_range(start_sura, start_ayah)", 0)
      driver.execute(null, "CREATE UNIQUE INDEX reading_bookmark_slot_idx ON reading_bookmark(slot)", 0)
      driver.execute(null, "CREATE UNIQUE INDEX reading_session_verse_idx ON reading_session(sura, ayah)", 0)
      driver.execute(null, "CREATE UNIQUE INDEX sync_item_remote_idx ON sync_item(resource, remote_id)", 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
