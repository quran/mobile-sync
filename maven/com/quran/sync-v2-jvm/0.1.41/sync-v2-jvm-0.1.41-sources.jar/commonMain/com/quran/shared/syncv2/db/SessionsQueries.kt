@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import app.cash.sqldelight.ExecutableQuery
import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SessionsQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> all(mapper: (
    local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = Query(-1_880_345_656, arrayOf("reading_session"), driver, "sessions.sq", "all", "SELECT reading_session.local_id, reading_session.sura, reading_session.ayah, reading_session.created_at, reading_session.updated_at FROM reading_session ORDER BY updated_at DESC, sura, ayah") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun all(): Query<Reading_session> = all(::Reading_session)

  public fun <T : Any> at(
    sura: Long,
    ayah: Long,
    mapper: (
      local_id: Long,
      sura: Long,
      ayah: Long,
      created_at: Long,
      updated_at: Long,
    ) -> T,
  ): Query<T> = AtQuery(sura, ayah) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun at(sura: Long, ayah: Long): Query<Reading_session> = at(sura, ayah, ::Reading_session)

  public fun <T : Any> `get`(local_id: Long, mapper: (
    local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = GetQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun `get`(local_id: Long): Query<Reading_session> = get(local_id, ::Reading_session)

  public fun lastInsertId(): ExecutableQuery<Long> = Query(74_826_787, driver, "sessions.sq", "lastInsertId", "SELECT last_insert_rowid()") { cursor ->
    cursor.getLong(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun insert(
    sura: Long,
    ayah: Long,
    created_at: Long,
    updated_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(2_112_193_330, """INSERT INTO reading_session(sura, ayah, created_at, updated_at) VALUES (?, ?, ?, ?)""", 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
        }
    notifyQueries(2_112_193_330) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertWithId(
    local_id: Long?,
    sura: Long,
    ayah: Long,
    created_at: Long,
    updated_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(2_111_988_307, """INSERT INTO reading_session(local_id, sura, ayah, created_at, updated_at) VALUES (?, ?, ?, ?, ?)""", 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
        }
    notifyQueries(2_111_988_307) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun update(
    sura: Long,
    ayah: Long,
    updated_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-1_837_827_774, """UPDATE reading_session SET sura = ?, ayah = ?, updated_at = ? WHERE local_id = ?""", 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-1_837_827_774) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun park(local_id: Long): QueryResult<Long> {
    val result = driver.execute(1_839_263_395, """UPDATE reading_session SET ayah = CASE WHEN local_id >= 0 THEN -2 * local_id - 1 ELSE 2 * local_id END WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_839_263_395) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun delete(local_id: Long): QueryResult<Long> {
    val result = driver.execute(1_960_527_396, """DELETE FROM reading_session WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_960_527_396) { emit ->
      emit("reading_session")
    }
    return result
  }

  private inner class AtQuery<out T : Any>(
    public val sura: Long,
    public val ayah: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_169_034_964, """SELECT reading_session.local_id, reading_session.sura, reading_session.ayah, reading_session.created_at, reading_session.updated_at FROM reading_session WHERE sura = ? AND ayah = ?""", mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, sura)
      bindLong(parameterIndex++, ayah)
    }

    override fun toString(): String = "sessions.sq:at"
  }

  private inner class GetQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_880_340_099, """SELECT reading_session.local_id, reading_session.sura, reading_session.ayah, reading_session.created_at, reading_session.updated_at FROM reading_session WHERE local_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "sessions.sq:get"
  }
}
