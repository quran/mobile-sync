@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.String

public data class Sync_meta(
  public val key: String,
  public val value_: String,
)
