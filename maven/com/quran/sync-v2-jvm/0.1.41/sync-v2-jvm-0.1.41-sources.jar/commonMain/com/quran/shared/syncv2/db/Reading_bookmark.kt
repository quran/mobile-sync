@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long
import kotlin.String

public data class Reading_bookmark(
  public val local_id: Long,
  public val slot: Long,
  public val name: String?,
  public val location_type: String?,
  public val location_key: Long?,
  public val location_verse: Long?,
  public val mushaf_id: Long?,
  public val metadata: String?,
  public val created_at: Long,
  public val updated_at: Long,
)
