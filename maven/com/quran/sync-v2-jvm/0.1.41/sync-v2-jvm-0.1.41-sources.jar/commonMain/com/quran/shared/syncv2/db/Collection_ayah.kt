@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long

public data class Collection_ayah(
  public val local_id: Long,
  public val collection_local_id: Long,
  public val sura: Long,
  public val ayah: Long,
  public val created_at: Long,
)
