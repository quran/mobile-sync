@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import app.cash.sqldelight.ExecutableQuery
import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class CollectionsQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> collectionsAll(mapper: (
    local_id: Long,
    name: String,
    name_key: String?,
    is_default: Long,
    is_system: Long,
    is_read_only: Long,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = Query(-1_487_692_895, arrayOf("collection"), driver, "collections.sq", "collectionsAll", "SELECT collection.local_id, collection.name, collection.name_key, collection.is_default, collection.is_system, collection.is_read_only, collection.created_at, collection.updated_at FROM collection ORDER BY local_id") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2),
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!
    )
  }

  public fun collectionsAll(): Query<Collection> = collectionsAll(::Collection)

  public fun <T : Any> collectionsNewestFirst(mapper: (
    local_id: Long,
    name: String,
    name_key: String?,
    is_default: Long,
    is_system: Long,
    is_read_only: Long,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = Query(476_022_890, arrayOf("collection"), driver, "collections.sq", "collectionsNewestFirst", "SELECT collection.local_id, collection.name, collection.name_key, collection.is_default, collection.is_system, collection.is_read_only, collection.created_at, collection.updated_at FROM collection ORDER BY created_at DESC, local_id DESC") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2),
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!
    )
  }

  public fun collectionsNewestFirst(): Query<Collection> = collectionsNewestFirst(::Collection)

  public fun <T : Any> collectionGet(local_id: Long, mapper: (
    local_id: Long,
    name: String,
    name_key: String?,
    is_default: Long,
    is_system: Long,
    is_read_only: Long,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = CollectionGetQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2),
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!
    )
  }

  public fun collectionGet(local_id: Long): Query<Collection> = collectionGet(local_id, ::Collection)

  public fun <T : Any> collectionByKey(name_key: String?, mapper: (
    local_id: Long,
    name: String,
    name_key: String?,
    is_default: Long,
    is_system: Long,
    is_read_only: Long,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = CollectionByKeyQuery(name_key) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2),
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!
    )
  }

  public fun collectionByKey(name_key: String?): Query<Collection> = collectionByKey(name_key, ::Collection)

  public fun <T : Any> collectionDefault(mapper: (
    local_id: Long,
    name: String,
    name_key: String?,
    is_default: Long,
    is_system: Long,
    is_read_only: Long,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = Query(-2_124_578_354, arrayOf("collection"), driver, "collections.sq", "collectionDefault", "SELECT collection.local_id, collection.name, collection.name_key, collection.is_default, collection.is_system, collection.is_read_only, collection.created_at, collection.updated_at FROM collection WHERE is_default = 1") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2),
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!
    )
  }

  public fun collectionDefault(): Query<Collection> = collectionDefault(::Collection)

  public fun <T : Any> collectionAyahsAll(mapper: (
    local_id: Long,
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
  ) -> T): Query<T> = Query(-1_937_460_960, arrayOf("collection_ayah"), driver, "collections.sq", "collectionAyahsAll", "SELECT collection_ayah.local_id, collection_ayah.collection_local_id, collection_ayah.sura, collection_ayah.ayah, collection_ayah.created_at FROM collection_ayah ORDER BY local_id") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun collectionAyahsAll(): Query<Collection_ayah> = collectionAyahsAll(::Collection_ayah)

  public fun <T : Any> collectionAyahGet(local_id: Long, mapper: (
    local_id: Long,
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
  ) -> T): Query<T> = CollectionAyahGetQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun collectionAyahGet(local_id: Long): Query<Collection_ayah> = collectionAyahGet(local_id, ::Collection_ayah)

  public fun <T : Any> collectionAyahsIn(collection_local_id: Long, mapper: (
    local_id: Long,
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
  ) -> T): Query<T> = CollectionAyahsInQuery(collection_local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun collectionAyahsIn(collection_local_id: Long): Query<Collection_ayah> = collectionAyahsIn(collection_local_id, ::Collection_ayah)

  public fun <T : Any> collectionAyahsAt(
    sura: Long,
    ayah: Long,
    mapper: (
      local_id: Long,
      collection_local_id: Long,
      sura: Long,
      ayah: Long,
      created_at: Long,
    ) -> T,
  ): Query<T> = CollectionAyahsAtQuery(sura, ayah) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun collectionAyahsAt(sura: Long, ayah: Long): Query<Collection_ayah> = collectionAyahsAt(sura, ayah, ::Collection_ayah)

  public fun <T : Any> collectionAyahFind(
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
    mapper: (
      local_id: Long,
      collection_local_id: Long,
      sura: Long,
      ayah: Long,
      created_at: Long,
    ) -> T,
  ): Query<T> = CollectionAyahFindQuery(collection_local_id, sura, ayah) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun collectionAyahFind(
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
  ): Query<Collection_ayah> = collectionAyahFind(collection_local_id, sura, ayah, ::Collection_ayah)

  public fun <T : Any> highlightAyahs(mapper: (
    local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
    name_key: String?,
  ) -> T): Query<T> = Query(-1_310_467_723, arrayOf("collection_ayah", "collection"), driver, "collections.sq", "highlightAyahs", """
  |SELECT collection_ayah.local_id, collection_ayah.sura, collection_ayah.ayah, collection_ayah.created_at, collection.name_key
  |FROM collection_ayah JOIN collection ON collection.local_id = collection_ayah.collection_local_id
  |WHERE collection.name_key LIKE 'system:highlights:%'
  |ORDER BY collection_ayah.sura, collection_ayah.ayah
  """.trimMargin()) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getString(4)
    )
  }

  public fun highlightAyahs(): Query<HighlightAyahs> = highlightAyahs(::HighlightAyahs)

  public fun <T : Any> remoteAyahBookmarkGet(bookmark_id: String, mapper: (
    bookmark_id: String,
    sura: Long,
    ayah: Long,
  ) -> T): Query<T> = RemoteAyahBookmarkGetQuery(bookmark_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!
    )
  }

  public fun remoteAyahBookmarkGet(bookmark_id: String): Query<Remote_ayah_bookmark> = remoteAyahBookmarkGet(bookmark_id, ::Remote_ayah_bookmark)

  public fun lastInsertId(): ExecutableQuery<Long> = Query(-1_850_927_233, driver, "collections.sq", "lastInsertId", "SELECT last_insert_rowid()") { cursor ->
    cursor.getLong(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionInsert(
    name: String,
    name_key: String?,
    is_default: Long,
    is_system: Long,
    is_read_only: Long,
    created_at: Long,
    updated_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-609_422_964, """INSERT INTO collection(name, name_key, is_default, is_system, is_read_only, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)""", 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, name_key)
          bindLong(parameterIndex++, is_default)
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, is_read_only)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
        }
    notifyQueries(-609_422_964) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionInsertWithId(
    local_id: Long?,
    name: String,
    name_key: String?,
    is_default: Long,
    is_system: Long,
    is_read_only: Long,
    created_at: Long,
    updated_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-1_328_536_275, """INSERT INTO collection(local_id, name, name_key, is_default, is_system, is_read_only, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", 8) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, name_key)
          bindLong(parameterIndex++, is_default)
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, is_read_only)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
        }
    notifyQueries(-1_328_536_275) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionUpdate(
    name: String,
    name_key: String?,
    is_system: Long,
    is_read_only: Long,
    updated_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-264_476_772, """UPDATE collection SET name = ?, name_key = ?, is_system = ?, is_read_only = ?, updated_at = ? WHERE local_id = ?""", 6) {
          var parameterIndex = 0
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, name_key)
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, is_read_only)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-264_476_772) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionPark(name_key: String?, local_id: Long): QueryResult<Long> {
    val result = driver.execute(-1_488_704_643, """UPDATE collection SET name_key = ? WHERE local_id = ?""", 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, name_key)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-1_488_704_643) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionDelete(local_id: Long): QueryResult<Long> {
    val result = driver.execute(-761_088_898, """DELETE FROM collection WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-761_088_898) { emit ->
      emit("collection")
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionsDeleteAll(): QueryResult<Long> {
    val result = driver.execute(-531_711_498, """DELETE FROM collection""", 0)
    notifyQueries(-531_711_498) { emit ->
      emit("collection")
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionAyahInsert(
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(955_163_467, """INSERT INTO collection_ayah(collection_local_id, sura, ayah, created_at) VALUES (?, ?, ?, ?)""", 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, collection_local_id)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, created_at)
        }
    notifyQueries(955_163_467) { emit ->
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionAyahInsertWithId(
    local_id: Long?,
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_002_412, """INSERT INTO collection_ayah(local_id, collection_local_id, sura, ayah, created_at) VALUES (?, ?, ?, ?, ?)""", 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
          bindLong(parameterIndex++, collection_local_id)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, created_at)
        }
    notifyQueries(1_002_412) { emit ->
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionAyahUpdate(
    collection_local_id: Long,
    sura: Long,
    ayah: Long,
    created_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_300_109_659, """UPDATE collection_ayah SET collection_local_id = ?, sura = ?, ayah = ?, created_at = ? WHERE local_id = ?""", 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, collection_local_id)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_300_109_659) { emit ->
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionAyahPark(local_id: Long): QueryResult<Long> {
    val result = driver.execute(-1_938_472_708, """UPDATE collection_ayah SET ayah = CASE WHEN local_id >= 0 THEN -2 * local_id - 1 ELSE 2 * local_id END WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-1_938_472_708) { emit ->
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionAyahsDeleteIn(collection_local_id: Long): QueryResult<Long> {
    val result = driver.execute(-1_317_375_983, """DELETE FROM collection_ayah WHERE collection_local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, collection_local_id)
        }
    notifyQueries(-1_317_375_983) { emit ->
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionAyahDelete(local_id: Long): QueryResult<Long> {
    val result = driver.execute(803_497_533, """DELETE FROM collection_ayah WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(803_497_533) { emit ->
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun collectionAyahsDeleteAll(): QueryResult<Long> {
    val result = driver.execute(2_111_009_845, """DELETE FROM collection_ayah""", 0)
    notifyQueries(2_111_009_845) { emit ->
      emit("collection_ayah")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun remoteAyahBookmarkPut(
    bookmark_id: String,
    sura: Long,
    ayah: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-480_175_233, """INSERT OR REPLACE INTO remote_ayah_bookmark(bookmark_id, sura, ayah) VALUES (?, ?, ?)""", 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, bookmark_id)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
        }
    notifyQueries(-480_175_233) { emit ->
      emit("remote_ayah_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun remoteAyahBookmarksDeleteAll(): QueryResult<Long> {
    val result = driver.execute(-121_936_333, """DELETE FROM remote_ayah_bookmark""", 0)
    notifyQueries(-121_936_333) { emit ->
      emit("remote_ayah_bookmark")
    }
    return result
  }

  private inner class CollectionGetQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-186_578_589, """SELECT collection.local_id, collection.name, collection.name_key, collection.is_default, collection.is_system, collection.is_read_only, collection.created_at, collection.updated_at FROM collection WHERE local_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "collections.sq:collectionGet"
  }

  private inner class CollectionByKeyQuery<out T : Any>(
    public val name_key: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT collection.local_id, collection.name, collection.name_key, collection.is_default, collection.is_system, collection.is_read_only, collection.created_at, collection.updated_at FROM collection WHERE name_key ${ if (name_key == null) "IS" else "=" } ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, name_key)
    }

    override fun toString(): String = "collections.sq:collectionByKey"
  }

  private inner class CollectionAyahGetQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection_ayah", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection_ayah", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(76_007_428, """SELECT collection_ayah.local_id, collection_ayah.collection_local_id, collection_ayah.sura, collection_ayah.ayah, collection_ayah.created_at FROM collection_ayah WHERE local_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "collections.sq:collectionAyahGet"
  }

  private inner class CollectionAyahsInQuery<out T : Any>(
    public val collection_local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection_ayah", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection_ayah", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(76_048_838, """SELECT collection_ayah.local_id, collection_ayah.collection_local_id, collection_ayah.sura, collection_ayah.ayah, collection_ayah.created_at FROM collection_ayah WHERE collection_local_id = ? ORDER BY sura, ayah""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, collection_local_id)
    }

    override fun toString(): String = "collections.sq:collectionAyahsIn"
  }

  private inner class CollectionAyahsAtQuery<out T : Any>(
    public val sura: Long,
    public val ayah: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection_ayah", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection_ayah", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(76_048_596, """SELECT collection_ayah.local_id, collection_ayah.collection_local_id, collection_ayah.sura, collection_ayah.ayah, collection_ayah.created_at FROM collection_ayah WHERE sura = ? AND ayah = ? ORDER BY local_id""", mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, sura)
      bindLong(parameterIndex++, ayah)
    }

    override fun toString(): String = "collections.sq:collectionAyahsAt"
  }

  private inner class CollectionAyahFindQuery<out T : Any>(
    public val collection_local_id: Long,
    public val sura: Long,
    public val ayah: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection_ayah", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection_ayah", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_938_763_061, """SELECT collection_ayah.local_id, collection_ayah.collection_local_id, collection_ayah.sura, collection_ayah.ayah, collection_ayah.created_at FROM collection_ayah WHERE collection_local_id = ? AND sura = ? AND ayah = ?""", mapper, 3) {
      var parameterIndex = 0
      bindLong(parameterIndex++, collection_local_id)
      bindLong(parameterIndex++, sura)
      bindLong(parameterIndex++, ayah)
    }

    override fun toString(): String = "collections.sq:collectionAyahFind"
  }

  private inner class RemoteAyahBookmarkGetQuery<out T : Any>(
    public val bookmark_id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("remote_ayah_bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("remote_ayah_bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-480_184_378, """SELECT remote_ayah_bookmark.bookmark_id, remote_ayah_bookmark.sura, remote_ayah_bookmark.ayah FROM remote_ayah_bookmark WHERE bookmark_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, bookmark_id)
    }

    override fun toString(): String = "collections.sq:remoteAyahBookmarkGet"
  }
}
