@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import app.cash.sqldelight.ExecutableQuery
import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class NotesQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> all(mapper: (
    local_id: Long,
    body: String,
    created_at: Long,
    updated_at: Long,
    archived_at: Long?,
  ) -> T): Query<T> = Query(353_558_720, arrayOf("note"), driver, "notes.sq", "all", "SELECT note.local_id, note.body, note.created_at, note.updated_at, note.archived_at FROM note ORDER BY local_id") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)
    )
  }

  public fun all(): Query<Note> = all(::Note)

  public fun <T : Any> `get`(local_id: Long, mapper: (
    local_id: Long,
    body: String,
    created_at: Long,
    updated_at: Long,
    archived_at: Long?,
  ) -> T): Query<T> = GetQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)
    )
  }

  public fun `get`(local_id: Long): Query<Note> = get(local_id, ::Note)

  public fun <T : Any> active(mapper: (
    local_id: Long,
    body: String,
    created_at: Long,
    updated_at: Long,
    archived_at: Long?,
  ) -> T): Query<T> = Query(1_600_049_031, arrayOf("note"), driver, "notes.sq", "active", "SELECT note.local_id, note.body, note.created_at, note.updated_at, note.archived_at FROM note WHERE archived_at IS NULL ORDER BY created_at DESC, local_id DESC") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)
    )
  }

  public fun active(): Query<Note> = active(::Note)

  public fun <T : Any> allRanges(mapper: (
    note_local_id: Long,
    position: Long,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
  ) -> T): Query<T> = Query(831_466_422, arrayOf("note_range"), driver, "notes.sq", "allRanges", "SELECT note_range.note_local_id, note_range.position, note_range.start_sura, note_range.start_ayah, note_range.end_sura, note_range.end_ayah FROM note_range ORDER BY note_local_id, position") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!
    )
  }

  public fun allRanges(): Query<Note_range> = allRanges(::Note_range)

  public fun <T : Any> rangesOf(note_local_id: Long, mapper: (
    note_local_id: Long,
    position: Long,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
  ) -> T): Query<T> = RangesOfQuery(note_local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!
    )
  }

  public fun rangesOf(note_local_id: Long): Query<Note_range> = rangesOf(note_local_id, ::Note_range)

  public fun createdAts(): Query<Long> = Query(-993_762_663, arrayOf("note"), driver, "notes.sq", "createdAts", "SELECT created_at FROM note") { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> freeCreatedAt(at: Long?, mapper: (free: Long?) -> T): Query<T> = FreeCreatedAtQuery(at) { cursor ->
    mapper(
      cursor.getLong(0)
    )
  }

  public fun freeCreatedAt(at: Long?): Query<FreeCreatedAt> = freeCreatedAt(at, ::FreeCreatedAt)

  public fun lastInsertId(): ExecutableQuery<Long> = Query(-382_325_205, driver, "notes.sq", "lastInsertId", "SELECT last_insert_rowid()") { cursor ->
    cursor.getLong(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun insert(
    body: String,
    created_at: Long,
    updated_at: Long,
    archived_at: Long?,
  ): QueryResult<Long> {
    val result = driver.execute(1_839_207_226, """INSERT INTO note(body, created_at, updated_at, archived_at) VALUES (?, ?, ?, ?)""", 4) {
          var parameterIndex = 0
          bindString(parameterIndex++, body)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, archived_at)
        }
    notifyQueries(1_839_207_226) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertWithId(
    local_id: Long?,
    body: String,
    created_at: Long,
    updated_at: Long,
    archived_at: Long?,
  ): QueryResult<Long> {
    val result = driver.execute(1_654_836_315, """INSERT INTO note(local_id, body, created_at, updated_at, archived_at) VALUES (?, ?, ?, ?, ?)""", 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, body)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, archived_at)
        }
    notifyQueries(1_654_836_315) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertRange(
    note_local_id: Long,
    position: Long,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-367_121_885, """INSERT INTO note_range(note_local_id, position, start_sura, start_ayah, end_sura, end_ayah) VALUES (?, ?, ?, ?, ?, ?)""", 6) {
          var parameterIndex = 0
          bindLong(parameterIndex++, note_local_id)
          bindLong(parameterIndex++, position)
          bindLong(parameterIndex++, start_sura)
          bindLong(parameterIndex++, start_ayah)
          bindLong(parameterIndex++, end_sura)
          bindLong(parameterIndex++, end_ayah)
        }
    notifyQueries(-367_121_885) { emit ->
      emit("note_range")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun update(
    body: String,
    created_at: Long,
    updated_at: Long,
    archived_at: Long?,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-2_110_813_878, """UPDATE note SET body = ?, created_at = ?, updated_at = ?, archived_at = ? WHERE local_id = ?""", 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, body)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, archived_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-2_110_813_878) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateBody(
    body: String,
    updated_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_635_090_956, """UPDATE note SET body = ?, updated_at = ? WHERE local_id = ?""", 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, body)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_635_090_956) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteRanges(note_local_id: Long): QueryResult<Long> {
    val result = driver.execute(-10_002_398, """DELETE FROM note_range WHERE note_local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, note_local_id)
        }
    notifyQueries(-10_002_398) { emit ->
      emit("note_range")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun delete(local_id: Long): QueryResult<Long> {
    val result = driver.execute(1_687_541_292, """DELETE FROM note WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_687_541_292) { emit ->
      emit("note")
      emit("note_range")
    }
    return result
  }

  private inner class GetQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(353_564_277, """SELECT note.local_id, note.body, note.created_at, note.updated_at, note.archived_at FROM note WHERE local_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "notes.sq:get"
  }

  private inner class RangesOfQuery<out T : Any>(
    public val note_local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note_range", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note_range", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_957_678_990, """SELECT note_range.note_local_id, note_range.position, note_range.start_sura, note_range.start_ayah, note_range.end_sura, note_range.end_ayah FROM note_range WHERE note_local_id = ? ORDER BY position""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, note_local_id)
    }

    override fun toString(): String = "notes.sq:rangesOf"
  }

  private inner class FreeCreatedAtQuery<out T : Any>(
    public val at: Long?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-284_214_130, """
    |SELECT min(candidate) AS free FROM (
    |  SELECT CAST(? AS INTEGER) AS candidate
    |  UNION ALL
    |  SELECT created_at + 1 FROM note WHERE created_at >= ?
    |) WHERE candidate NOT IN (SELECT created_at FROM note)
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, at)
      bindLong(parameterIndex++, at)
    }

    override fun toString(): String = "notes.sq:freeCreatedAt"
  }
}
