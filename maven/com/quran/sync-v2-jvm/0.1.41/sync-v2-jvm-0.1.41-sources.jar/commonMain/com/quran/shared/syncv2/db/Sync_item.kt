@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long
import kotlin.String

public data class Sync_item(
  public val resource: String,
  public val local_id: Long,
  public val remote_id: String?,
  public val base_json: String?,
  public val held_reason: String?,
  public val held_json: String?,
  public val held_until: Long?,
)
