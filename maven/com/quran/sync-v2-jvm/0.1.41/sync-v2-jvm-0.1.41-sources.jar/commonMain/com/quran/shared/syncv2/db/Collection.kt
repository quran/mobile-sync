@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long
import kotlin.String

public data class Collection(
  public val local_id: Long,
  public val name: String,
  public val name_key: String?,
  public val is_default: Long,
  public val is_system: Long,
  public val is_read_only: Long,
  public val created_at: Long,
  public val updated_at: Long,
)
