@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class Sync_runQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> newest(limit: Long, mapper: (
    id: Long,
    started_at: Long,
    ended_at: Long,
    triggered_by: String,
    result: String,
    attempts: Long,
    pushed: Long,
    pulled: Long,
    held: Long,
    error_kind: String?,
    error_http_status: Long?,
    error_server_code: String?,
    error_message: String?,
  ) -> T): Query<T> = NewestQuery(limit) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getString(9),
      cursor.getLong(10),
      cursor.getString(11),
      cursor.getString(12)
    )
  }

  public fun newest(limit: Long): Query<Sync_run> = newest(limit, ::Sync_run)

  /**
   * @return The number of rows updated.
   */
  public fun insert(
    started_at: Long,
    ended_at: Long,
    triggered_by: String,
    result: String,
    attempts: Long,
    pushed: Long,
    pulled: Long,
    held: Long,
    error_kind: String?,
    error_http_status: Long?,
    error_server_code: String?,
    error_message: String?,
  ): QueryResult<Long> {
    val result = driver.execute(199_105_788, """
        |INSERT INTO sync_run(
        |  started_at, ended_at, triggered_by, result, attempts, pushed, pulled, held,
        |  error_kind, error_http_status, error_server_code, error_message
        |) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 12) {
          var parameterIndex = 0
          bindLong(parameterIndex++, started_at)
          bindLong(parameterIndex++, ended_at)
          bindString(parameterIndex++, triggered_by)
          bindString(parameterIndex++, result)
          bindLong(parameterIndex++, attempts)
          bindLong(parameterIndex++, pushed)
          bindLong(parameterIndex++, pulled)
          bindLong(parameterIndex++, held)
          bindString(parameterIndex++, error_kind)
          bindLong(parameterIndex++, error_http_status)
          bindString(parameterIndex++, error_server_code)
          bindString(parameterIndex++, error_message)
        }
    notifyQueries(199_105_788) { emit ->
      emit("sync_run")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun prune(keep: Long): QueryResult<Long> {
    val result = driver.execute(428_650_759, """DELETE FROM sync_run WHERE id NOT IN (SELECT id FROM sync_run ORDER BY id DESC LIMIT ?)""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, keep)
        }
    notifyQueries(428_650_759) { emit ->
      emit("sync_run")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(236_516_051, """DELETE FROM sync_run""", 0)
    notifyQueries(236_516_051) { emit ->
      emit("sync_run")
    }
    return result
  }

  private inner class NewestQuery<out T : Any>(
    public val limit: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("sync_run", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("sync_run", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(334_059_049, """SELECT sync_run.id, sync_run.started_at, sync_run.ended_at, sync_run.triggered_by, sync_run.result, sync_run.attempts, sync_run.pushed, sync_run.pulled, sync_run.held, sync_run.error_kind, sync_run.error_http_status, sync_run.error_server_code, sync_run.error_message FROM sync_run ORDER BY id DESC LIMIT ?""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, limit)
    }

    override fun toString(): String = "sync_run.sq:newest"
  }
}
