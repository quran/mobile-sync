@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.quran.shared.syncv2.db.syncv2.newInstance
import com.quran.shared.syncv2.db.syncv2.schema
import kotlin.String
import kotlin.Unit
import kotlin.collections.List

public interface SyncV2Database : Transacter {
  public val collectionsQueries: CollectionsQueries

  public val notesQueries: NotesQueries

  public val readingBookmarksQueries: ReadingBookmarksQueries

  public val sessionsQueries: SessionsQueries

  public val sync_itemQueries: Sync_itemQueries

  public val sync_runQueries: Sync_runQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = SyncV2Database::class.schema

    public operator fun invoke(driver: SqlDriver): SyncV2Database = SyncV2Database::class.newInstance(driver)

    public fun allTableNames(): List<String> = listOf("collection", "collection_ayah", "note", "note_range", "reading_bookmark", "reading_session", "remote_ayah_bookmark", "sync_item", "sync_meta", "sync_run")
  }
}
