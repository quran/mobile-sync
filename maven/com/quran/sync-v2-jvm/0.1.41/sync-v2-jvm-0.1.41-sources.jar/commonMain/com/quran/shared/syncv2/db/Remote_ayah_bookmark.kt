@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long
import kotlin.String

public data class Remote_ayah_bookmark(
  public val bookmark_id: String,
  public val sura: Long,
  public val ayah: Long,
)
