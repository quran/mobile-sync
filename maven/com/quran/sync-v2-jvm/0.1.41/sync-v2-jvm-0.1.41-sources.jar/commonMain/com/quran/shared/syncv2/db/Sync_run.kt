@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import kotlin.Long
import kotlin.String

public data class Sync_run(
  public val id: Long,
  public val started_at: Long,
  public val ended_at: Long,
  public val triggered_by: String,
  public val result: String,
  public val attempts: Long,
  public val pushed: Long,
  public val pulled: Long,
  public val held: Long,
  public val error_kind: String?,
  public val error_http_status: Long?,
  public val error_server_code: String?,
  public val error_message: String?,
)
