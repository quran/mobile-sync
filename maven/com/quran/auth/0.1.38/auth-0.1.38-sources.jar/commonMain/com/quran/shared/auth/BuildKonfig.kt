@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER")

package com.quran.shared.auth

import kotlin.Boolean
import kotlin.String
import kotlin.Suppress

internal object BuildKonfig {
  public val BUILD_TYPE: String = "debug"

  public val IS_DEBUG: Boolean = true
}
