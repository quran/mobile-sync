package com.quran.shared.auth.model

import com.quran.shared.auth.model.UserInfo

/**
 * Sealed class representing authentication state.
 *
 * The auth flow is handled entirely by the OIDC library's CodeAuthFlow, so we only need states for: Restoring, Idle,
 * Loading, Success, and Error.
 */
sealed class AuthState {
    /**
     * Initial state: the stored session has not been read yet. It is replaced by [Success] or [Idle] once the launch
     * check has read local storage, without waiting on the network.
     */
    data object Restoring : AuthState()

    /** User not logged in, ready to start */
    data object Idle : AuthState()

    /** Authentication in progress (browser may be open) */
    data object Loading : AuthState()

    /**
     * Successfully authenticated.
     *
     * [userInfo] comes from the session's ID token and is stored with the tokens. It is null only
     * for a session stored before this version, until its next token refresh.
     */
    data class Success(val userInfo: UserInfo?) : AuthState()

    /** Authentication failed with an exception */
    data class Error(val exception: Exception, val message: String) : AuthState()
}
