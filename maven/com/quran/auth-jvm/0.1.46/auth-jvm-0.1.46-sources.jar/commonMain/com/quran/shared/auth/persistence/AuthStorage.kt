package com.quran.shared.auth.persistence

import com.quran.shared.auth.model.FetchedProfile
import com.quran.shared.auth.model.TokenResponse
import com.quran.shared.auth.model.UserInfo
import com.quran.shared.auth.utils.currentTimeMillis
import com.quran.shared.di.AppScope
import com.russhwolf.settings.coroutines.SuspendSettings
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.SingleIn
import kotlin.native.HiddenFromObjC
import kotlin.time.Instant
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import org.publicvalue.multiplatform.oidc.tokenstore.TokenStore
import org.publicvalue.multiplatform.oidc.types.remote.AccessTokenResponse

/**
 * Persists authentication token material and non-secret session metadata across app restarts.
 *
 * The OIDC token response is stored through [TokenStore] so each platform can use its secure
 * storage implementation. App-specific commit markers, normalized expiry, scope, the session's
 * user (read from its ID token), and its fetched profile remain in settings.
 */
@SingleIn(AppScope::class)
@HiddenFromObjC
@Inject
class AuthStorage(
    private val tokenStore: TokenStore,
    private val settings: SuspendSettings,
    private val json: Json
) {

    suspend fun retrieveStoredAccessToken(): String? = tokenStore.getAccessToken()
    suspend fun retrieveStoredRefreshToken(): String? = tokenStore.getRefreshToken()
    suspend fun retrieveStoredIdToken(): String? = tokenStore.getIdToken()
    suspend fun retrieveStoredScope(): String? = settings.getStringOrNull(KEY_SCOPE)
    suspend fun retrieveTokenExpiration(): Long = settings.getLong(KEY_TOKEN_EXPIRATION, 0)
    suspend fun retrieveSessionGeneration(): Long = settings.getLong(KEY_SESSION_GENERATION, 0)
    suspend fun retrieveCommittedTokenGeneration(): Long? =
        settings.getLongOrNull(KEY_COMMITTED_TOKEN_GENERATION)
    suspend fun retrieveTokenWriteGeneration(): Long =
        settings.getLong(KEY_TOKEN_WRITE_GENERATION, 0)
    suspend fun retrieveCommittedTokenWriteGeneration(): Long? =
        settings.getLongOrNull(KEY_COMMITTED_TOKEN_WRITE_GENERATION)

    suspend fun storeSessionGeneration(generation: Long) {
        settings.putLong(KEY_SESSION_GENERATION, generation)
    }

    suspend fun storeCommittedTokenGeneration(generation: Long) {
        settings.putLong(KEY_COMMITTED_TOKEN_GENERATION, generation)
        settings.putLong(KEY_COMMITTED_TOKEN_WRITE_GENERATION, retrieveTokenWriteGeneration())
    }

    suspend fun clearTokenCommitMetadata() {
        var failure: Exception? = null

        suspend fun attempt(block: suspend () -> Unit) {
            try {
                block()
            } catch (e: Exception) {
                if (failure == null) {
                    failure = e
                }
            }
        }

        attempt { settings.remove(KEY_COMMITTED_TOKEN_GENERATION) }
        attempt { settings.remove(KEY_COMMITTED_TOKEN_WRITE_GENERATION) }

        failure?.let { throw it }
    }

    /**
     * Retrieves the session's user (read from its ID token) from non-token session metadata.
     */
    suspend fun retrieveUserInfo(): UserInfo? {
        val userInfoJson = settings.getStringOrNull(KEY_USER_INFO) ?: return null
        return try {
            json.decodeFromString<UserInfo>(userInfoJson)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Stores token response data for an existing session while preserving stable refresh and ID
     * tokens when a refresh response omits them.
     *
     * Some providers return only a new access token during refresh. Passing null directly to
     * [TokenStore.saveTokens] would remove the previous refresh token, so this method reads the
     * existing secure token values first and keeps them unless replacements are present.
     *
     * @param tokenResponse token response returned from a refresh or same-session update.
     * @param userInfo the user read from the response's ID token, stored in the same write; null keeps the stored user.
     */
    suspend fun storeTokens(tokenResponse: TokenResponse, userInfo: UserInfo? = null) {
        storeTokens(tokenResponse, preserveExistingTokens = true, userInfo = userInfo)
    }

    /**
     * Stores token response data for a newly completed interactive login session.
     *
     * This intentionally does not preserve existing refresh or ID tokens. A successful login or
     * login-continuation is a session boundary, so stale identity metadata must be removed before
     * the new token material is stored.
     *
     * @param tokenResponse token response returned from a successful interactive login.
     * @param userInfo the session's user read from the response's ID token, stored in the same write.
     */
    suspend fun storeNewSessionTokens(tokenResponse: TokenResponse, userInfo: UserInfo) {
        val previousMetadata = snapshotSessionMetadata()
        try {
            clearSessionMetadata()
            storeTokens(tokenResponse, preserveExistingTokens = false, userInfo = userInfo)
        } catch (e: Exception) {
            try {
                withContext(NonCancellable) {
                    restoreSessionMetadata(previousMetadata)
                }
            } catch (_: Exception) {
                // Token rollback already left the advanced write marker when full restore was unsafe.
            }
            throw e
        }
    }

    private suspend fun storeTokens(
        tokenResponse: TokenResponse,
        preserveExistingTokens: Boolean,
        userInfo: UserInfo?
    ) {
        // OIDC 0.18 stores tokens as one record. A single snapshot keeps preservation and rollback
        // on the same version if another token-store implementation updates the record atomically.
        val previousTokens = tokenStore.getTokenResponse()
        val previousScope = settings.getStringOrNull(KEY_SCOPE)
        val previousExpiration = settings.getLongOrNull(KEY_TOKEN_EXPIRATION)
        val previousRetrievedAt = settings.getLongOrNull(KEY_TOKEN_RETRIEVED_AT)
        val previousTokenWriteGeneration = settings.getLongOrNull(KEY_TOKEN_WRITE_GENERATION)
        val previousUserInfo = settings.getStringOrNull(KEY_USER_INFO)
        try {
            markTokenWriteStarted(previousTokenWriteGeneration)
            val expirationTime = if (tokenResponse.expiresAt != null) {
                try {
                    Instant.parse(tokenResponse.expiresAt).toEpochMilliseconds()
                } catch (e: Exception) {
                    currentTimeMillis() + (tokenResponse.expiresIn * 1000)
                }
            } else {
                currentTimeMillis() + (tokenResponse.expiresIn * 1000)
            }
            val refreshToken = tokenResponse.refreshToken
                ?: if (preserveExistingTokens) previousTokens?.refresh_token else null
            val idToken = tokenResponse.idToken
                ?: if (preserveExistingTokens) previousTokens?.id_token else null

            tokenStore.saveTokens(
                accessToken = tokenResponse.accessToken,
                refreshToken = refreshToken,
                idToken = idToken
            )
            tokenResponse.scope?.let { settings.putString(KEY_SCOPE, it) }
            settings.putLong(KEY_TOKEN_EXPIRATION, expirationTime)
            settings.putLong(KEY_TOKEN_RETRIEVED_AT, currentTimeMillis())
            userInfo?.let { storeUserInfo(it) }
        } catch (e: Exception) {
            rollbackTokenWrite(
                tokens = previousTokens,
                scope = previousScope,
                expiration = previousExpiration,
                retrievedAt = previousRetrievedAt,
                tokenWriteGeneration = previousTokenWriteGeneration,
                userInfo = previousUserInfo
            )
            throw e
        }
    }

    suspend fun storeUserInfo(userInfo: UserInfo) {
        settings.putString(KEY_USER_INFO, json.encodeToString(userInfo))
    }

    /**
     * The session's profile as the account API last returned it, kept apart from the ID token's user, which a token
     * refresh rewrites. Null when none was fetched for this session, or it can't be read.
     */
    suspend fun retrieveFetchedProfile(): FetchedProfile? {
        val profileJson = settings.getStringOrNull(KEY_FETCHED_PROFILE) ?: return null
        return try {
            json.decodeFromString<FetchedProfile>(profileJson)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun storeFetchedProfile(profile: FetchedProfile) {
        settings.putString(KEY_FETCHED_PROFILE, json.encodeToString(profile))
    }

    /** When this session last tried to fetch its profile (epoch milliseconds), whatever came of it. */
    suspend fun retrieveProfileFetchAttemptedAt(): Long? = settings.getLongOrNull(KEY_PROFILE_FETCH_ATTEMPTED_AT)

    suspend fun storeProfileFetchAttemptedAt(attemptedAt: Long) {
        settings.putLong(KEY_PROFILE_FETCH_ATTEMPTED_AT, attemptedAt)
    }

    /**
     * Clears secure token material and non-token auth metadata.
     */
    suspend fun clearAllTokens() {
        var failure: Exception? = null

        suspend fun attempt(block: suspend () -> Unit) {
            try {
                block()
            } catch (e: Exception) {
                if (failure == null) {
                    failure = e
                }
            }
        }

        attempt { clearTokenCommitMetadata() }
        attempt { tokenStore.removeTokens() }
        attempt { clearSessionMetadata() }

        failure?.let { throw it }
    }

    private suspend fun markTokenWriteStarted(previousTokenWriteGeneration: Long?) {
        val writeGenerationBase = maxOf(
            previousTokenWriteGeneration ?: 0L,
            retrieveCommittedTokenWriteGeneration() ?: 0L
        )
        settings.putLong(KEY_TOKEN_WRITE_GENERATION, writeGenerationBase + 1)
    }

    private suspend fun restoreTokens(tokens: AccessTokenResponse?) {
        if (tokens == null) {
            tokenStore.removeTokens()
        } else {
            tokenStore.saveTokens(tokens)
        }
    }

    private suspend fun restoreTokenMetadata(
        scope: String?,
        expiration: Long?,
        retrievedAt: Long?
    ) {
        if (scope == null) {
            settings.remove(KEY_SCOPE)
        } else {
            settings.putString(KEY_SCOPE, scope)
        }
        if (expiration == null) {
            settings.remove(KEY_TOKEN_EXPIRATION)
        } else {
            settings.putLong(KEY_TOKEN_EXPIRATION, expiration)
        }
        if (retrievedAt == null) {
            settings.remove(KEY_TOKEN_RETRIEVED_AT)
        } else {
            settings.putLong(KEY_TOKEN_RETRIEVED_AT, retrievedAt)
        }
    }

    private suspend fun rollbackTokenWrite(
        tokens: AccessTokenResponse?,
        scope: String?,
        expiration: Long?,
        retrievedAt: Long?,
        tokenWriteGeneration: Long?,
        userInfo: String?
    ) {
        try {
            withContext(NonCancellable) {
                restoreTokens(tokens)
                restoreTokenMetadata(
                    scope = scope,
                    expiration = expiration,
                    retrievedAt = retrievedAt
                )
                restoreUserInfo(userInfo)
                if (tokenWriteGeneration == null) {
                    settings.remove(KEY_TOKEN_WRITE_GENERATION)
                } else {
                    settings.putLong(KEY_TOKEN_WRITE_GENERATION, tokenWriteGeneration)
                }
            }
        } catch (_: Exception) {
            // Leave the advanced write marker so partially written token material stays hidden.
        }
    }

    private suspend fun snapshotSessionMetadata(): SessionMetadata =
        SessionMetadata(
            scope = settings.getStringOrNull(KEY_SCOPE),
            expiration = settings.getLongOrNull(KEY_TOKEN_EXPIRATION),
            retrievedAt = settings.getLongOrNull(KEY_TOKEN_RETRIEVED_AT),
            userInfo = settings.getStringOrNull(KEY_USER_INFO),
            fetchedProfile = settings.getStringOrNull(KEY_FETCHED_PROFILE),
            profileFetchAttemptedAt = settings.getLongOrNull(KEY_PROFILE_FETCH_ATTEMPTED_AT)
        )

    private suspend fun restoreSessionMetadata(metadata: SessionMetadata) {
        restoreTokenMetadata(
            scope = metadata.scope,
            expiration = metadata.expiration,
            retrievedAt = metadata.retrievedAt
        )
        restoreUserInfo(metadata.userInfo)
        if (metadata.fetchedProfile == null) {
            settings.remove(KEY_FETCHED_PROFILE)
        } else {
            settings.putString(KEY_FETCHED_PROFILE, metadata.fetchedProfile)
        }
        if (metadata.profileFetchAttemptedAt == null) {
            settings.remove(KEY_PROFILE_FETCH_ATTEMPTED_AT)
        } else {
            settings.putLong(KEY_PROFILE_FETCH_ATTEMPTED_AT, metadata.profileFetchAttemptedAt)
        }
    }

    private suspend fun restoreUserInfo(userInfo: String?) {
        if (userInfo == null) {
            settings.remove(KEY_USER_INFO)
        } else {
            settings.putString(KEY_USER_INFO, userInfo)
        }
    }

    /** The session's own data: a logout and a new session (a sign-in, maybe to another account) remove it all. */
    private suspend fun clearSessionMetadata() {
        settings.remove(KEY_SCOPE)
        settings.remove(KEY_USER_INFO)
        settings.remove(KEY_FETCHED_PROFILE)
        settings.remove(KEY_PROFILE_FETCH_ATTEMPTED_AT)
        settings.remove(KEY_TOKEN_EXPIRATION)
        settings.remove(KEY_TOKEN_RETRIEVED_AT)
    }

    companion object {
        private const val KEY_SCOPE = "scope"
        private const val KEY_TOKEN_EXPIRATION = "token_expiration"
        private const val KEY_TOKEN_RETRIEVED_AT = "token_retrieved_at"
        private const val KEY_USER_INFO = "user_info"
        private const val KEY_FETCHED_PROFILE = "fetched_profile"
        private const val KEY_PROFILE_FETCH_ATTEMPTED_AT = "profile_fetch_attempted_at"
        private const val KEY_SESSION_GENERATION = "session_generation"
        private const val KEY_COMMITTED_TOKEN_GENERATION = "committed_token_generation"
        private const val KEY_TOKEN_WRITE_GENERATION = "token_write_generation"
        private const val KEY_COMMITTED_TOKEN_WRITE_GENERATION = "committed_token_write_generation"
    }
}

private data class SessionMetadata(
    val scope: String?,
    val expiration: Long?,
    val retrievedAt: Long?,
    val userInfo: String?,
    val fetchedProfile: String?,
    val profileFetchAttemptedAt: Long?
)
