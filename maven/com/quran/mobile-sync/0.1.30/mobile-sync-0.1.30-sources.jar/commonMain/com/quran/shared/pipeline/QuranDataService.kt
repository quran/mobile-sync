package com.quran.shared.pipeline

import co.touchlab.kermit.Logger
import com.quran.shared.auth.model.AuthState
import com.quran.shared.auth.repository.LogoutTokenCaptureException
import com.quran.shared.auth.repository.LogoutTokenMaterial
import com.quran.shared.auth.repository.RemoteLogoutFailure
import com.quran.shared.auth.repository.RemoteLogoutMode
import com.quran.shared.auth.repository.RemoteLogoutOperation
import com.quran.shared.auth.service.AuthService
import com.quran.shared.di.AppScope
import com.quran.shared.persistence.TextLengthLimitException
import com.quran.shared.persistence.input.PersistenceImportData
import com.quran.shared.persistence.input.PersistenceImportResult
import com.quran.shared.persistence.model.AyahHighlight
import com.quran.shared.persistence.model.AyahHighlightColor
import com.quran.shared.persistence.model.BookmarkCollectionsReplacementResult
import com.quran.shared.persistence.model.Collection
import com.quran.shared.persistence.model.CollectionAyahBookmark
import com.quran.shared.persistence.model.CollectionWithAyahBookmarks
import com.quran.shared.persistence.model.Note
import com.quran.shared.persistence.model.ReadingBookmark
import com.quran.shared.persistence.model.ReadingBookmarkSlot
import com.quran.shared.persistence.model.ReadingSession
import com.quran.shared.persistence.repository.PersistenceResetRepository
import com.quran.shared.persistence.repository.bookmark.repository.BookmarksRepository
import com.quran.shared.persistence.repository.collection.repository.CollectionsRepository
import com.quran.shared.persistence.repository.collectionbookmark.repository.CollectionBookmarksRepository
import com.quran.shared.persistence.repository.importdata.PersistenceImportRepository
import com.quran.shared.persistence.repository.note.repository.NotesRepository
import com.quran.shared.persistence.repository.readingsession.repository.ReadingSessionsRepository
import com.quran.shared.persistence.util.PlatformDateTime
import com.quran.shared.persistence.util.currentPlatformDateTime
import com.quran.shared.persistence.util.toPlatform
import com.quran.shared.syncengine.AuthenticationDataFetcher
import com.quran.shared.syncengine.LocalModificationDateFetcher
import com.quran.shared.syncengine.SyncLifecycleGate
import com.quran.shared.syncengine.SynchronizationClient
import com.quran.shared.syncengine.SynchronizationEnvironment
import com.rickclephas.kmp.nativecoroutines.NativeCoroutines
import com.rickclephas.kmp.nativecoroutines.NativeCoroutinesState
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.SingleIn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.native.HiddenFromObjC
import kotlin.time.Instant

/**
 * Creates the scheduler-backed synchronization client used by [QuranDataService].
 *
 * Keeping this as a graph binding lets tests replace only the sync client creation path while
 * leaving the service and repository dependencies wired through Metro.
 */
@HiddenFromObjC
internal fun interface QuranDataServiceSynchronizationClientFactory {
    /**
     * Builds a synchronization client for the service lifecycle.
     *
     * @param pipeline the sync pipeline that owns resource adapters and repository bridges.
     * @param environment the remote sync environment.
     * @param localModificationDateFetcher reads the current local sync token.
     * @param authenticationDataFetcher supplies fresh authentication headers for sync requests.
     * @param syncLifecycleGate guards sync work during managed session resets.
     * @param callback receives sync completion and error events.
     * @return the synchronization client used for app-start, local-mutation, and immediate sync triggers.
     */
    fun create(
        pipeline: SyncEnginePipeline,
        environment: SynchronizationEnvironment,
        localModificationDateFetcher: LocalModificationDateFetcher,
        authenticationDataFetcher: AuthenticationDataFetcher,
        syncLifecycleGate: SyncLifecycleGate,
        callback: SyncEngineCallback
    ): SynchronizationClient
}

/**
 * Production sync client factory that delegates to [SyncEnginePipeline.setup].
 */
@HiddenFromObjC
@Inject
internal class DefaultQuranDataServiceSynchronizationClientFactory() :
    QuranDataServiceSynchronizationClientFactory {
    override fun create(
        pipeline: SyncEnginePipeline,
        environment: SynchronizationEnvironment,
        localModificationDateFetcher: LocalModificationDateFetcher,
        authenticationDataFetcher: AuthenticationDataFetcher,
        syncLifecycleGate: SyncLifecycleGate,
        callback: SyncEngineCallback
    ): SynchronizationClient =
        pipeline.setup(
            environment = environment,
            localModificationDateFetcher = localModificationDateFetcher,
            authenticationDataFetcher = authenticationDataFetcher,
            syncLifecycleGate = syncLifecycleGate,
            callback = callback
        )
}

/**
 * Managed app-facing data facade for Quran user data.
 *
 * Sync-capable clients use this facade for reads and writes so local persistence mutations,
 * sync scheduling, session reset safety, and cross-resource reconciliation stay coordinated.
 * This class must be obtained from the [com.quran.shared.pipeline.di.AppGraph] DI graph via
 * [com.quran.shared.pipeline.di.SharedDependencyGraph]. Direct construction is not supported.
 */
@Inject
@SingleIn(AppScope::class)
class QuranDataService internal constructor(
    private val authService: AuthService,
    private val pipeline: SyncEnginePipeline,
    private val environment: SynchronizationEnvironment,
    private val persistenceResetRepository: PersistenceResetRepository,
    private val persistenceImportRepository: PersistenceImportRepository,
    private val syncLocalModificationDateStore: SyncLocalModificationDateStore,
    private val sessionLifecycleCoordinator: SessionLifecycleCoordinator,
    private val syncClientFactory: QuranDataServiceSynchronizationClientFactory
) {
    private val serviceJob: Job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + serviceJob)
    private val syncClient: SynchronizationClient
    private val initializationMutex = Mutex()
    private var initializationAttempt: Deferred<Unit>? = null
    private var initialized = false
    private var syncLifecycleStarted = false

    fun clear() {
        serviceJob.cancel()
        syncClient.cancelSyncing()
    }

    @HiddenFromObjC
    suspend fun clearAndJoin() {
        clear()
        serviceJob.cancelAndJoin()
        syncClient.cancelSyncingAndJoin()
    }

    @HiddenFromObjC
    internal suspend fun awaitInitialization() {
        val attempt = initializationMutex.withLock {
            if (initialized) {
                null
            } else {
                initializationAttempt ?: scope.async {
                    sessionLifecycleCoordinator.completePersistedResetIfNeeded {
                        syncClient.cancelSyncingAndJoin()
                        resetLocalAuthDataAndToken()
                    }
                }.also { initializationAttempt = it }
            }
        } ?: return

        try {
            attempt.await()
        } catch (failure: Throwable) {
            if (attempt.isCompleted) {
                initializationMutex.withLock {
                    if (initializationAttempt === attempt) initializationAttempt = null
                }
            }
            throw failure
        }

        val shouldStartSyncLifecycle = initializationMutex.withLock {
            initialized = true
            if (initializationAttempt === attempt) initializationAttempt = null
            if (syncLifecycleStarted || !serviceJob.isActive) {
                false
            } else {
                syncLifecycleStarted = true
                true
            }
        }
        if (shouldStartSyncLifecycle) startSyncLifecycle()
    }

    private fun startSyncLifecycle() {
        scope.launch {
            syncClient.applicationStarted()

            // Observe auth state and trigger sync when a session is published. Logged-out sync
            // attempts no-op after fetching empty headers; managed reset owns cancellation.
            authState.collect { state ->
                if (state is AuthState.Success && sessionLifecycleCoordinator.canStartSync()) {
                    syncClient.triggerSyncImmediately()
                }
            }
        }
    }

    @NativeCoroutinesState
    val authState: StateFlow<AuthState> get() = authService.authState

    // Cast the synchronization repository to the transactional repository.
    // This keeps QuranDataService as the single app-facing data entry point.
    private val bookmarksRepository = pipeline.bookmarksRepository as BookmarksRepository
    private val readingBookmarksRepository = pipeline.readingBookmarksRepository
    private val collectionsRepository = pipeline.collectionsRepository as CollectionsRepository
    private val collectionBookmarksRepository =
        pipeline.collectionBookmarksRepository as CollectionBookmarksRepository
    private val notesRepository = pipeline.notesRepository as NotesRepository
    private val readingSessionsRepository = pipeline.readingSessionsRepository as ReadingSessionsRepository

    /**
     * Flow of ayah highlights, stored independently from app-facing bookmark collections.
     */
    @NativeCoroutines
    val highlights: Flow<List<AyahHighlight>> get() = collectionBookmarksRepository.getHighlightsFlow()

    @NativeCoroutines
    val readingBookmarks: Flow<List<ReadingBookmark>> get() = readingBookmarksRepository.getReadingBookmarksFlow()

    /**
     * Flow of all collections with their bookmarks for the UI to observe.
     *
     * The default collection is first. Non-default system collections remain hidden from this
     * app-facing collection list.
     */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    @NativeCoroutines
    val collectionsWithBookmarks: Flow<List<CollectionWithAyahBookmarks>>
        get() =
            collectionsRepository.getCollectionsFlow().flatMapLatest { collections ->
                val collectionFlows = collections
                    .filter { it.isDefault || !it.isSystem }
                    .sortedByDescending(Collection::isDefault)
                    .map { collection ->
                        collectionBookmarksRepository.getBookmarksForCollectionFlow(collection.id)
                            .map { bookmarks: List<CollectionAyahBookmark> ->
                                CollectionWithAyahBookmarks(collection, bookmarks)
                            }
                    }
                if (collectionFlows.isEmpty()) {
                    flowOf(emptyList())
                } else {
                    combine(collectionFlows) { it.toList() }
                }
            }

    /**
     * Flow of all notes for the UI to observe.
     */
    @NativeCoroutines
    val notes: Flow<List<Note>> get() = notesRepository.getNotesFlow()

    /**
     * Flow of all reading sessions for the UI to observe.
     */
    @NativeCoroutines
    val readingSessions: Flow<List<ReadingSession>> get() = readingSessionsRepository.getReadingSessionsFlow()

    init {
        val authFetcher = object : AuthenticationDataFetcher {
            override suspend fun fetchAuthenticationHeaders(): Map<String, String> {
                return authService.getAuthHeaders()
            }

            override fun isLoggedIn(): Boolean {
                return authService.isLoggedIn()
            }
        }

        syncClient = syncClientFactory.create(
            pipeline = pipeline,
            environment = environment,
            localModificationDateFetcher = syncLocalModificationDateStore,
            authenticationDataFetcher = authFetcher,
            syncLifecycleGate = sessionLifecycleCoordinator,
            callback = SettingsSyncEngineCallback(syncLocalModificationDateStore, CurrentSyncWriteBoundaryGuard)
        )

        scope.launch {
            try {
                awaitInitialization()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Logger.e(e) { "Failed to recover persisted session reset" }
            }
        }
    }

    @NativeCoroutines
    suspend fun logout(clearLocalData: Boolean = true): LogoutResult {
        awaitInitialization()
        if (!clearLocalData) {
            throw UnsupportedOperationException("Keep-local logout is not implemented yet")
        }
        val remoteLogoutMode = RemoteLogoutMode.TOKEN_REVOCATION_ONLY
        var tokenMaterial: LogoutTokenMaterial? = null
        var tokenCaptureFailure: Throwable? = null
        try {
            sessionLifecycleCoordinator.runManagedReset(
                beforeWriteDrain = {
                    try {
                        authService.captureLogoutTokenMaterialForLogout()
                    } catch (e: LogoutTokenCaptureException) {
                        tokenCaptureFailure = e.cause ?: e
                        null
                    }.let { captured ->
                        tokenMaterial = captured
                    }
                }
            ) {
                syncClient.cancelSyncingAndJoin()
                resetLocalDataAndSyncToken()
            }
            val warnings = tokenCaptureFailure?.let { failure ->
                logoutRemoteCleanupFailureWarnings(failure, remoteLogoutMode)
            } ?: try {
                authService.attemptRemoteLogout(
                    tokenMaterial!!,
                    remoteLogoutMode
                ).let { failures ->
                    failures.map { it.toLogoutWarning() }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (failure: Throwable) {
                logoutRemoteCleanupFailureWarnings(failure, remoteLogoutMode)
            }
            return LogoutResult(warnings)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Logger.e(e) { "Logout failed" }
            throw e
        }
    }

    fun triggerSync() {
        if (!sessionLifecycleCoordinator.canStartSync()) {
            Logger.d { "Sync trigger skipped because session is resetting" }
            return
        }
        syncClient.localDataUpdated()
    }

    private suspend fun resetLocalAuthDataAndToken() {
        authService.clearLocalSession()
        resetLocalDataAndSyncToken()
    }

    private suspend fun resetLocalDataAndSyncToken() {
        persistenceResetRepository.deleteAllData()
        syncLocalModificationDateStore.updateLastModificationDate(0L)
    }

    private fun logoutRemoteCleanupFailureWarnings(
        failure: Throwable,
        mode: RemoteLogoutMode
    ): List<LogoutWarning> =
        mode.operations.map { operation ->
            LogoutWarning(
                type = operation.toLogoutWarningType(),
                message = failure.message
            )
        }

    private fun RemoteLogoutFailure.toLogoutWarning(): LogoutWarning =
        LogoutWarning(
            type = operation.toLogoutWarningType(),
            message = exception.message
        )

    private fun RemoteLogoutOperation.toLogoutWarningType(): LogoutWarningType =
        when (this) {
            RemoteLogoutOperation.REVOKE_REFRESH_TOKEN -> LogoutWarningType.REVOKE_TOKEN_FAILED
            RemoteLogoutOperation.END_SESSION -> LogoutWarningType.END_SESSION_FAILED
        }

    private suspend fun <T> mutatingCall(
        errorMessage: String,
        shouldTriggerSync: (T) -> Boolean = { true },
        block: suspend () -> T
    ): T {
        try {
            awaitInitialization()
            return sessionLifecycleCoordinator.withMutatingWrite {
                val result = block()
                if (shouldTriggerSync(result)) {
                    triggerSync()
                }
                result
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Logger.e(e) { errorMessage }
            throw e
        }
    }

    @NativeCoroutines
    suspend fun importData(data: PersistenceImportData): PersistenceImportResult {
        return importData(
            data = data,
            deleteExisting = false,
            trackHistory = false
        )
    }

    @NativeCoroutines
    suspend fun importData(
        data: PersistenceImportData,
        deleteExisting: Boolean
    ): PersistenceImportResult = importData(data, deleteExisting, trackHistory = false)

    @NativeCoroutines
    suspend fun importData(
        data: PersistenceImportData,
        deleteExisting: Boolean,
        trackHistory: Boolean
    ): PersistenceImportResult = mutatingCall(
        errorMessage = "Failed to import persistence data",
        shouldTriggerSync = { result -> result.changed }
    ) {
        persistenceImportRepository.importData(data, deleteExisting, trackHistory)
    }

    /**
     * Sets the highlight color for one ayah, replacing any existing highlight color.
     * Default and user collection memberships are preserved.
     */
    @NativeCoroutines
    suspend fun setHighlight(sura: Int, ayah: Int, color: AyahHighlightColor): AyahHighlight {
        return setHighlight(sura, ayah, color, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun setHighlight(
        sura: Int,
        ayah: Int,
        color: AyahHighlightColor,
        timestamp: PlatformDateTime
    ): AyahHighlight {
        return mutatingCall("Failed to set ayah highlight") {
            collectionBookmarksRepository.setHighlight(sura, ayah, color, timestamp)
        }
    }

    /**
     * Deletes the highlight from one ayah while preserving default and user collection memberships.
     *
     * @return `true` when at least one highlight membership was removed.
     */
    @NativeCoroutines
    suspend fun deleteHighlight(sura: Int, ayah: Int): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete ayah highlight",
            shouldTriggerSync = { removed -> removed }
        ) {
            collectionBookmarksRepository.deleteHighlight(sura, ayah)
        }
    }

    @NativeCoroutines
    suspend fun replaceAyahBookmarkCollections(
        sura: Int,
        ayah: Int,
        collectionIds: List<String>
    ): BookmarkCollectionsReplacementResult {
        return replaceAyahBookmarkCollections(sura, ayah, collectionIds, currentPlatformDateTime())
    }

    /**
     * Replaces an ayah bookmark's saved collection memberships with an explicit mutation timestamp
     * and schedules sync only when memberships changed.
     *
     * Non-empty memberships create the bookmark if needed. Empty memberships remove the saved
     * bookmark, or do nothing when it does not exist. Highlight collection memberships are always
     * preserved and excluded from replacement.
     */
    @NativeCoroutines
    suspend fun replaceAyahBookmarkCollections(
        sura: Int,
        ayah: Int,
        collectionIds: List<String>,
        timestamp: PlatformDateTime
    ): BookmarkCollectionsReplacementResult {
        return mutatingCall(
            errorMessage = "Failed to replace ayah bookmark collection memberships",
            shouldTriggerSync = { result -> result.changed }
        ) {
            bookmarksRepository.replaceAyahBookmarkCollections(sura, ayah, collectionIds, timestamp)
        }
    }

    @NativeCoroutines
    suspend fun setAyahReadingBookmark(
        slot: ReadingBookmarkSlot,
        sura: Int,
        ayah: Int
    ): ReadingBookmark = setAyahReadingBookmark(slot, sura, ayah, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun setAyahReadingBookmark(
        slot: ReadingBookmarkSlot,
        sura: Int,
        ayah: Int,
        timestamp: PlatformDateTime
    ): ReadingBookmark = mutatingCall("Failed to set reading ayah bookmark") {
        readingBookmarksRepository.setAyahReadingBookmark(slot, sura, ayah, timestamp)
    }

    @NativeCoroutines
    suspend fun setPageReadingBookmark(slot: ReadingBookmarkSlot, page: Int): ReadingBookmark =
        setPageReadingBookmark(slot, page, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun setPageReadingBookmark(
        slot: ReadingBookmarkSlot,
        page: Int,
        timestamp: PlatformDateTime
    ): ReadingBookmark =
        mutatingCall("Failed to set reading page bookmark") {
            readingBookmarksRepository.setPageReadingBookmark(slot, page, timestamp)
        }

    @NativeCoroutines
    suspend fun renameReadingBookmark(slot: ReadingBookmarkSlot, name: String?): ReadingBookmark =
        renameReadingBookmark(slot, name, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun renameReadingBookmark(
        slot: ReadingBookmarkSlot,
        name: String?,
        timestamp: PlatformDateTime
    ): ReadingBookmark =
        mutatingCall("Failed to rename reading bookmark") {
            readingBookmarksRepository.renameReadingBookmark(slot, name, timestamp)
        }

    @NativeCoroutines
    suspend fun clearReadingBookmark(slot: ReadingBookmarkSlot): ReadingBookmark =
        clearReadingBookmark(slot, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun clearReadingBookmark(slot: ReadingBookmarkSlot, timestamp: PlatformDateTime): ReadingBookmark =
        mutatingCall("Failed to clear reading bookmark") {
            readingBookmarksRepository.clearReadingBookmark(slot, timestamp)
        }

    @NativeCoroutines
    suspend fun addReadingSession(sura: Int, ayah: Int): ReadingSession {
        return addReadingSession(sura, ayah, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun addReadingSession(sura: Int, ayah: Int, timestamp: PlatformDateTime): ReadingSession {
        return mutatingCall("Failed to add reading session") {
            readingSessionsRepository.addReadingSession(sura, ayah, timestamp)
        }
    }

    /**
     * Updates a reading session, merging it into an existing destination session when needed.
     *
     * The returned session is authoritative because a merge returns the destination's ID.
     */
    @NativeCoroutines
    suspend fun updateReadingSession(id: String, sura: Int, ayah: Int): ReadingSession {
        return updateReadingSession(id, sura, ayah, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun updateReadingSession(
        id: String,
        sura: Int,
        ayah: Int,
        timestamp: PlatformDateTime
    ): ReadingSession {
        return mutatingCall("Failed to update reading session") {
            readingSessionsRepository.updateReadingSession(id, sura, ayah, timestamp)
        }
    }

    /**
     * Deletes the reading session at the given ayah and schedules sync only when a row was removed.
     *
     * @param sura the sura number of the reading session to delete.
     * @param ayah the ayah number of the reading session to delete.
     * @return `true` when a reading session was deleted, or `false` when no matching session existed.
     */
    @NativeCoroutines
    suspend fun deleteReadingSession(sura: Int, ayah: Int): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete reading session",
            shouldTriggerSync = { deleted -> deleted }
        ) {
            readingSessionsRepository.deleteReadingSession(sura, ayah)
        }
    }

    /** @throws TextLengthLimitException when [name] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun addCollection(name: String): Collection {
        return addCollection(name, currentPlatformDateTime())
    }

    /** @throws TextLengthLimitException when [name] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun addCollection(name: String, timestamp: PlatformDateTime): Collection {
        return mutatingCall("Failed to add collection") {
            collectionsRepository.addCollection(name, timestamp)
        }
    }

    /**
     * Updates a collection name and schedules sync for the local mutation.
     *
     * @param id the mobile-sync identifier of the collection to update.
     * @param name the new collection name.
     * @return the updated collection.
     * @throws IllegalArgumentException when [id] does not identify an active collection.
     * @throws TextLengthLimitException when [name] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun updateCollection(id: String, name: String): Collection {
        return updateCollection(id, name, currentPlatformDateTime())
    }

    /**
     * Updates a collection name with an explicit mutation timestamp and schedules sync.
     *
     * @param id the mobile-sync identifier of the collection to update.
     * @param name the new collection name.
     * @param timestamp the timestamp to persist for the mutation.
     * @return the updated collection.
     * @throws IllegalArgumentException when [id] does not identify an active collection.
     * @throws TextLengthLimitException when [name] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun updateCollection(id: String, name: String, timestamp: PlatformDateTime): Collection {
        return mutatingCall("Failed to update collection") {
            collectionsRepository.updateCollection(id, name, timestamp)
        }
    }

    /** Deletes a custom collection and schedules sync when a row was removed. */
    @NativeCoroutines
    suspend fun deleteCollection(id: String): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete collection",
            shouldTriggerSync = { deleted -> deleted }
        ) {
            collectionsRepository.deleteCollection(id)
        }
    }

    @NativeCoroutines
    suspend fun addAyahBookmarkToCollection(
        collectionId: String,
        sura: Int,
        ayah: Int
    ): CollectionAyahBookmark {
        return addAyahBookmarkToCollection(collectionId, sura, ayah, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun addAyahBookmarkToCollection(
        collectionId: String,
        sura: Int,
        ayah: Int,
        timestamp: PlatformDateTime
    ): CollectionAyahBookmark {
        return mutatingCall("Failed to add ayah bookmark to collection") {
            collectionBookmarksRepository.addAyahBookmarkToCollection(collectionId, sura, ayah, timestamp)
        }
    }

    /** Removes an ayah bookmark from a collection and schedules sync when a membership was removed. */
    @NativeCoroutines
    suspend fun removeAyahBookmarkFromCollection(collectionId: String, bookmarkId: String): Boolean {
        return mutatingCall(
            errorMessage = "Failed to remove bookmark from collection",
            shouldTriggerSync = { removed -> removed }
        ) {
            collectionBookmarksRepository.removeAyahBookmarkFromCollection(collectionId, bookmarkId)
        }
    }

    /** @throws TextLengthLimitException when [body] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun addNote(body: String, startSura: Int, startAyah: Int, endSura: Int, endAyah: Int) {
        addNote(body, startSura, startAyah, endSura, endAyah, currentPlatformDateTime())
    }

    /** @throws TextLengthLimitException when [body] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun addNote(
        body: String,
        startSura: Int,
        startAyah: Int,
        endSura: Int,
        endAyah: Int,
        timestamp: PlatformDateTime
    ) {
        mutatingCall("Failed to add note") {
            notesRepository.addNote(body, startSura, startAyah, endSura, endAyah, timestamp)
        }
    }

    /**
     * Updates an existing note and schedules sync for the local mutation.
     *
     * @param id the mobile-sync identifier of the note to update.
     * @param body the updated note body.
     * @param startSura the first sura covered by the note.
     * @param startAyah the first ayah covered by the note.
     * @param endSura the last sura covered by the note.
     * @param endAyah the last ayah covered by the note.
     * @throws TextLengthLimitException when a changed [body] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun updateNote(
        id: String,
        body: String,
        startSura: Int,
        startAyah: Int,
        endSura: Int,
        endAyah: Int
    ) {
        updateNote(id, body, startSura, startAyah, endSura, endAyah, currentPlatformDateTime())
    }

    /** @throws TextLengthLimitException when a changed [body] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun updateNote(
        id: String,
        body: String,
        startSura: Int,
        startAyah: Int,
        endSura: Int,
        endAyah: Int,
        timestamp: PlatformDateTime
    ) {
        mutatingCall("Failed to update note") {
            notesRepository.updateNote(id, body, startSura, startAyah, endSura, endAyah, timestamp)
        }
    }

    /** Deletes a note and schedules sync when a row was removed. */
    @NativeCoroutines
    suspend fun deleteNote(id: String): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete note",
            shouldTriggerSync = { deleted -> deleted }
        ) {
            notesRepository.deleteNote(id)
        }
    }

}

internal class SettingsSyncEngineCallback(
    private val syncLocalModificationDateStore: SyncLocalModificationDateStore,
    private val writeBoundaryGuard: SyncWriteBoundaryGuard = SyncWriteBoundaryGuard {}
) : SyncEngineCallback {
    override suspend fun synchronizationDone(newLastModificationDate: Long) {
        Logger.i { "Sync completed. New last modified: $newLastModificationDate" }
        syncLocalModificationDateStore.updateLastModificationDate(newLastModificationDate, writeBoundaryGuard)
    }

    override suspend fun encounteredError(errorMsg: String) {
        Logger.e { "Sync error: $errorMsg" }
    }
}
