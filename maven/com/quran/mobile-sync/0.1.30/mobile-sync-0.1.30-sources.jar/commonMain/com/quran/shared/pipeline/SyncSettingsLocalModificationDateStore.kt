package com.quran.shared.pipeline

import com.quran.shared.di.AppScope
import com.quran.shared.syncengine.LocalModificationDateFetcher
import com.quran.shared.pipeline.storage.SyncMetadataSettings
import com.russhwolf.settings.coroutines.SuspendSettings
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.SingleIn
import kotlin.native.HiddenFromObjC

/**
 * Persists the shared remote sync token used to fetch incremental mutations.
 */
@HiddenFromObjC
interface SyncLocalModificationDateStore : LocalModificationDateFetcher {
    /**
     * Stores the newest completed remote mutation timestamp.
     *
     * @param date epoch-millisecond mutation timestamp returned by the sync API.
     */
    suspend fun updateLastModificationDate(date: Long)

    suspend fun updateLastModificationDate(
        date: Long,
        writeBoundaryGuard: SyncWriteBoundaryGuard
    ) {
        writeBoundaryGuard.checkWriteBoundary()
        updateLastModificationDate(date)
    }
}

/**
 * [SyncLocalModificationDateStore] backed by the graph-provided database settings instance.
 */
@HiddenFromObjC
@SingleIn(AppScope::class)
@Inject
class SyncSettingsLocalModificationDateStore(
    @SyncMetadataSettings private val settings: SuspendSettings
) : SyncLocalModificationDateStore {

    override suspend fun localLastModificationDate(): Long {
        return settings.getLong(KEY_LAST_MODIFIED, 0L)
    }

    override suspend fun updateLastModificationDate(date: Long) {
        settings.putLong(KEY_LAST_MODIFIED, date)
    }

    override suspend fun updateLastModificationDate(
        date: Long,
        writeBoundaryGuard: SyncWriteBoundaryGuard
    ) {
        writeBoundaryGuard.checkWriteBoundary()
        settings.putLong(KEY_LAST_MODIFIED, date)
    }

    private companion object {
        const val KEY_LAST_MODIFIED = "com.quran.sync.last_modified_date"
    }
}
