package com.quran.shared.pipeline

import co.touchlab.kermit.Logger
import com.quran.shared.di.AppScope
import com.quran.shared.mutations.LocalModelMutation
import com.quran.shared.mutations.LocalMutationAck
import com.quran.shared.mutations.Mutation
import com.quran.shared.mutations.RemoteModelMutation
import com.quran.shared.persistence.input.LocalSyncCollection
import com.quran.shared.persistence.input.LocalSyncCollectionAyahBookmark
import com.quran.shared.persistence.input.LocalSyncNote
import com.quran.shared.persistence.input.LocalSyncReadingSession
import com.quran.shared.persistence.input.LocalSyncReadingBookmark
import com.quran.shared.persistence.input.RemoteBookmark
import com.quran.shared.persistence.input.RemoteCollection
import com.quran.shared.persistence.input.RemoteCollectionBookmark
import com.quran.shared.persistence.input.RemoteNote
import com.quran.shared.persistence.input.RemoteReadingSession
import com.quran.shared.persistence.input.RemoteReadingBookmark
import com.quran.shared.persistence.model.ReadingSession
import com.quran.shared.persistence.repository.PersistenceWriteBoundaryGuard
import com.quran.shared.persistence.repository.bookmark.repository.BookmarksSynchronizationRepository
import com.quran.shared.persistence.repository.collection.repository.CollectionsSynchronizationRepository
import com.quran.shared.persistence.repository.collectionbookmark.repository.CollectionBookmarksSynchronizationRepository
import com.quran.shared.persistence.repository.note.repository.NotesSynchronizationRepository
import com.quran.shared.persistence.repository.readingbookmark.repository.ReadingBookmarksRepository
import com.quran.shared.persistence.repository.readingbookmark.repository.ReadingBookmarksSynchronizationRepository
import com.quran.shared.persistence.repository.readingsession.repository.ReadingSessionsSynchronizationRepository
import com.quran.shared.persistence.util.fromPlatform
import com.quran.shared.persistence.util.toPlatform
import com.quran.shared.syncengine.AuthenticationDataFetcher
import com.quran.shared.syncengine.BookmarksSynchronizationConfigurations
import com.quran.shared.syncengine.CollectionBookmarksSynchronizationConfigurations
import com.quran.shared.syncengine.CollectionsSynchronizationConfigurations
import com.quran.shared.syncengine.LocalDataFetcher
import com.quran.shared.syncengine.LocalModificationDateFetcher
import com.quran.shared.syncengine.NotesSynchronizationConfigurations
import com.quran.shared.syncengine.ReadingSessionsSynchronizationConfigurations
import com.quran.shared.syncengine.ReadingBookmarksSynchronizationConfigurations
import com.quran.shared.syncengine.ResultNotifier
import com.quran.shared.syncengine.SyncCompletionFinalizer
import com.quran.shared.syncengine.SyncLifecycleGate
import com.quran.shared.syncengine.SynchronizationClient
import com.quran.shared.syncengine.SynchronizationClientBuilder
import com.quran.shared.syncengine.SynchronizationEnvironment
import com.quran.shared.syncengine.checkCurrentSyncWriteBoundary
import com.quran.shared.syncengine.model.NoteAyah
import com.quran.shared.syncengine.model.NoteRange
import com.quran.shared.syncengine.model.SyncBookmark
import com.quran.shared.syncengine.model.SyncCollection
import com.quran.shared.syncengine.model.SyncCollectionBookmark
import com.quran.shared.syncengine.model.SyncNote
import com.quran.shared.syncengine.model.SyncReadingSession
import com.quran.shared.syncengine.model.SyncReadingBookmark
import com.quran.shared.syncengine.model.SyncReadingBookmarkLocation
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.SingleIn
import kotlin.native.HiddenFromObjC

@HiddenFromObjC
interface SyncEngineCallback {
    suspend fun synchronizationDone(newLastModificationDate: Long)
    suspend fun encounteredError(errorMsg: String)
}

@HiddenFromObjC
fun interface SyncWriteBoundaryGuard {
    suspend fun checkWriteBoundary()
}

private val NoOpSyncWriteBoundaryGuard = SyncWriteBoundaryGuard {}

internal val CurrentSyncWriteBoundaryGuard = SyncWriteBoundaryGuard {
    checkCurrentSyncWriteBoundary()
}

private fun SyncWriteBoundaryGuard.toPersistenceWriteBoundaryGuard(): PersistenceWriteBoundaryGuard =
    PersistenceWriteBoundaryGuard {
        checkWriteBoundary()
    }

private inline fun <Source, Target> LocalModelMutation<Source>.mapModel(
    transform: (LocalModelMutation<Source>) -> Target
): LocalModelMutation<Target> =
    LocalModelMutation(
        model = transform(this),
        remoteID = remoteID,
        localID = localID,
        mutation = mutation,
        ack = ack
    )

private inline fun <Source, Target> RemoteModelMutation<Source>.mapModel(
    transform: (RemoteModelMutation<Source>) -> Target
): RemoteModelMutation<Target> =
    RemoteModelMutation(
        model = transform(this),
        remoteID = remoteID,
        mutation = mutation,
        ack = ack
    )

@Inject
@SingleIn(AppScope::class)
@HiddenFromObjC
class SyncEnginePipeline(
    val bookmarksRepository: BookmarksSynchronizationRepository,
    val readingBookmarksRepository: ReadingBookmarksRepository,
    val readingBookmarksSynchronizationRepository: ReadingBookmarksSynchronizationRepository,
    val collectionsRepository: CollectionsSynchronizationRepository,
    val collectionBookmarksRepository: CollectionBookmarksSynchronizationRepository,
    val notesRepository: NotesSynchronizationRepository,
    val readingSessionsRepository: ReadingSessionsSynchronizationRepository
) {
    private lateinit var syncClient: SynchronizationClient

    fun setup(
        environment: SynchronizationEnvironment,
        localModificationDateFetcher: LocalModificationDateFetcher,
        authenticationDataFetcher: AuthenticationDataFetcher,
        syncLifecycleGate: SyncLifecycleGate,
        callback: SyncEngineCallback
    ): SynchronizationClient {
        val writeBoundaryGuard = CurrentSyncWriteBoundaryGuard

        val bookmarksConf = BookmarksSynchronizationConfigurations(
            localModificationDateFetcher = localModificationDateFetcher,
            resultNotifier = ResultReceiver(bookmarksRepository, callback, writeBoundaryGuard),
            localDataFetcher = RepositoryDataFetcher(bookmarksRepository)
        )
        val collectionsConf = CollectionsSynchronizationConfigurations(
            localModificationDateFetcher = localModificationDateFetcher,
            resultNotifier = CollectionsResultReceiver(collectionsRepository, callback, writeBoundaryGuard),
            localDataFetcher = CollectionsRepositoryDataFetcher(collectionsRepository)
        )
        val collectionBookmarksConf = CollectionBookmarksSynchronizationConfigurations(
            localModificationDateFetcher = localModificationDateFetcher,
            resultNotifier = CollectionBookmarksResultReceiver(
                collectionBookmarksRepository,
                callback,
                writeBoundaryGuard
            ),
            localDataFetcher = CollectionBookmarksRepositoryDataFetcher(collectionBookmarksRepository, bookmarksRepository)
        )
        val notesConf = NotesSynchronizationConfigurations(
            localModificationDateFetcher = localModificationDateFetcher,
            resultNotifier = NotesResultReceiver(notesRepository, callback, writeBoundaryGuard),
            localDataFetcher = NotesRepositoryDataFetcher(notesRepository)
        )
        val readingBookmarksConf = ReadingBookmarksSynchronizationConfigurations(
            localModificationDateFetcher = localModificationDateFetcher,
            resultNotifier = ReadingBookmarksResultReceiver(
                repository = readingBookmarksSynchronizationRepository,
                callback = callback,
                writeBoundaryGuard = writeBoundaryGuard
            ),
            localDataFetcher = ReadingBookmarksRepositoryDataFetcher(readingBookmarksSynchronizationRepository)
        )
        val readingSessionsConf = ReadingSessionsSynchronizationConfigurations(
            localModificationDateFetcher = localModificationDateFetcher,
            resultNotifier = ReadingSessionsResultReceiver(
                repository = readingSessionsRepository,
                callback = callback,
                writeBoundaryGuard = writeBoundaryGuard
            ),
            localDataFetcher = ReadingSessionsRepositoryDataFetcher(readingSessionsRepository)
        )
        val syncClient = SynchronizationClientBuilder.build(
            environment = environment,
            authFetcher = authenticationDataFetcher,
            bookmarksConfigurations = bookmarksConf,
            collectionsConfigurations = collectionsConf,
            collectionBookmarksConfigurations = collectionBookmarksConf,
            notesConfigurations = notesConf,
            readingBookmarksConfigurations = readingBookmarksConf,
            readingSessionsConfigurations = readingSessionsConf,
            syncLifecycleGate = syncLifecycleGate,
            syncCompletionFinalizer = SyncCompletionFinalizer { token ->
                callback.synchronizationDone(token)
            }
        )

        this.syncClient = syncClient

        return syncClient
    }

    fun startListening() {
        // TODO:
    }
}

private class RepositoryDataFetcher(
    val bookmarksRepository: BookmarksSynchronizationRepository
) : LocalDataFetcher<SyncBookmark> {

    override suspend fun fetchLocalMutations(lastModified: Long): List<LocalModelMutation<SyncBookmark>> {
        return bookmarksRepository.fetchMutatedBookmarks().map { repoMutation ->
            repoMutation.mapModel { it.model.toSyncEngine(it.localID) }
        }
            .sortedByDescending { it.model.lastModified.toEpochMilliseconds() }
    }

    override suspend fun checkLocalExistence(remoteIDs: List<String>): Map<String, Boolean> {
        return bookmarksRepository.remoteResourcesExist(remoteIDs)
    }

    override suspend fun fetchLocalModel(remoteId: String): SyncBookmark? {
        return bookmarksRepository.fetchBookmarkByRemoteId(remoteId)?.toSyncEngine(remoteId)
    }

    override suspend fun markLocalMutationsInFlight(
        localMutations: List<LocalModelMutation<SyncBookmark>>
    ): List<LocalMutationAck> =
        bookmarksRepository.markMutatedBookmarksInFlight(localMutations.mapNotNull { it.ack })

    override suspend fun rollbackLocalMutationsInFlight(acks: List<LocalMutationAck>) {
        bookmarksRepository.rollbackMutatedBookmarksInFlight(acks)
    }
}

private class CollectionsRepositoryDataFetcher(
    val collectionsRepository: CollectionsSynchronizationRepository
) : LocalDataFetcher<SyncCollection> {

    override suspend fun fetchLocalMutations(lastModified: Long): List<LocalModelMutation<SyncCollection>> {
        return collectionsRepository.fetchMutatedCollections().map { repoMutation ->
            repoMutation.mapModel { it.model.toSyncEngine() }
        }
    }

    override suspend fun checkLocalExistence(remoteIDs: List<String>): Map<String, Boolean> {
        return collectionsRepository.remoteResourcesExist(remoteIDs)
    }

    override suspend fun fetchLocalModel(remoteId: String): SyncCollection? {
        return null
    }
}

private class CollectionBookmarksRepositoryDataFetcher(
    val collectionBookmarksRepository: CollectionBookmarksSynchronizationRepository,
    val bookmarksRepository: BookmarksSynchronizationRepository
) : LocalDataFetcher<SyncCollectionBookmark> {

    override suspend fun fetchLocalMutations(lastModified: Long): List<LocalModelMutation<SyncCollectionBookmark>> {
        return collectionBookmarksRepository.fetchMutatedCollectionBookmarks().map { repoMutation ->
            repoMutation.mapModel { it.model.toSyncEngine() }
        }
    }

    override suspend fun checkLocalExistence(remoteIDs: List<String>): Map<String, Boolean> {
        return collectionBookmarksRepository.remoteResourcesExist(remoteIDs)
    }

    override suspend fun fetchLocalModel(remoteId: String): SyncCollectionBookmark? {
        collectionBookmarksRepository.fetchCollectionBookmarkByRemoteId(remoteId)?.let { collectionBookmark ->
            return collectionBookmark.toSyncEngine()
        }
        val bookmark = bookmarksRepository.fetchBookmarkByRemoteId(remoteId) ?: return null
        return when (bookmark) {
            is RemoteBookmark.Ayah -> SyncCollectionBookmark.AyahBookmark(
                collectionId = "", // Not used for this fetch
                sura = bookmark.sura,
                ayah = bookmark.ayah,
                lastModified = bookmark.lastUpdated.fromPlatform(),
                bookmarkId = remoteId,
                createdAt = bookmark.createdAt?.fromPlatform()
            )
        }
    }

    override suspend fun markLocalMutationsInFlight(
        localMutations: List<LocalModelMutation<SyncCollectionBookmark>>
    ): List<LocalMutationAck> =
        collectionBookmarksRepository.markMutatedCollectionBookmarksInFlight(localMutations.mapNotNull { it.ack })

    override suspend fun rollbackLocalMutationsInFlight(acks: List<LocalMutationAck>) {
        collectionBookmarksRepository.rollbackMutatedCollectionBookmarksInFlight(acks)
    }
}

private class NotesRepositoryDataFetcher(
    val notesRepository: NotesSynchronizationRepository
) : LocalDataFetcher<SyncNote> {
    private val logger = Logger.withTag("NotesRepositoryDataFetcher")

    override suspend fun fetchLocalMutations(lastModified: Long): List<LocalModelMutation<SyncNote>> {
        return notesRepository.fetchMutatedNotes(lastModified).mapNotNull { repoMutation ->
            val syncNote = repoMutation.model.toSyncEngine()
            if (syncNote == null) {
                logger.w { "Skipping note mutation with invalid ayah range: localId=${repoMutation.localID}" }
                null
            } else {
                repoMutation.mapModel { syncNote }
            }
        }
    }

    override suspend fun checkLocalExistence(remoteIDs: List<String>): Map<String, Boolean> {
        return notesRepository.remoteResourcesExist(remoteIDs)
    }

    override suspend fun fetchLocalModel(remoteId: String): SyncNote? {
        return null
    }
}

private class ReadingBookmarksRepositoryDataFetcher(
    val repository: ReadingBookmarksSynchronizationRepository
) : LocalDataFetcher<SyncReadingBookmark> {

    override suspend fun fetchLocalMutations(lastModified: Long): List<LocalModelMutation<SyncReadingBookmark>> =
        repository.fetchMutatedReadingBookmarks().map { mutation ->
            mutation.mapModel { it.model.toSyncEngine() }
        }

    override suspend fun checkLocalExistence(remoteIDs: List<String>): Map<String, Boolean> =
        repository.remoteResourcesExist(remoteIDs)

    override suspend fun fetchLocalModel(remoteId: String): SyncReadingBookmark? =
        repository.fetchReadingBookmarkByRemoteId(remoteId)?.toSyncEngine()
}

private class ReadingSessionsRepositoryDataFetcher(
    val readingSessionsRepository: ReadingSessionsSynchronizationRepository
) : LocalDataFetcher<SyncReadingSession> {

    override suspend fun fetchLocalMutations(lastModified: Long): List<LocalModelMutation<SyncReadingSession>> {
        return readingSessionsRepository.fetchMutatedReadingSessions().map { repoMutation ->
            repoMutation.mapModel { it.model.toSyncEngine() }
        }
    }

    override suspend fun checkLocalExistence(remoteIDs: List<String>): Map<String, Boolean> {
        return readingSessionsRepository.remoteResourcesExist(remoteIDs)
    }

    override suspend fun fetchLocalModel(remoteId: String): SyncReadingSession? {
        return readingSessionsRepository.fetchReadingSessionByRemoteId(remoteId)?.toSyncEngine()
    }
}

internal abstract class CallbackResultNotifier<Model>(
    private val callback: SyncEngineCallback
) : ResultNotifier<Model> {
    override suspend fun didFail(message: String) {
        callback.encounteredError(message)
    }
}

private fun logPersistingSyncChanges(
    resourceLabel: String,
    remoteUpdateCount: Int,
    localUpdateCount: Int
) {
    Logger.i {
        "Persisting $remoteUpdateCount $resourceLabel remote updates, " +
            "and clearing $localUpdateCount local updates."
    }
}

internal class ResultReceiver(
    val bookmarksRepository: BookmarksSynchronizationRepository,
    callback: SyncEngineCallback,
    private val writeBoundaryGuard: SyncWriteBoundaryGuard = NoOpSyncWriteBoundaryGuard
) : CallbackResultNotifier<SyncBookmark>(callback) {

    override suspend fun didSucceed(
        newToken: Long,
        newRemoteMutations: List<RemoteModelMutation<SyncBookmark>>,
        processedLocalMutations: List<LocalModelMutation<SyncBookmark>>
    ) {
        val mappedRemotes = newRemoteMutations.map { remoteMutation ->
            remoteMutation.mapModel { it.model.toRemoteInput() }
        }
        val mappedLocals = processedLocalMutations.map { localMutation ->
            localMutation.mapModel { it.model.toRemoteInput() }
        }

        logPersistingSyncChanges("bookmark", mappedRemotes.size, mappedLocals.size)

        bookmarksRepository.applyRemoteChanges(
            updatesToPersist = mappedRemotes,
            localMutationsToClear = mappedLocals,
            writeBoundaryGuard = writeBoundaryGuard.toPersistenceWriteBoundaryGuard()
        )
    }
}

private class CollectionsResultReceiver(
    val repository: CollectionsSynchronizationRepository,
    callback: SyncEngineCallback,
    private val writeBoundaryGuard: SyncWriteBoundaryGuard = NoOpSyncWriteBoundaryGuard
) : CallbackResultNotifier<SyncCollection>(callback) {

    override suspend fun didSucceed(
        newToken: Long,
        newRemoteMutations: List<RemoteModelMutation<SyncCollection>>,
        processedLocalMutations: List<LocalModelMutation<SyncCollection>>
    ) {
        val mappedRemotes = newRemoteMutations.map { remoteMutation ->
            remoteMutation.mapModel { it.model.toRemoteInput() }
        }
        val mappedLocals = processedLocalMutations.map { localMutation ->
            localMutation.mapModel { it.model.toLocalSyncCollection() }
        }

        logPersistingSyncChanges("collection", mappedRemotes.size, mappedLocals.size)

        repository.applyRemoteChanges(
            updatesToPersist = mappedRemotes,
            localMutationsToClear = mappedLocals,
            writeBoundaryGuard = writeBoundaryGuard.toPersistenceWriteBoundaryGuard()
        )
    }
}

private class CollectionBookmarksResultReceiver(
    val repository: CollectionBookmarksSynchronizationRepository,
    callback: SyncEngineCallback,
    private val writeBoundaryGuard: SyncWriteBoundaryGuard = NoOpSyncWriteBoundaryGuard
) : CallbackResultNotifier<SyncCollectionBookmark>(callback) {

    override suspend fun didSucceed(
        newToken: Long,
        newRemoteMutations: List<RemoteModelMutation<SyncCollectionBookmark>>,
        processedLocalMutations: List<LocalModelMutation<SyncCollectionBookmark>>
    ) {
        val mappedRemotes = newRemoteMutations.map { remoteMutation ->
            remoteMutation.mapModel { it.model.toRemoteInput() }
        }
        val mappedLocals = processedLocalMutations.map { localMutation ->
            localMutation.mapModel { it.model.toLocalSyncCollectionBookmark(it.localID) }
        }

        logPersistingSyncChanges("collection bookmark", mappedRemotes.size, mappedLocals.size)

        repository.applyRemoteChanges(
            updatesToPersist = mappedRemotes,
            localMutationsToClear = mappedLocals,
            writeBoundaryGuard = writeBoundaryGuard.toPersistenceWriteBoundaryGuard()
        )
    }
}

private class NotesResultReceiver(
    val repository: NotesSynchronizationRepository,
    callback: SyncEngineCallback,
    private val writeBoundaryGuard: SyncWriteBoundaryGuard = NoOpSyncWriteBoundaryGuard
) : CallbackResultNotifier<SyncNote>(callback) {
    private val logger = Logger.withTag("NotesResultReceiver")

    override suspend fun didSucceed(
        newToken: Long,
        newRemoteMutations: List<RemoteModelMutation<SyncNote>>,
        processedLocalMutations: List<LocalModelMutation<SyncNote>>
    ) {
        val mappedRemotes = newRemoteMutations.mapNotNull { remoteMutation ->
            val remoteNote = when (remoteMutation.mutation) {
                Mutation.DELETED -> RemoteNote(
                    body = null,
                    startSura = null,
                    startAyah = null,
                    endSura = null,
                    endAyah = null,
                    lastUpdated = remoteMutation.model.lastModified.toPlatform(),
                    createdAt = remoteMutation.model.createdAt?.toPlatform()
                )
                Mutation.CREATED, Mutation.MODIFIED -> remoteMutation.model.toRemoteInput()
            }

            if (remoteNote == null) {
                logger.w { "Skipping remote note mutation without valid ranges: remoteId=${remoteMutation.remoteID}" }
                null
            } else {
                remoteMutation.mapModel { remoteNote }
            }
        }

        val mappedLocals = processedLocalMutations.mapNotNull { localMutation ->
            val localSyncNote = localMutation.model.toLocalSyncNote(localMutation.localID)
            if (localSyncNote == null) {
                logger.w { "Skipping local note mutation without valid ranges: localId=${localMutation.localID}" }
                null
            } else {
                localMutation.mapModel { localSyncNote }
            }
        }

        logPersistingSyncChanges("note", mappedRemotes.size, mappedLocals.size)

        repository.applyRemoteChanges(
            updatesToPersist = mappedRemotes,
            localMutationsToClear = mappedLocals,
            writeBoundaryGuard = writeBoundaryGuard.toPersistenceWriteBoundaryGuard()
        )
    }
}

internal class ReadingBookmarksResultReceiver(
    val repository: ReadingBookmarksSynchronizationRepository,
    callback: SyncEngineCallback,
    private val writeBoundaryGuard: SyncWriteBoundaryGuard = NoOpSyncWriteBoundaryGuard
) : CallbackResultNotifier<SyncReadingBookmark>(callback) {

    override suspend fun didSucceed(
        newToken: Long,
        newRemoteMutations: List<RemoteModelMutation<SyncReadingBookmark>>,
        processedLocalMutations: List<LocalModelMutation<SyncReadingBookmark>>
    ) {
        val remotes = newRemoteMutations.map { mutation ->
            mutation.mapModel { it.model.toRemoteInput() }
        }
        val locals = processedLocalMutations.map { mutation ->
            mutation.mapModel { it.model.toLocalSyncInput(it.localID) }
        }
        logPersistingSyncChanges("reading bookmark", remotes.size, locals.size)
        repository.applyRemoteChanges(
            updatesToPersist = remotes,
            localMutationsToClear = locals,
            writeBoundaryGuard = writeBoundaryGuard.toPersistenceWriteBoundaryGuard()
        )
    }
}

private class ReadingSessionsResultReceiver(
    val repository: ReadingSessionsSynchronizationRepository,
    callback: SyncEngineCallback,
    private val writeBoundaryGuard: SyncWriteBoundaryGuard = NoOpSyncWriteBoundaryGuard
) : CallbackResultNotifier<SyncReadingSession>(callback) {

    override suspend fun didSucceed(
        newToken: Long,
        newRemoteMutations: List<RemoteModelMutation<SyncReadingSession>>,
        processedLocalMutations: List<LocalModelMutation<SyncReadingSession>>
    ) {
        val mappedRemotes = newRemoteMutations.map { remoteMutation ->
            remoteMutation.mapModel { it.model.toRemoteInput() }
        }

        val mappedLocals = processedLocalMutations.map { localMutation ->
            localMutation.mapModel { it.model.toLocalSyncReadingSession(it.localID) }
        }

        logPersistingSyncChanges("reading session", mappedRemotes.size, mappedLocals.size)

        repository.applyRemoteChangesForMutations(
            updatesToPersist = mappedRemotes,
            localMutationsToClear = mappedLocals,
            writeBoundaryGuard = writeBoundaryGuard.toPersistenceWriteBoundaryGuard()
        )
    }
}

private fun RemoteBookmark.toSyncEngine(id: String): SyncBookmark {
    return when (this) {
        is RemoteBookmark.Ayah -> SyncBookmark.AyahBookmark(
            id = id,
            sura = this.sura,
            ayah = this.ayah,
            lastModified = this.lastUpdated.fromPlatform(),
            createdAt = this.createdAt?.fromPlatform()
        )
    }
}

private fun LocalSyncCollection.toSyncEngine(): SyncCollection {
    return SyncCollection(
        id = this.localId,
        name = this.name,
        lastModified = this.lastUpdated.fromPlatform(),
        createdAt = this.createdAt.fromPlatform(),
        isDefault = this.isDefault,
        isSystem = this.isSystem
    )
}

private fun SyncCollection.toLocalSyncCollection(): LocalSyncCollection {
    val updatedAt = lastModified.toPlatform()
    return LocalSyncCollection(
        name = requireNotNull(this.name) { "Transforming a collection without a name." },
        lastUpdated = updatedAt,
        localId = this.id,
        createdAt = this.createdAt?.toPlatform() ?: updatedAt,
        isDefault = this.isDefault,
        isSystem = this.isSystem
    )
}

private fun SyncBookmark.toRemoteInput(): RemoteBookmark {
    return when (this) {
        is SyncBookmark.AyahBookmark ->
            RemoteBookmark.Ayah(
                sura = this.sura,
                ayah = this.ayah,
                lastUpdated = this.lastModified.toPlatform(),
                createdAt = this.createdAt?.toPlatform()
            )
    }
}

private fun SyncCollection.toRemoteInput(): RemoteCollection {
    return RemoteCollection(
        name = this.name,
        lastUpdated = this.lastModified.toPlatform(),
        createdAt = this.createdAt?.toPlatform(),
        isDefault = this.isDefault,
        isSystem = this.isSystem
    )
}

private fun LocalSyncCollectionAyahBookmark.toSyncEngine(): SyncCollectionBookmark {
    val collectionId = requireNotNull(collectionRemoteId) { "Collection remote ID is required for sync." }
    return SyncCollectionBookmark.AyahBookmark(
        collectionId = collectionId,
        sura = sura,
        ayah = ayah,
        lastModified = lastUpdated.fromPlatform(),
        bookmarkId = bookmarkRemoteId,
        createdAt = createdAt?.fromPlatform()
    )
}

private fun SyncCollectionBookmark.toLocalSyncCollectionBookmark(localId: String): LocalSyncCollectionAyahBookmark {
    val updatedAt = lastModified.toPlatform()
    return when (this) {
        is SyncCollectionBookmark.AyahBookmark ->
            LocalSyncCollectionAyahBookmark(
                collectionLocalId = "",
                collectionRemoteId = collectionId,
                bookmarkLocalId = "",
                bookmarkRemoteId = bookmarkId,
                sura = sura,
                ayah = ayah,
                lastUpdated = updatedAt,
                localId = localId,
                createdAt = createdAt?.toPlatform()
            )
    }
}

private fun SyncCollectionBookmark.toRemoteInput(): RemoteCollectionBookmark {
    val updatedAt = lastModified.toPlatform()
    return when (this) {
        is SyncCollectionBookmark.AyahBookmark ->
            RemoteCollectionBookmark.Ayah(
                collectionId = collectionId,
                sura = sura,
                ayah = ayah,
                lastUpdated = updatedAt,
                bookmarkId = bookmarkId,
                createdAt = createdAt?.toPlatform()
            )
    }
}

private fun LocalSyncNote.toSyncEngine(): SyncNote? {
    return SyncNote(
        id = localId,
        body = body,
        ranges = listOf(
            NoteRange(
                start = NoteAyah(sura = startSura, ayah = startAyah),
                end = NoteAyah(sura = endSura, ayah = endAyah)
            )
        ),
        lastModified = lastUpdated.fromPlatform(),
        createdAt = createdAt.fromPlatform()
    )
}

private fun SyncNote.toLocalSyncNote(localId: String): LocalSyncNote? {
    val range = primaryRangeOrNull() ?: return null
    val noteBody = requireNotNull(body) { "Transforming a note without a body." }
    val updatedAt = lastModified.toPlatform()
    return LocalSyncNote(
        body = noteBody,
        startSura = range.start.sura,
        startAyah = range.start.ayah,
        endSura = range.end.sura,
        endAyah = range.end.ayah,
        lastUpdated = updatedAt,
        localId = localId,
        createdAt = createdAt?.toPlatform() ?: updatedAt
    )
}

private fun SyncNote.toRemoteInput(): RemoteNote? {
    val range = primaryRangeOrNull() ?: return null
    return RemoteNote(
        body = body,
        startSura = range.start.sura,
        startAyah = range.start.ayah,
        endSura = range.end.sura,
        endAyah = range.end.ayah,
        lastUpdated = lastModified.toPlatform(),
        semanticReplayEligible = ranges.size == 1,
        createdAt = createdAt?.toPlatform()
    )
}

private val notesRangeLogger = Logger.withTag("NotesRangeMapper")

private fun SyncNote.primaryRangeOrNull(): NoteRange? {
    if (ranges.isEmpty()) {
        return null
    }
    if (ranges.size > 1) {
        notesRangeLogger.w { "Note contains ${ranges.size} ranges; only the first will be synced. noteId=$id" }
    }
    return ranges.first()
}

private fun ReadingSession.toSyncEngine(): SyncReadingSession {
    return SyncReadingSession(
        id = id,
        chapterNumber = sura,
        verseNumber = ayah,
        lastModified = lastUpdated.fromPlatform()
    )
}

private fun LocalSyncReadingBookmark.toSyncEngine(): SyncReadingBookmark =
    SyncReadingBookmark(
        slot = slot,
        name = name,
        location = readingBookmarkLocation(type, sura, ayah, page),
        lastModified = lastUpdated.fromPlatform(),
        createdAt = createdAt.fromPlatform()
    )

private fun RemoteReadingBookmark.toSyncEngine(): SyncReadingBookmark =
    SyncReadingBookmark(
        slot = slot,
        name = name,
        location = readingBookmarkLocation(type, sura, ayah, page),
        lastModified = lastUpdated.fromPlatform(),
        createdAt = createdAt?.fromPlatform()
    )

private fun readingBookmarkLocation(
    type: String?,
    sura: Int?,
    ayah: Int?,
    page: Int?
): SyncReadingBookmarkLocation? = when (type) {
    "AYAH" -> SyncReadingBookmarkLocation.Ayah(
        sura = requireNotNull(sura),
        ayah = requireNotNull(ayah)
    )
    "PAGE" -> SyncReadingBookmarkLocation.Page(
        page = requireNotNull(page)
    )
    null -> null
    else -> error("Unsupported reading bookmark type: $type")
}

private fun SyncReadingBookmark.toRemoteInput(): RemoteReadingBookmark {
    val values = location.toPersistenceValues()
    return RemoteReadingBookmark(
        slot = slot,
        name = name,
        type = values.type,
        sura = values.sura,
        ayah = values.ayah,
        page = values.page,
        lastUpdated = lastModified.toPlatform(),
        createdAt = createdAt?.toPlatform()
    )
}

private fun SyncReadingBookmark.toLocalSyncInput(localId: String): LocalSyncReadingBookmark {
    val values = location.toPersistenceValues()
    val updatedAt = lastModified.toPlatform()
    return LocalSyncReadingBookmark(
        slot = slot,
        name = name,
        type = values.type,
        sura = values.sura,
        ayah = values.ayah,
        page = values.page,
        lastUpdated = updatedAt,
        localId = localId,
        createdAt = createdAt?.toPlatform() ?: updatedAt
    )
}

private data class ReadingBookmarkPersistenceValues(
    val type: String?,
    val sura: Int?,
    val ayah: Int?,
    val page: Int?
)

private fun SyncReadingBookmarkLocation?.toPersistenceValues(): ReadingBookmarkPersistenceValues = when (this) {
    is SyncReadingBookmarkLocation.Ayah -> ReadingBookmarkPersistenceValues(
        type = "AYAH",
        sura = sura,
        ayah = ayah,
        page = null
    )
    is SyncReadingBookmarkLocation.Page -> ReadingBookmarkPersistenceValues(
        type = "PAGE",
        sura = null,
        ayah = null,
        page = page
    )
    null -> ReadingBookmarkPersistenceValues(null, null, null, null)
}

private fun LocalSyncReadingSession.toSyncEngine(): SyncReadingSession {
    return SyncReadingSession(
        id = localId,
        chapterNumber = sura,
        verseNumber = ayah,
        lastModified = lastUpdated.fromPlatform(),
        createdAt = createdAt.fromPlatform()
    )
}

private fun SyncReadingSession.toLocalSyncReadingSession(localId: String): LocalSyncReadingSession {
    val updatedAt = lastModified.toPlatform()
    return LocalSyncReadingSession(
        sura = chapterNumber,
        ayah = verseNumber,
        lastUpdated = updatedAt,
        localId = localId,
        createdAt = createdAt?.toPlatform() ?: updatedAt
    )
}

private fun SyncReadingSession.toRemoteInput(): RemoteReadingSession {
    return RemoteReadingSession(
        chapterNumber = chapterNumber,
        verseNumber = verseNumber,
        lastUpdated = lastModified.toPlatform(),
        createdAt = createdAt?.toPlatform()
    )
}
