@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import kotlin.Long
import kotlin.String

public data class Note(
  public val local_id: Long,
  public val remote_id: String?,
  public val note: String,
  public val start_sura: Long,
  public val start_ayah: Long,
  public val end_sura: Long,
  public val end_ayah: Long,
  public val created_at: Long,
  public val modified_at: Long,
  public val deleted: Long,
  public val is_edited: Long,
  public val pending_version: Long,
)
