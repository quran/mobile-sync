@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import com.quran.shared.persistence.notes.CheckRemoteIDsExistence
import kotlin.Any
import kotlin.Long
import kotlin.String
import kotlin.collections.Collection

public class NotesQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> getNotes(mapper: (
    local_id: Long,
    remote_id: String?,
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(-753_552_330, arrayOf("note"), driver, "notes.sq", "getNotes", "SELECT note.local_id, note.remote_id, note.note, note.start_sura, note.start_ayah, note.end_sura, note.end_ayah, note.created_at, note.modified_at, note.deleted, note.is_edited, note.pending_version FROM note WHERE deleted = 0 ORDER BY created_at DESC") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getString(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!
    )
  }

  public fun getNotes(): Query<Note> = getNotes(::Note)

  public fun countAll(): Query<Long> = Query(1_208_525_117, arrayOf("note"), driver, "notes.sq", "countAll", "SELECT COUNT(*) FROM note") { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> getNoteByLocalId(local_id: Long, mapper: (
    local_id: Long,
    remote_id: String?,
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetNoteByLocalIdQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getString(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!
    )
  }

  public fun getNoteByLocalId(local_id: Long): Query<Note> = getNoteByLocalId(local_id, ::Note)

  public fun <T : Any> getNoteByRemoteId(remote_id: String?, mapper: (
    local_id: Long,
    remote_id: String?,
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetNoteByRemoteIdQuery(remote_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getString(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!
    )
  }

  public fun getNoteByRemoteId(remote_id: String?): Query<Note> = getNoteByRemoteId(remote_id, ::Note)

  public fun <T : Any> getPendingDeletedCreatedNotesByContent(
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    mapper: (
      local_id: Long,
      remote_id: String?,
      note: String,
      start_sura: Long,
      start_ayah: Long,
      end_sura: Long,
      end_ayah: Long,
      created_at: Long,
      modified_at: Long,
      deleted: Long,
      is_edited: Long,
      pending_version: Long,
    ) -> T,
  ): Query<T> = GetPendingDeletedCreatedNotesByContentQuery(note, start_sura, start_ayah, end_sura, end_ayah) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getString(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!
    )
  }

  public fun getPendingDeletedCreatedNotesByContent(
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
  ): Query<Note> = getPendingDeletedCreatedNotesByContent(note, start_sura, start_ayah, end_sura, end_ayah, ::Note)

  public fun <T : Any> getPendingActiveCreatedNotesByContent(
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    mapper: (
      local_id: Long,
      remote_id: String?,
      note: String,
      start_sura: Long,
      start_ayah: Long,
      end_sura: Long,
      end_ayah: Long,
      created_at: Long,
      modified_at: Long,
      deleted: Long,
      is_edited: Long,
      pending_version: Long,
    ) -> T,
  ): Query<T> = GetPendingActiveCreatedNotesByContentQuery(note, start_sura, start_ayah, end_sura, end_ayah) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getString(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!
    )
  }

  public fun getPendingActiveCreatedNotesByContent(
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
  ): Query<Note> = getPendingActiveCreatedNotesByContent(note, start_sura, start_ayah, end_sura, end_ayah, ::Note)

  public fun <T : Any> getLastInsertedNote(mapper: (
    local_id: Long,
    remote_id: String?,
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(-1_343_446_453, arrayOf("note"), driver, "notes.sq", "getLastInsertedNote", "SELECT note.local_id, note.remote_id, note.note, note.start_sura, note.start_ayah, note.end_sura, note.end_ayah, note.created_at, note.modified_at, note.deleted, note.is_edited, note.pending_version FROM note WHERE local_id = last_insert_rowid() LIMIT 1") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getString(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!
    )
  }

  public fun getLastInsertedNote(): Query<Note> = getLastInsertedNote(::Note)

  public fun <T : Any> getUnsyncedNotes(mapper: (
    local_id: Long,
    remote_id: String?,
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(637_818_531, arrayOf("note"), driver, "notes.sq", "getUnsyncedNotes", """
  |SELECT note.local_id, note.remote_id, note.note, note.start_sura, note.start_ayah, note.end_sura, note.end_ayah, note.created_at, note.modified_at, note.deleted, note.is_edited, note.pending_version FROM note
  |  WHERE (remote_id IS NULL AND deleted = 0)
  |    OR (remote_id IS NOT NULL AND deleted = 1)
  |    OR is_edited = 1
  |  ORDER BY created_at DESC
  """.trimMargin()) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getString(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!
    )
  }

  public fun getUnsyncedNotes(): Query<Note> = getUnsyncedNotes(::Note)

  public fun <T : Any> checkRemoteIDsExistence(queried_ids: Collection<String?>, mapper: (remote_id: String?) -> T): Query<T> = CheckRemoteIDsExistenceQuery(queried_ids) { cursor ->
    mapper(
      cursor.getString(0)
    )
  }

  public fun checkRemoteIDsExistence(queried_ids: Collection<String?>): Query<CheckRemoteIDsExistence> = checkRemoteIDsExistence(queried_ids, ::CheckRemoteIDsExistence)

  /**
   * @return The number of rows updated.
   */
  public fun addNewNote(
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    timestamp: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-2_022_115_780, """
        |INSERT INTO note (
        |    remote_id,
        |    note,
        |    start_sura,
        |    start_ayah,
        |    end_sura,
        |    end_ayah,
        |    created_at,
        |    modified_at,
        |    deleted,
        |    pending_version
        |  )
        |  VALUES (
        |    NULL,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    0,
        |    1
        |  )
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, note)
          bindLong(parameterIndex++, start_sura)
          bindLong(parameterIndex++, start_ayah)
          bindLong(parameterIndex++, end_sura)
          bindLong(parameterIndex++, end_ayah)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, timestamp)
        }
    notifyQueries(-2_022_115_780) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertImportedNote(
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-365_364_262, """
        |INSERT INTO note (
        |    remote_id,
        |    note,
        |    start_sura,
        |    start_ayah,
        |    end_sura,
        |    end_ayah,
        |    created_at,
        |    modified_at,
        |    deleted,
        |    is_edited,
        |    pending_version
        |  )
        |  VALUES (
        |    NULL,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    0,
        |    0,
        |    1
        |  )
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, note)
          bindLong(parameterIndex++, start_sura)
          bindLong(parameterIndex++, start_ayah)
          bindLong(parameterIndex++, end_sura)
          bindLong(parameterIndex++, end_ayah)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(-365_364_262) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateNote(
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    timestamp: Long,
    id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-1_776_521_018, """
        |UPDATE note
        |  SET note = ?,
        |    start_sura = ?,
        |    start_ayah = ?,
        |    end_sura = ?,
        |    end_ayah = ?,
        |    deleted = 0,
        |    is_edited = CASE WHEN remote_id IS NULL THEN 0 ELSE 1 END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE local_id = ?
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, note)
          bindLong(parameterIndex++, start_sura)
          bindLong(parameterIndex++, start_ayah)
          bindLong(parameterIndex++, end_sura)
          bindLong(parameterIndex++, end_ayah)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, id)
        }
    notifyQueries(-1_776_521_018) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun attachRemoteNoteIdForCreatedAck(
    remote_id: String?,
    pending_version: Long,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-957_952_505, """
        |UPDATE note
        |  SET remote_id = ?,
        |    is_edited = CASE
        |      WHEN deleted = 1 THEN is_edited
        |      WHEN pending_version = ? THEN 0
        |      ELSE 1
        |    END,
        |    modified_at = CASE
        |      WHEN pending_version = ? THEN ?
        |      ELSE modified_at
        |    END
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-957_952_505) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun attachRemoteNoteIdForSemanticReplay(
    remote_id: String?,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_628_837_843, """
        |UPDATE note
        |  SET remote_id = ?,
        |    is_edited = CASE
        |      WHEN deleted = 1 THEN is_edited
        |      ELSE 0
        |    END,
        |    modified_at = CASE
        |      WHEN deleted = 1 THEN modified_at
        |      ELSE ?
        |    END
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_628_837_843) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteRemoteNote(remote_id: String?): QueryResult<Long> {
    val result = driver.execute(null, """DELETE FROM note WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
        }
    notifyQueries(854_422_926) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(1_394_621_995, """DELETE FROM note""", 0)
    notifyQueries(1_394_621_995) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markUnsyncedNotesDeletedForImport(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(117_865_323, """
        |UPDATE note
        |  SET deleted = 1,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE remote_id IS NULL
        |    AND deleted = 0
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(117_865_323) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markRemoteNotesDeleted(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(-1_857_191_146, """
        |UPDATE note
        |  SET deleted = 1,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE remote_id IS NOT NULL
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(-1_857_191_146) { emit ->
      emit("note")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteNote(timestamp: Long, id: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(-1_954_480_551, """
        |UPDATE note
        |  SET deleted = 1,
        |    is_edited = CASE WHEN remote_id IS NULL THEN is_edited ELSE 1 END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE local_id = ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, id)
        }
  }.also {
    notifyQueries(283_999_400) { emit ->
      emit("note")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun persistRemoteNote(
    remote_id: String?,
    note: String,
    start_sura: Long,
    start_ayah: Long,
    end_sura: Long,
    end_ayah: Long,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(null, """
        |INSERT INTO note (
        |    remote_id, note, start_sura, start_ayah, end_sura, end_ayah, created_at, modified_at, deleted, is_edited
        |  )
        |  SELECT ?, ?, ?, ?, ?, ?, ?, ?, 0, 0
        |  WHERE NOT EXISTS (
        |    SELECT 1 FROM note WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?
        |  )
        """.trimMargin(), 9) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, note)
          bindLong(parameterIndex++, start_sura)
          bindLong(parameterIndex++, start_ayah)
          bindLong(parameterIndex++, end_sura)
          bindLong(parameterIndex++, end_ayah)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
          bindString(parameterIndex++, remote_id)
        }
    driver.execute(null, """
        |UPDATE note
        |  SET note = ?,
        |    start_sura = ?,
        |    start_ayah = ?,
        |    end_sura = ?,
        |    end_ayah = ?,
        |    modified_at = ?,
        |    deleted = 0,
        |    is_edited = 0
        |  WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?
        |    AND deleted = 0
        |    AND is_edited = 0
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, note)
          bindLong(parameterIndex++, start_sura)
          bindLong(parameterIndex++, start_ayah)
          bindLong(parameterIndex++, end_sura)
          bindLong(parameterIndex++, end_ayah)
          bindLong(parameterIndex++, modified_at)
          bindString(parameterIndex++, remote_id)
        }
  }.also {
    notifyQueries(-647_493_759) { emit ->
      emit("note")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearLocalMutationFor(
    id: Long,
    pending_version: Long,
    pending_op: String,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-160_481_784, """
        |DELETE FROM note
        |  WHERE remote_id IS NULL
        |    AND local_id = ?
        |    AND pending_version = ?
        |    AND ? = 'CREATED'
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
    driver.execute(-160_481_783, """
        |DELETE FROM note
        |  WHERE local_id = ?
        |    AND deleted = 1
        |    AND pending_version = ?
        |    AND ? = 'DELETED'
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
    driver.execute(-160_481_782, """
        |UPDATE note
        |  SET deleted = 0,
        |    is_edited = 0,
        |    modified_at = ?
        |  WHERE local_id = ?
        |    AND remote_id IS NOT NULL
        |    AND deleted = 0
        |    AND is_edited = 1
        |    AND pending_version = ?
        |    AND ? = 'MODIFIED'
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
  }.also {
    notifyQueries(1_014_357_015) { emit ->
      emit("note")
    }
  }

  private inner class GetNoteByLocalIdQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-2_109_053_390, """SELECT note.local_id, note.remote_id, note.note, note.start_sura, note.start_ayah, note.end_sura, note.end_ayah, note.created_at, note.modified_at, note.deleted, note.is_edited, note.pending_version FROM note WHERE local_id = ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "notes.sq:getNoteByLocalId"
  }

  private inner class GetNoteByRemoteIdQuery<out T : Any>(
    public val remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT note.local_id, note.remote_id, note.note, note.start_sura, note.start_ayah, note.end_sura, note.end_ayah, note.created_at, note.modified_at, note.deleted, note.is_edited, note.pending_version FROM note WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, remote_id)
    }

    override fun toString(): String = "notes.sq:getNoteByRemoteId"
  }

  private inner class GetPendingDeletedCreatedNotesByContentQuery<out T : Any>(
    public val note: String,
    public val start_sura: Long,
    public val start_ayah: Long,
    public val end_sura: Long,
    public val end_ayah: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(2_103_695_548, """
    |SELECT note.local_id, note.remote_id, note.note, note.start_sura, note.start_ayah, note.end_sura, note.end_ayah, note.created_at, note.modified_at, note.deleted, note.is_edited, note.pending_version FROM note
    |  WHERE remote_id IS NULL
    |    AND deleted = 1
    |    AND note = ?
    |    AND start_sura = ?
    |    AND start_ayah = ?
    |    AND end_sura = ?
    |    AND end_ayah = ?
    """.trimMargin(), mapper, 5) {
      var parameterIndex = 0
      bindString(parameterIndex++, note)
      bindLong(parameterIndex++, start_sura)
      bindLong(parameterIndex++, start_ayah)
      bindLong(parameterIndex++, end_sura)
      bindLong(parameterIndex++, end_ayah)
    }

    override fun toString(): String = "notes.sq:getPendingDeletedCreatedNotesByContent"
  }

  private inner class GetPendingActiveCreatedNotesByContentQuery<out T : Any>(
    public val note: String,
    public val start_sura: Long,
    public val start_ayah: Long,
    public val end_sura: Long,
    public val end_ayah: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_011_958_423, """
    |SELECT note.local_id, note.remote_id, note.note, note.start_sura, note.start_ayah, note.end_sura, note.end_ayah, note.created_at, note.modified_at, note.deleted, note.is_edited, note.pending_version FROM note
    |  WHERE remote_id IS NULL
    |    AND deleted = 0
    |    AND note = ?
    |    AND start_sura = ?
    |    AND start_ayah = ?
    |    AND end_sura = ?
    |    AND end_ayah = ?
    """.trimMargin(), mapper, 5) {
      var parameterIndex = 0
      bindString(parameterIndex++, note)
      bindLong(parameterIndex++, start_sura)
      bindLong(parameterIndex++, start_ayah)
      bindLong(parameterIndex++, end_sura)
      bindLong(parameterIndex++, end_ayah)
    }

    override fun toString(): String = "notes.sq:getPendingActiveCreatedNotesByContent"
  }

  private inner class CheckRemoteIDsExistenceQuery<out T : Any>(
    public val queried_ids: Collection<String?>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("note", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("note", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val queried_idsIndexes = createArguments(count = queried_ids.size)
      return driver.executeQuery(null, """SELECT remote_id FROM note WHERE remote_id IN $queried_idsIndexes""", mapper, queried_ids.size) {
            var parameterIndex = 0
            queried_ids.forEach { queried_ids_ ->
              bindString(parameterIndex++, queried_ids_)
            }
          }
    }

    override fun toString(): String = "notes.sq:checkRemoteIDsExistence"
  }
}
