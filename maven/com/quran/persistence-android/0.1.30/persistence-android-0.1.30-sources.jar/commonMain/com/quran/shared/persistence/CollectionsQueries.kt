@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import com.quran.shared.persistence.collections.CheckRemoteIDsExistence
import com.quran.shared.persistence.model.CollectionName
import com.quran.shared.persistence.model.CollectionNameKey
import kotlin.Any
import kotlin.Long
import kotlin.String

public class CollectionsQueries(
  driver: SqlDriver,
  private val collectionAdapter: Collection.Adapter,
) : TransacterImpl(driver) {
  public fun <T : Any> getCollections(mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(1_458_637_854, arrayOf("collection"), driver, "collections.sq", "getCollections", "SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection WHERE deleted = 0 ORDER BY created_at DESC") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getCollections(): Query<Collection> = getCollections(::Collection)

  public fun countAll(): Query<Long> = Query(-1_445_724_911, arrayOf("collection"), driver, "collections.sq", "countAll", "SELECT COUNT(*) FROM collection") { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> getCollectionByName(name_key: CollectionNameKey, mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetCollectionByNameQuery(name_key) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getCollectionByName(name_key: CollectionNameKey): Query<Collection> = getCollectionByName(name_key, ::Collection)

  public fun <T : Any> getPendingCreatedCollectionsByName(name_key: CollectionNameKey, mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetPendingCreatedCollectionsByNameQuery(name_key) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getPendingCreatedCollectionsByName(name_key: CollectionNameKey): Query<Collection> = getPendingCreatedCollectionsByName(name_key, ::Collection)

  public fun <T : Any> getPendingDeletedCreatedCollectionsByName(name_key: CollectionNameKey, mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetPendingDeletedCreatedCollectionsByNameQuery(name_key) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getPendingDeletedCreatedCollectionsByName(name_key: CollectionNameKey): Query<Collection> = getPendingDeletedCreatedCollectionsByName(name_key, ::Collection)

  public fun <T : Any> getPendingActiveCreatedCollectionsByName(name_key: CollectionNameKey, mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetPendingActiveCreatedCollectionsByNameQuery(name_key) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getPendingActiveCreatedCollectionsByName(name_key: CollectionNameKey): Query<Collection> = getPendingActiveCreatedCollectionsByName(name_key, ::Collection)

  public fun <T : Any> getCollectionByLocalId(local_id: Long, mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetCollectionByLocalIdQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getCollectionByLocalId(local_id: Long): Query<Collection> = getCollectionByLocalId(local_id, ::Collection)

  public fun <T : Any> getCollectionByRemoteId(remote_id: String?, mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetCollectionByRemoteIdQuery(remote_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getCollectionByRemoteId(remote_id: String?): Query<Collection> = getCollectionByRemoteId(remote_id, ::Collection)

  public fun <T : Any> getDefaultCollection(mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(-1_480_892_536, arrayOf("collection"), driver, "collections.sq", "getDefaultCollection", "SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection WHERE is_default = 1 AND deleted = 0 LIMIT 1") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getDefaultCollection(): Query<Collection> = getDefaultCollection(::Collection)

  public fun <T : Any> getUnsyncedCollections(mapper: (
    local_id: Long,
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    is_edited: Long,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(2_124_764_363, arrayOf("collection"), driver, "collections.sq", "getUnsyncedCollections", """
  |SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection
  |  WHERE (remote_id IS NULL AND deleted = 0 AND pending_version > 0)
  |    OR (remote_id IS NOT NULL AND deleted = 1)
  |    OR is_edited = 1
  |  ORDER BY created_at DESC
  """.trimMargin()) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      collectionAdapter.nameAdapter.decode(cursor.getString(2)!!),
      collectionAdapter.name_keyAdapter.decode(cursor.getString(3)!!),
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getUnsyncedCollections(): Query<Collection> = getUnsyncedCollections(::Collection)

  public fun <T : Any> checkRemoteIDsExistence(queried_ids: kotlin.collections.Collection<String?>, mapper: (remote_id: String?) -> T): Query<T> = CheckRemoteIDsExistenceQuery(queried_ids) { cursor ->
    mapper(
      cursor.getString(0)
    )
  }

  public fun checkRemoteIDsExistence(queried_ids: kotlin.collections.Collection<String?>): Query<CheckRemoteIDsExistence> = checkRemoteIDsExistence(queried_ids, ::CheckRemoteIDsExistence)

  /**
   * @return The number of rows updated.
   */
  public fun keepEarliestUnsyncedCreatedAt(timestamp: Long, local_id: Long): QueryResult<Long> {
    val result = driver.execute(1_032_587_121, """
        |UPDATE collection
        |  SET created_at = ?
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        |    AND created_at > ?
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, local_id)
          bindLong(parameterIndex++, timestamp)
        }
    notifyQueries(1_032_587_121) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateCollectionName(
    name: CollectionName,
    name_key: CollectionNameKey,
    timestamp: Long,
    id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_526_670_321, """
        |UPDATE collection
        |  SET name = ?,
        |    name_key = ?,
        |    is_edited = CASE WHEN remote_id IS NULL THEN is_edited ELSE 1 END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE local_id = ?
        |    AND deleted = 0
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, id)
        }
    notifyQueries(1_526_670_321) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun persistRemoteCollection(
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
    is_default: Long,
    is_system: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-1_700_339_559, """
        |INSERT INTO collection (
        |    remote_id, name, name_key, created_at, modified_at, deleted, is_edited, is_default, is_system
        |  )
        |  VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?)
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, is_default)
          bindLong(parameterIndex++, is_system)
        }
    notifyQueries(-1_700_339_559) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateRemoteCollection(
    name: CollectionName,
    name_key: CollectionNameKey,
    modified_at: Long,
    is_default: Long,
    is_system: Long,
    remote_id: String?,
  ): QueryResult<Long> {
    val result = driver.execute(null, """
        |UPDATE collection
        |  SET name = CASE WHEN is_system = 1 THEN name ELSE ? END,
        |    name_key = CASE WHEN is_system = 1 THEN name_key ELSE ? END,
        |    modified_at = ?,
        |    deleted = 0,
        |    is_edited = 0,
        |    is_default = CASE WHEN is_system = 1 THEN is_default ELSE ? END,
        |    is_system = CASE WHEN is_system = 1 THEN 1 ELSE ? END
        |  WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?
        |    AND deleted = 0
        |    AND is_edited = 0
        """.trimMargin(), 6) {
          var parameterIndex = 0
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, is_default)
          bindLong(parameterIndex++, is_system)
          bindString(parameterIndex++, remote_id)
        }
    notifyQueries(-724_328_660) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateRemoteCollectionByLocalId(
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    modified_at: Long,
    is_default: Long,
    is_system: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_290_131_395, """
        |UPDATE collection
        |  SET remote_id = ?,
        |    name = CASE WHEN is_system = 1 THEN name ELSE ? END,
        |    name_key = CASE WHEN is_system = 1 THEN name_key ELSE ? END,
        |    modified_at = ?,
        |    deleted = 0,
        |    is_edited = 0,
        |    is_default = CASE WHEN is_system = 1 THEN is_default ELSE ? END,
        |    is_system = CASE WHEN is_system = 1 THEN 1 ELSE ? END
        |  WHERE local_id = ?
        |    AND deleted = 0
        |    AND is_edited = 0
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, is_default)
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_290_131_395) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun attachRemoteCollectionIdForCreatedAck(
    remote_id: String?,
    is_default: Long,
    is_system: Long,
    pending_version: Long,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_504_802_567, """
        |UPDATE collection
        |  SET remote_id = ?,
        |    is_default = CASE WHEN is_system = 1 THEN is_default ELSE ? END,
        |    is_system = CASE WHEN is_system = 1 THEN 1 ELSE ? END,
        |    is_edited = CASE
        |      WHEN deleted = 1 THEN is_edited
        |      WHEN pending_version = ? THEN 0
        |      ELSE 1
        |    END,
        |    modified_at = CASE
        |      WHEN pending_version = ? THEN ?
        |      ELSE modified_at
        |    END
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, is_default)
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_504_802_567) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun attachRemoteCollectionIdForSemanticReplay(
    remote_id: String?,
    name: CollectionName,
    name_key: CollectionNameKey,
    is_default: Long,
    is_system: Long,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-865_845_037, """
        |UPDATE collection
        |  SET remote_id = ?,
        |    name = CASE WHEN is_system = 1 THEN name ELSE ? END,
        |    name_key = CASE WHEN is_system = 1 THEN name_key ELSE ? END,
        |    is_default = CASE WHEN is_system = 1 THEN is_default ELSE ? END,
        |    is_system = CASE WHEN is_system = 1 THEN 1 ELSE ? END,
        |    is_edited = CASE
        |      WHEN deleted = 1 THEN is_edited
        |      ELSE 0
        |    END,
        |    modified_at = CASE
        |      WHEN deleted = 1 THEN modified_at
        |      ELSE ?
        |    END
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
          bindLong(parameterIndex++, is_default)
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-865_845_037) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(717_249_751, """DELETE FROM collection""", 0)
    notifyQueries(717_249_751) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markUnsyncedCollectionsDeletedForImport(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(-1_668_505_557, """
        |UPDATE collection
        |  SET deleted = 1,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE remote_id IS NULL
        |    AND is_system = 0
        |    AND deleted = 0
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(-1_668_505_557) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markRemoteCollectionsDeleted(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(1_674_512_662, """
        |UPDATE collection
        |  SET deleted = 1,
        |    is_edited = 1,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE remote_id IS NOT NULL
        |    AND is_system = 0
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(1_674_512_662) { emit ->
      emit("collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun seedSystemCollections(): QueryResult<Long> = transactionWithResult {
    driver.execute(546_546_439, """
        |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
        |  VALUES ('Favorites', 'favorites', 1, 1)
        """.trimMargin(), 0)
    driver.execute(546_546_440, """
        |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
        |  VALUES ('system:highlights:blue', 'system:highlights:blue', 0, 1)
        """.trimMargin(), 0)
    driver.execute(546_546_441, """
        |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
        |  VALUES ('system:highlights:pink', 'system:highlights:pink', 0, 1)
        """.trimMargin(), 0)
    driver.execute(546_546_442, """
        |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
        |  VALUES ('system:highlights:green', 'system:highlights:green', 0, 1)
        """.trimMargin(), 0)
    driver.execute(546_546_443, """
        |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
        |  VALUES ('system:highlights:yellow', 'system:highlights:yellow', 0, 1)
        """.trimMargin(), 0)
    driver.execute(546_546_444, """
        |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
        |  VALUES ('system:highlights:purple', 'system:highlights:purple', 0, 1)
        """.trimMargin(), 0)
  }.also {
    notifyQueries(840_791_254) { emit ->
      emit("collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun addNewCollection(
    is_system: Long,
    timestamp: Long,
    name_key: CollectionNameKey,
    name: CollectionName,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-555_382_291, """
        |UPDATE collection
        |  SET deleted = 0,
        |    is_system = ?,
        |    is_edited = CASE
        |      WHEN remote_id IS NULL THEN 0
        |      WHEN deleted = 1 THEN 1
        |      ELSE is_edited
        |    END,
        |    modified_at = ?,
        |    pending_version = CASE
        |      WHEN remote_id IS NULL OR deleted = 1 OR is_edited = 1 THEN pending_version + 1
        |      ELSE pending_version
        |    END
        |  WHERE name_key = ?
        |    AND deleted = 0
        |    AND (is_system = 0 OR ? = 1)
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, timestamp)
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
          bindLong(parameterIndex++, is_system)
        }
    driver.execute(-555_382_290, """
        |UPDATE collection
        |  SET deleted = 0,
        |    name = ?,
        |    is_system = ?,
        |    is_edited = CASE
        |      WHEN remote_id IS NULL THEN 0
        |      ELSE 1
        |    END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE local_id = (
        |    SELECT local_id FROM collection
        |    WHERE name_key = ?
        |      AND deleted = 1
        |      AND (is_system = 0 OR ? = 1)
        |      AND NOT EXISTS (
        |        SELECT 1 FROM collection AS active
        |        WHERE active.name_key = ?
        |          AND active.deleted = 0
        |      )
        |    ORDER BY modified_at DESC, local_id DESC
        |    LIMIT 1
        |  )
        """.trimMargin(), 6) {
          val name_key_ = collectionAdapter.name_keyAdapter.encode(name_key)
          var parameterIndex = 0
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindLong(parameterIndex++, is_system)
          bindLong(parameterIndex++, timestamp)
          bindString(parameterIndex++, name_key_)
          bindLong(parameterIndex++, is_system)
          bindString(parameterIndex++, name_key_)
        }
    driver.execute(-555_382_289, """
        |INSERT OR IGNORE INTO collection (
        |    remote_id, name, name_key, created_at, modified_at, deleted, is_edited, is_default, is_system, pending_version
        |  )
        |  SELECT
        |    NULL,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    0,
        |    0,
        |    0,
        |    ?,
        |    1
        |  WHERE NOT EXISTS (
        |    SELECT 1 FROM collection
        |    WHERE name_key = ?
        |      AND deleted = 0
        |  )
        """.trimMargin(), 6) {
          val name_key_ = collectionAdapter.name_keyAdapter.encode(name_key)
          var parameterIndex = 0
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindString(parameterIndex++, name_key_)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, is_system)
          bindString(parameterIndex++, name_key_)
        }
  }.also {
    notifyQueries(-1_721_246_404) { emit ->
      emit("collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertImportedCollection(
    name: CollectionName,
    name_key: CollectionNameKey,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(1_744_240_011, """
        |INSERT OR IGNORE INTO collection (
        |    remote_id,
        |    name,
        |    name_key,
        |    created_at,
        |    modified_at,
        |    deleted,
        |    is_edited,
        |    pending_version
        |  )
        |  VALUES (
        |    NULL,
        |    ?,
        |    ?,
        |    ?,
        |    ?,
        |    0,
        |    0,
        |    0
        |  )
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindString(parameterIndex++, collectionAdapter.nameAdapter.encode(name))
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(1_744_240_012, """
        |UPDATE collection
        |  SET deleted = 0,
        |    is_edited = CASE
        |      WHEN remote_id IS NULL THEN 0
        |      WHEN deleted = 1 THEN 0
        |      ELSE is_edited
        |    END,
        |    modified_at = CASE
        |      WHEN remote_id IS NULL THEN ?
        |      WHEN deleted = 1 THEN ?
        |      ELSE modified_at
        |    END,
        |    pending_version = CASE
        |      WHEN remote_id IS NULL OR deleted = 1 THEN pending_version + 1
        |      ELSE pending_version
        |    END
        |  WHERE name_key = ?
        |    AND deleted = 0
        |    AND is_system = 0
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
        }
  }.also {
    notifyQueries(685_613_146) { emit ->
      emit("collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteCollection(id: Long, timestamp: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(324_199_513, """
        |DELETE FROM bookmark_collection
        |  WHERE collection_local_id = ?
        |    AND last_synced_bookmark_remote_id IS NULL
        |    AND last_synced_collection_remote_id IS NULL
        |    AND (pending_op IS NULL OR pending_op != 'CREATED' OR pending_version <= 1)
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
        }
    driver.execute(324_199_514, """
        |UPDATE bookmark_collection
        |  SET is_active = 0,
        |    pending_op = 'DELETED',
        |    pending_version = CASE WHEN pending_op = 'DELETED' THEN pending_version ELSE pending_version + 1 END,
        |    modified_at = ?
        |  WHERE collection_local_id = ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, id)
        }
    driver.execute(324_199_515, """
        |UPDATE collection
        |  SET deleted = 1,
        |    is_edited = CASE WHEN remote_id IS NULL THEN is_edited ELSE 1 END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE local_id = ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, id)
        }
  }.also {
    notifyQueries(268_493_480) { emit ->
      emit("bookmark_collection")
      emit("collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteRemoteCollection(remote_id: String?): QueryResult<Long> = transactionWithResult {
    driver.execute(null, """
        |DELETE FROM bookmark_collection WHERE collection_local_id IN (
        |    SELECT local_id FROM collection WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?
        |  )
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
        }
    driver.execute(null, """DELETE FROM collection WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
        }
  }.also {
    notifyQueries(-820_516_850) { emit ->
      emit("bookmark_collection")
      emit("collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearLocalMutationFor(
    id: Long,
    pending_version: Long,
    pending_op: String,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(200_163_252, """
        |DELETE FROM bookmark_collection
        |  WHERE collection_local_id IN (
        |    SELECT local_id FROM collection
        |    WHERE local_id = ?
        |      AND deleted = 1
        |      AND pending_version = ?
        |      AND ? = 'DELETED'
        |  )
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
    driver.execute(200_163_253, """
        |DELETE FROM collection
        |  WHERE local_id = ?
        |    AND deleted = 1
        |    AND pending_version = ?
        |    AND ? = 'DELETED'
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
    driver.execute(200_163_254, """
        |UPDATE collection
        |  SET deleted = 0,
        |    is_edited = 0,
        |    modified_at = ?
        |  WHERE local_id = ?
        |    AND pending_version = ?
        |    AND (
        |      (? = 'CREATED' AND remote_id IS NULL)
        |      OR (? = 'MODIFIED' AND remote_id IS NOT NULL AND deleted = 0 AND is_edited = 1)
        |    )
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
          bindString(parameterIndex++, pending_op)
        }
  }.also {
    notifyQueries(1_054_955_715) { emit ->
      emit("bookmark_collection")
      emit("collection")
    }
  }

  private inner class GetCollectionByNameQuery<out T : Any>(
    public val name_key: CollectionNameKey,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_204_262_185, """SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection WHERE name_key = ? AND deleted = 0 LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
    }

    override fun toString(): String = "collections.sq:getCollectionByName"
  }

  private inner class GetPendingCreatedCollectionsByNameQuery<out T : Any>(
    public val name_key: CollectionNameKey,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-287_075_281, """
    |SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection
    |  WHERE remote_id IS NULL
    |    AND name_key = ?
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
    }

    override fun toString(): String = "collections.sq:getPendingCreatedCollectionsByName"
  }

  private inner class GetPendingDeletedCreatedCollectionsByNameQuery<out T : Any>(
    public val name_key: CollectionNameKey,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_227_074_584, """
    |SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection
    |  WHERE remote_id IS NULL
    |    AND deleted = 1
    |    AND name_key = ?
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
    }

    override fun toString(): String = "collections.sq:getPendingDeletedCreatedCollectionsByName"
  }

  private inner class GetPendingActiveCreatedCollectionsByNameQuery<out T : Any>(
    public val name_key: CollectionNameKey,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_419_408_725, """
    |SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection
    |  WHERE remote_id IS NULL
    |    AND deleted = 0
    |    AND name_key = ?
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, collectionAdapter.name_keyAdapter.encode(name_key))
    }

    override fun toString(): String = "collections.sq:getPendingActiveCreatedCollectionsByName"
  }

  private inner class GetCollectionByLocalIdQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_696_377_318, """SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection WHERE local_id = ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "collections.sq:getCollectionByLocalId"
  }

  private inner class GetCollectionByRemoteIdQuery<out T : Any>(
    public val remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT collection.local_id, collection.remote_id, collection.name, collection.name_key, collection.created_at, collection.modified_at, collection.deleted, collection.is_edited, collection.is_default, collection.is_system, collection.pending_version FROM collection WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, remote_id)
    }

    override fun toString(): String = "collections.sq:getCollectionByRemoteId"
  }

  private inner class CheckRemoteIDsExistenceQuery<out T : Any>(
    public val queried_ids: kotlin.collections.Collection<String?>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val queried_idsIndexes = createArguments(count = queried_ids.size)
      return driver.executeQuery(null, """SELECT remote_id FROM collection WHERE remote_id IN $queried_idsIndexes""", mapper, queried_ids.size) {
            var parameterIndex = 0
            queried_ids.forEach { queried_ids_ ->
              bindString(parameterIndex++, queried_ids_)
            }
          }
    }

    override fun toString(): String = "collections.sq:checkRemoteIDsExistence"
  }
}
