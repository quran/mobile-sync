@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence.bookmark_collections

import kotlin.String

public data class CheckRemoteIDsExistence(
  public val remote_id: String?,
)
