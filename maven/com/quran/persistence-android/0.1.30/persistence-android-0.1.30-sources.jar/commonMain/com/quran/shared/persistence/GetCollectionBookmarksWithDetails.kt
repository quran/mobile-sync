@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import com.quran.shared.persistence.model.CollectionName
import kotlin.Long
import kotlin.String

public data class GetCollectionBookmarksWithDetails(
  public val local_id: Long,
  public val bookmark_local_id: Long,
  public val collection_local_id: Long,
  public val is_active: Long,
  public val pending_op: String?,
  public val pending_version: Long,
  public val last_synced_bookmark_remote_id: String?,
  public val last_synced_collection_remote_id: String?,
  public val created_at: Long,
  public val modified_at: Long,
  public val collection_remote_id: String?,
  public val collection_name: CollectionName,
  public val bookmark_remote_id: String?,
  public val sura: Long,
  public val ayah: Long,
  public val bookmark_last_updated_at: Long,
  public val bookmark_added_at: Long,
)
