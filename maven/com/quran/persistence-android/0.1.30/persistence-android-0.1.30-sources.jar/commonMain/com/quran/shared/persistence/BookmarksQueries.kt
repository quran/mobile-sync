@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import com.quran.shared.persistence.bookmarks.CheckRemoteIDsExistence
import kotlin.Any
import kotlin.Long
import kotlin.String
import kotlin.collections.Collection

public class BookmarksQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun countAll(): Query<Long> = Query(-568_238_983, arrayOf("bookmark"), driver, "bookmarks.sq", "countAll", "SELECT COUNT(*) FROM bookmark") { cursor ->
    cursor.getLong(0)!!
  }

  public fun countActive(): Query<Long> = Query(-1_949_397_714, arrayOf("bookmark"), driver, "bookmarks.sq", "countActive", "SELECT COUNT(*) FROM bookmark WHERE deleted = 0") { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> getBookmarkForAyah(
    sura: Long,
    ayah: Long,
    mapper: (
      local_id: Long,
      remote_id: String?,
      sura: Long,
      ayah: Long,
      mushaf_id: Long,
      deleted: Long,
      bookmark_pending_op: String?,
      bookmark_pending_version: Long,
      created_at: Long,
      modified_at: Long,
      bookmark_modified_at: Long,
    ) -> T,
  ): Query<T> = GetBookmarkForAyahQuery(sura, ayah) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getBookmarkForAyah(sura: Long, ayah: Long): Query<Bookmark> = getBookmarkForAyah(sura, ayah, ::Bookmark)

  public fun <T : Any> getBookmarkByLocalId(local_id: Long, mapper: (
    local_id: Long,
    remote_id: String?,
    sura: Long,
    ayah: Long,
    mushaf_id: Long,
    deleted: Long,
    bookmark_pending_op: String?,
    bookmark_pending_version: Long,
    created_at: Long,
    modified_at: Long,
    bookmark_modified_at: Long,
  ) -> T): Query<T> = GetBookmarkByLocalIdQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getBookmarkByLocalId(local_id: Long): Query<Bookmark> = getBookmarkByLocalId(local_id, ::Bookmark)

  public fun <T : Any> getBookmarkByRemoteId(remote_id: String?, mapper: (
    local_id: Long,
    remote_id: String?,
    sura: Long,
    ayah: Long,
    mushaf_id: Long,
    deleted: Long,
    bookmark_pending_op: String?,
    bookmark_pending_version: Long,
    created_at: Long,
    modified_at: Long,
    bookmark_modified_at: Long,
  ) -> T): Query<T> = GetBookmarkByRemoteIdQuery(remote_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getBookmarkByRemoteId(remote_id: String?): Query<Bookmark> = getBookmarkByRemoteId(remote_id, ::Bookmark)

  public fun <T : Any> getUnsyncedBookmarkRows(mapper: (
    local_id: Long,
    remote_id: String?,
    sura: Long,
    ayah: Long,
    mushaf_id: Long,
    deleted: Long,
    bookmark_pending_op: String,
    bookmark_pending_version: Long,
    created_at: Long,
    modified_at: Long,
    bookmark_modified_at: Long,
  ) -> T): Query<T> = Query(897_100_625, arrayOf("bookmark"), driver, "bookmarks.sq", "getUnsyncedBookmarkRows", """
  |SELECT bookmark.local_id, bookmark.remote_id, bookmark.sura, bookmark.ayah, bookmark.mushaf_id, bookmark.deleted, bookmark.bookmark_pending_op, bookmark.bookmark_pending_version, bookmark.created_at, bookmark.modified_at, bookmark.bookmark_modified_at FROM bookmark
  |  WHERE bookmark_pending_op IS NOT NULL
  |    AND (bookmark_pending_op != 'DELETED' OR remote_id IS NOT NULL)
  |  ORDER BY modified_at DESC
  """.trimMargin()) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getLong(10)!!
    )
  }

  public fun getUnsyncedBookmarkRows(): Query<GetUnsyncedBookmarkRows> = getUnsyncedBookmarkRows(::GetUnsyncedBookmarkRows)

  public fun <T : Any> checkRemoteIDsExistence(queried_ids: Collection<String?>, mapper: (remote_id: String?) -> T): Query<T> = CheckRemoteIDsExistenceQuery(queried_ids) { cursor ->
    mapper(
      cursor.getString(0)
    )
  }

  public fun checkRemoteIDsExistence(queried_ids: Collection<String?>): Query<CheckRemoteIDsExistence> = checkRemoteIDsExistence(queried_ids, ::CheckRemoteIDsExistence)

  /**
   * @return The number of rows updated.
   */
  public fun clearBookmarkRemoteIdByLocalId(local_id: Long, remote_id: String?): QueryResult<Long> {
    val result = driver.execute(null, """
        |UPDATE bookmark SET remote_id = NULL
        |  WHERE local_id = ? AND remote_id ${ if (remote_id == null) "IS" else "=" } ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, remote_id)
        }
    notifyQueries(-831_551_150) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun attachRemoteBookmarkIdByLocalId(
    remote_id: String?,
    modified_at: Long?,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-1_900_530_580, """
        |UPDATE bookmark
        |  SET remote_id = ?,
        |    modified_at = MAX(modified_at, ?),
        |    bookmark_modified_at = MAX(bookmark_modified_at, ?)
        |  WHERE local_id = ? AND remote_id IS NULL
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-1_900_530_580) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun bindRemoteBookmarkIdPreservingTimestampsByLocalId(remote_id: String?, local_id: Long): QueryResult<Long> {
    val result = driver.execute(1_852_824_270, """
        |UPDATE bookmark
        |  SET remote_id = ?
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_852_824_270) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun reactivateDeletedBookmarkForActiveRemoteRelation(local_id: Long, remote_id: String?): QueryResult<Long> {
    val result = driver.execute(null, """
        |UPDATE bookmark
        |  SET deleted = 0
        |  WHERE local_id = ?
        |    AND remote_id ${ if (remote_id == null) "IS" else "=" } ?
        |    AND deleted = 1
        |    AND bookmark_pending_op IS NULL
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, remote_id)
        }
    notifyQueries(-959_095_505) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun touchBookmarkForFirstSavedMembership(modified_at: Long, local_id: Long): QueryResult<Long> {
    val result = driver.execute(-343_517_208, """
        |UPDATE bookmark
        |  SET modified_at = CASE
        |      WHEN modified_at > ? THEN modified_at
        |      ELSE ?
        |    END,
        |    bookmark_modified_at = CASE
        |      WHEN bookmark_modified_at > ? THEN bookmark_modified_at
        |      ELSE ?
        |    END
        |  WHERE local_id = ? AND deleted = 0
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-343_517_208) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markBookmarkDeleted(timestamp: Long, local_id: Long): QueryResult<Long> {
    val result = driver.execute(-756_848_977, """
        |UPDATE bookmark
        |  SET deleted = 1,
        |    bookmark_pending_op = 'DELETED',
        |    bookmark_pending_version = bookmark_pending_version + 1,
        |    modified_at = ?
        |  WHERE local_id = ? AND remote_id IS NOT NULL
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-756_848_977) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun hardDeleteBookmarkByLocalId(local_id: Long): QueryResult<Long> {
    val result = driver.execute(1_454_122_844, """DELETE FROM bookmark WHERE local_id = ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(1_454_122_844) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun hardDeleteBookmarkByRemoteId(remote_id: String?): QueryResult<Long> {
    val result = driver.execute(null, """DELETE FROM bookmark WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
        }
    notifyQueries(-285_521_589) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun applyRemoteBookmarkDeletedByLocalId(modified_at: Long, local_id: Long): QueryResult<Long> {
    val result = driver.execute(143_655_289, """
        |UPDATE bookmark
        |  SET deleted = 1,
        |    remote_id = NULL,
        |    bookmark_pending_op = NULL,
        |    modified_at = ?
        |  WHERE local_id = ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(143_655_289) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteLocalOrphanBookmarks(): QueryResult<Long> {
    val result = driver.execute(-581_331_876, """
        |DELETE FROM bookmark
        |  WHERE remote_id IS NULL
        |    AND deleted = 0
        |    AND bookmark_pending_op IS NULL
        |    AND NOT EXISTS (
        |      SELECT 1 FROM bookmark_collection bc
        |      WHERE bc.bookmark_local_id = bookmark.local_id
        |        AND (
        |          bc.is_active = 1
        |          OR bc.pending_op IS NOT NULL
        |          OR bc.last_synced_bookmark_remote_id IS NOT NULL
        |          OR bc.last_synced_collection_remote_id IS NOT NULL
        |        )
        |    )
        """.trimMargin(), 0)
    notifyQueries(-581_331_876) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearBookmarkPending(
    remote_id: String?,
    modified_at: Long?,
    local_id: Long,
    pending_op: String?,
    pending_version: Long,
  ): QueryResult<Long> {
    val result = driver.execute(null, """
        |UPDATE bookmark
        |  SET bookmark_pending_op = NULL,
        |    remote_id = CASE WHEN remote_id IS NULL THEN ? ELSE remote_id END,
        |    deleted = 0,
        |    modified_at = MAX(modified_at, ?),
        |    bookmark_modified_at = MAX(bookmark_modified_at, ?)
        |  WHERE local_id = ?
        |    AND bookmark_pending_op ${ if (pending_op == null) "IS" else "=" } ?
        |    AND bookmark_pending_version = ?
        """.trimMargin(), 6) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, pending_op)
          bindLong(parameterIndex++, pending_version)
        }
    notifyQueries(-1_667_864_229) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearBookmarkDeletePending(
    remote_id: String?,
    modified_at: Long?,
    local_id: Long,
    pending_op: String?,
    pending_version: Long,
  ): QueryResult<Long> {
    val result = driver.execute(null, """
        |UPDATE bookmark
        |  SET bookmark_pending_op = NULL,
        |    remote_id = CASE WHEN remote_id IS NULL THEN ? ELSE remote_id END,
        |    modified_at = MAX(modified_at, ?),
        |    bookmark_modified_at = MAX(bookmark_modified_at, ?)
        |  WHERE local_id = ?
        |    AND deleted = 1
        |    AND bookmark_pending_op ${ if (pending_op == null) "IS" else "=" } ?
        |    AND bookmark_pending_version = ?
        """.trimMargin(), 6) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, pending_op)
          bindLong(parameterIndex++, pending_version)
        }
    notifyQueries(-695_995_856) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markUnsyncedBookmarksDeletedForImport(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(1_313_088_107, """
        |UPDATE bookmark
        |  SET deleted = 1,
        |    bookmark_pending_op = CASE
        |      WHEN bookmark_pending_op IS NOT NULL THEN 'DELETED'
        |      ELSE bookmark_pending_op
        |    END,
        |    bookmark_pending_version = CASE
        |      WHEN bookmark_pending_op = 'DELETED' THEN bookmark_pending_version
        |      WHEN bookmark_pending_op IS NOT NULL THEN bookmark_pending_version + 1
        |      ELSE bookmark_pending_version
        |    END,
        |    modified_at = ?
        |  WHERE remote_id IS NULL AND deleted = 0
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(1_313_088_107) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markRemoteBookmarksDeleted(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(626_665_878, """
        |UPDATE bookmark
        |  SET deleted = 1,
        |    bookmark_pending_op = 'DELETED',
        |    bookmark_pending_version = bookmark_pending_version + 1,
        |    modified_at = ?
        |  WHERE remote_id IS NOT NULL
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(626_665_878) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(-2_145_457_553, """DELETE FROM bookmark""", 0)
    notifyQueries(-2_145_457_553) { emit ->
      emit("bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun upsertAyahBookmark(
    remote_id: String?,
    sura: Long,
    ayah: Long,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(554_341_916, """
        |INSERT OR IGNORE INTO bookmark (
        |    remote_id, sura, ayah, mushaf_id, deleted,
        |    created_at, modified_at, bookmark_modified_at
        |  ) VALUES (
        |    ?, ?, ?, 1, 0,
        |    ?, ?, ?
        |  )
        """.trimMargin(), 6) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(554_341_917, """
        |UPDATE bookmark
        |  SET remote_id = CASE WHEN ? IS NULL THEN remote_id ELSE ? END,
        |    deleted = CASE
        |      WHEN ? IS NOT NULL AND remote_id IS NULL
        |        AND deleted = 1 AND bookmark_pending_op = 'DELETED' THEN deleted
        |      ELSE 0
        |    END,
        |    bookmark_pending_op = CASE
        |      WHEN ? IS NOT NULL AND remote_id IS NULL
        |        AND deleted = 1 AND bookmark_pending_op = 'DELETED' THEN bookmark_pending_op
        |      WHEN ? IS NOT NULL THEN NULL
        |      WHEN bookmark_pending_op = 'DELETED' THEN NULL
        |      ELSE bookmark_pending_op
        |    END,
        |    bookmark_pending_version = CASE
        |      WHEN ? IS NULL AND bookmark_pending_op = 'DELETED' THEN bookmark_pending_version + 1
        |      ELSE bookmark_pending_version
        |    END,
        |    modified_at = ?,
        |    bookmark_modified_at = ?
        |  WHERE sura = ? AND ayah = ? AND mushaf_id = 1
        """.trimMargin(), 10) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
        }
  }.also {
    notifyQueries(2_087_725_355) { emit ->
      emit("bookmark")
    }
  }

  private inner class GetBookmarkForAyahQuery<out T : Any>(
    public val sura: Long,
    public val ayah: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-852_762_589, """
    |SELECT bookmark.local_id, bookmark.remote_id, bookmark.sura, bookmark.ayah, bookmark.mushaf_id, bookmark.deleted, bookmark.bookmark_pending_op, bookmark.bookmark_pending_version, bookmark.created_at, bookmark.modified_at, bookmark.bookmark_modified_at FROM bookmark
    |  WHERE sura = ? AND ayah = ? AND mushaf_id = 1
    |  LIMIT 1
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, sura)
      bindLong(parameterIndex++, ayah)
    }

    override fun toString(): String = "bookmarks.sq:getBookmarkForAyah"
  }

  private inner class GetBookmarkByLocalIdQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_653_251_114, """SELECT bookmark.local_id, bookmark.remote_id, bookmark.sura, bookmark.ayah, bookmark.mushaf_id, bookmark.deleted, bookmark.bookmark_pending_op, bookmark.bookmark_pending_version, bookmark.created_at, bookmark.modified_at, bookmark.bookmark_modified_at FROM bookmark WHERE local_id = ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "bookmarks.sq:getBookmarkByLocalId"
  }

  private inner class GetBookmarkByRemoteIdQuery<out T : Any>(
    public val remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT bookmark.local_id, bookmark.remote_id, bookmark.sura, bookmark.ayah, bookmark.mushaf_id, bookmark.deleted, bookmark.bookmark_pending_op, bookmark.bookmark_pending_version, bookmark.created_at, bookmark.modified_at, bookmark.bookmark_modified_at FROM bookmark WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, remote_id)
    }

    override fun toString(): String = "bookmarks.sq:getBookmarkByRemoteId"
  }

  private inner class CheckRemoteIDsExistenceQuery<out T : Any>(
    public val queried_ids: Collection<String?>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val queried_idsIndexes = createArguments(count = queried_ids.size)
      return driver.executeQuery(null, """SELECT remote_id FROM bookmark WHERE remote_id IN $queried_idsIndexes""", mapper, queried_ids.size) {
            var parameterIndex = 0
            queried_ids.forEach { queried_ids_ ->
              bindString(parameterIndex++, queried_ids_)
            }
          }
    }

    override fun toString(): String = "bookmarks.sq:checkRemoteIDsExistence"
  }
}
