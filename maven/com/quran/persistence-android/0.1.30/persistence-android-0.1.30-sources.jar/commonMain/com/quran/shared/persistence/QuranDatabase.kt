@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.quran.shared.persistence.persistence.newInstance
import com.quran.shared.persistence.persistence.schema
import kotlin.String
import kotlin.Unit
import kotlin.collections.List

public interface QuranDatabase : Transacter {
  public val bookmark_collectionsQueries: Bookmark_collectionsQueries

  public val bookmarksQueries: BookmarksQueries

  public val collectionsQueries: CollectionsQueries

  public val import_trackingQueries: Import_trackingQueries

  public val key_value_storeQueries: Key_value_storeQueries

  public val notesQueries: NotesQueries

  public val reading_bookmarksQueries: Reading_bookmarksQueries

  public val reading_sessionsQueries: Reading_sessionsQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = QuranDatabase::class.schema

    public operator fun invoke(driver: SqlDriver, collectionAdapter: Collection.Adapter): QuranDatabase = QuranDatabase::class.newInstance(driver, collectionAdapter)

    public fun allTableNames(): List<String> = listOf("bookmark", "bookmark_collection", "collection", "import_history", "key_value_store", "note", "reading_bookmark", "reading_session")
  }
}
