@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import com.quran.shared.persistence.reading_bookmarks.CheckRemoteIDsExistence
import kotlin.Any
import kotlin.Long
import kotlin.String
import kotlin.collections.Collection

public class Reading_bookmarksQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> getReadingBookmarks(mapper: (
    local_id: Long,
    remote_id: String?,
    slot: Long,
    name: String?,
    bookmark_type: String?,
    sura: Long?,
    ayah: Long?,
    page: Long?,
    mushaf_id: Long?,
    pending_op: String?,
    pending_version: Long,
    created_at: Long,
    modified_at: Long,
  ) -> T): Query<T> = Query(-2_027_513_133, arrayOf("reading_bookmark"), driver, "reading_bookmarks.sq", "getReadingBookmarks", "SELECT reading_bookmark.local_id, reading_bookmark.remote_id, reading_bookmark.slot, reading_bookmark.name, reading_bookmark.bookmark_type, reading_bookmark.sura, reading_bookmark.ayah, reading_bookmark.page, reading_bookmark.mushaf_id, reading_bookmark.pending_op, reading_bookmark.pending_version, reading_bookmark.created_at, reading_bookmark.modified_at FROM reading_bookmark ORDER BY slot") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getLong(5),
      cursor.getLong(6),
      cursor.getLong(7),
      cursor.getLong(8),
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12)!!
    )
  }

  public fun getReadingBookmarks(): Query<Reading_bookmark> = getReadingBookmarks(::Reading_bookmark)

  public fun <T : Any> getReadingBookmarkForSlot(slot: Long, mapper: (
    local_id: Long,
    remote_id: String?,
    slot: Long,
    name: String?,
    bookmark_type: String?,
    sura: Long?,
    ayah: Long?,
    page: Long?,
    mushaf_id: Long?,
    pending_op: String?,
    pending_version: Long,
    created_at: Long,
    modified_at: Long,
  ) -> T): Query<T> = GetReadingBookmarkForSlotQuery(slot) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getLong(5),
      cursor.getLong(6),
      cursor.getLong(7),
      cursor.getLong(8),
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12)!!
    )
  }

  public fun getReadingBookmarkForSlot(slot: Long): Query<Reading_bookmark> = getReadingBookmarkForSlot(slot, ::Reading_bookmark)

  public fun <T : Any> getReadingBookmarkByRemoteId(remote_id: String?, mapper: (
    local_id: Long,
    remote_id: String?,
    slot: Long,
    name: String?,
    bookmark_type: String?,
    sura: Long?,
    ayah: Long?,
    page: Long?,
    mushaf_id: Long?,
    pending_op: String?,
    pending_version: Long,
    created_at: Long,
    modified_at: Long,
  ) -> T): Query<T> = GetReadingBookmarkByRemoteIdQuery(remote_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getLong(5),
      cursor.getLong(6),
      cursor.getLong(7),
      cursor.getLong(8),
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12)!!
    )
  }

  public fun getReadingBookmarkByRemoteId(remote_id: String?): Query<Reading_bookmark> = getReadingBookmarkByRemoteId(remote_id, ::Reading_bookmark)

  public fun <T : Any> getUnsyncedReadingBookmarks(mapper: (
    local_id: Long,
    remote_id: String?,
    slot: Long,
    name: String?,
    bookmark_type: String?,
    sura: Long?,
    ayah: Long?,
    page: Long?,
    mushaf_id: Long?,
    pending_op: String,
    pending_version: Long,
    created_at: Long,
    modified_at: Long,
  ) -> T): Query<T> = Query(1_961_204_550, arrayOf("reading_bookmark"), driver, "reading_bookmarks.sq", "getUnsyncedReadingBookmarks", "SELECT reading_bookmark.local_id, reading_bookmark.remote_id, reading_bookmark.slot, reading_bookmark.name, reading_bookmark.bookmark_type, reading_bookmark.sura, reading_bookmark.ayah, reading_bookmark.page, reading_bookmark.mushaf_id, reading_bookmark.pending_op, reading_bookmark.pending_version, reading_bookmark.created_at, reading_bookmark.modified_at FROM reading_bookmark WHERE pending_op IS NOT NULL ORDER BY modified_at DESC") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getLong(5),
      cursor.getLong(6),
      cursor.getLong(7),
      cursor.getLong(8),
      cursor.getString(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12)!!
    )
  }

  public fun getUnsyncedReadingBookmarks(): Query<GetUnsyncedReadingBookmarks> = getUnsyncedReadingBookmarks(::GetUnsyncedReadingBookmarks)

  public fun <T : Any> checkRemoteIDsExistence(queried_ids: Collection<String?>, mapper: (remote_id: String?) -> T): Query<T> = CheckRemoteIDsExistenceQuery(queried_ids) { cursor ->
    mapper(
      cursor.getString(0)
    )
  }

  public fun checkRemoteIDsExistence(queried_ids: Collection<String?>): Query<CheckRemoteIDsExistence> = checkRemoteIDsExistence(queried_ids, ::CheckRemoteIDsExistence)

  /**
   * @return The number of rows updated.
   */
  public fun acknowledgeReadingBookmarkMutation(
    remote_id: String?,
    pending_op: String?,
    pending_version: Long,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(null, """
        |UPDATE reading_bookmark
        |  SET remote_id = CASE WHEN remote_id IS NULL THEN ? ELSE remote_id END,
        |    pending_op = CASE
        |      WHEN pending_op ${ if (pending_op == null) "IS" else "=" } ? AND pending_version = ? THEN NULL
        |      WHEN remote_id IS NULL THEN 'MODIFIED'
        |      ELSE pending_op
        |    END,
        |    modified_at = CASE
        |      WHEN pending_op ${ if (pending_op == null) "IS" else "=" } ? AND pending_version = ? THEN ?
        |      ELSE modified_at
        |    END
        |  WHERE local_id = ?
        |    AND (remote_id IS NULL OR remote_id ${ if (remote_id == null) "IS" else "=" } ?)
        """.trimMargin(), 8) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, pending_op)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, remote_id)
        }
    notifyQueries(-1_093_658_013) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(-1_337_140_862, """DELETE FROM reading_bookmark""", 0)
    notifyQueries(-1_337_140_862) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markAllForImportReplacement(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(-1_638_204_508, """
        |UPDATE reading_bookmark
        |  SET bookmark_type = NULL,
        |    sura = NULL,
        |    ayah = NULL,
        |    page = NULL,
        |    mushaf_id = NULL,
        |    pending_op = CASE WHEN remote_id IS NULL THEN 'CREATED' ELSE 'MODIFIED' END,
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(-1_638_204_508) { emit ->
      emit("reading_bookmark")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun setAyahReadingBookmark(
    slot: Long,
    sura: Long?,
    ayah: Long?,
    mushaf_id: Long?,
    timestamp: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-210_198_490, """
        |INSERT OR IGNORE INTO reading_bookmark (
        |    slot, bookmark_type, sura, ayah, page, mushaf_id, pending_op,
        |    pending_version, created_at, modified_at
        |  ) VALUES (
        |    ?, 'AYAH', ?, ?, NULL, ?, 'CREATED',
        |    0, ?, ?
        |  )
        """.trimMargin(), 6) {
          var parameterIndex = 0
          bindLong(parameterIndex++, slot)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, mushaf_id)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, timestamp)
        }
    driver.execute(-210_198_489, """
        |UPDATE reading_bookmark
        |  SET bookmark_type = 'AYAH',
        |    sura = ?,
        |    ayah = ?,
        |    page = NULL,
        |    mushaf_id = ?,
        |    pending_op = CASE WHEN remote_id IS NULL THEN 'CREATED' ELSE 'MODIFIED' END,
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        |  WHERE slot = ?
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, mushaf_id)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, slot)
        }
  }.also {
    notifyQueries(1_108_159_925) { emit ->
      emit("reading_bookmark")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun setPageReadingBookmark(
    slot: Long,
    page: Long?,
    mushaf_id: Long?,
    timestamp: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(2_106_297_846, """
        |INSERT OR IGNORE INTO reading_bookmark (
        |    slot, bookmark_type, sura, ayah, page, mushaf_id, pending_op,
        |    pending_version, created_at, modified_at
        |  ) VALUES (
        |    ?, 'PAGE', NULL, NULL, ?, ?, 'CREATED',
        |    0, ?, ?
        |  )
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, slot)
          bindLong(parameterIndex++, page)
          bindLong(parameterIndex++, mushaf_id)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, timestamp)
        }
    driver.execute(2_106_297_847, """
        |UPDATE reading_bookmark
        |  SET bookmark_type = 'PAGE',
        |    sura = NULL,
        |    ayah = NULL,
        |    page = ?,
        |    mushaf_id = ?,
        |    pending_op = CASE WHEN remote_id IS NULL THEN 'CREATED' ELSE 'MODIFIED' END,
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        |  WHERE slot = ?
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, page)
          bindLong(parameterIndex++, mushaf_id)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, slot)
        }
  }.also {
    notifyQueries(547_442_565) { emit ->
      emit("reading_bookmark")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun renameReadingBookmark(
    slot: Long,
    name: String?,
    timestamp: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-2_028_146_687, """
        |INSERT OR IGNORE INTO reading_bookmark (
        |    slot, name, pending_op, pending_version, created_at, modified_at
        |  ) VALUES (
        |    ?, ?, 'CREATED', 0, ?, ?
        |  )
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, slot)
          bindString(parameterIndex++, name)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, timestamp)
        }
    driver.execute(-2_028_146_686, """
        |UPDATE reading_bookmark
        |  SET name = ?,
        |    pending_op = CASE WHEN remote_id IS NULL THEN 'CREATED' ELSE 'MODIFIED' END,
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        |  WHERE slot = ?
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, name)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, slot)
        }
  }.also {
    notifyQueries(-1_968_588_720) { emit ->
      emit("reading_bookmark")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearReadingBookmark(slot: Long, timestamp: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(-1_613_588_934, """
        |INSERT OR IGNORE INTO reading_bookmark (
        |    slot, pending_op, pending_version, created_at, modified_at
        |  ) VALUES (
        |    ?, 'CREATED', 0, ?, ?
        |  )
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, slot)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, timestamp)
        }
    driver.execute(-1_613_588_933, """
        |UPDATE reading_bookmark
        |  SET bookmark_type = NULL,
        |    sura = NULL,
        |    ayah = NULL,
        |    page = NULL,
        |    mushaf_id = NULL,
        |    pending_op = CASE WHEN remote_id IS NULL THEN 'CREATED' ELSE 'MODIFIED' END,
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        |  WHERE slot = ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, slot)
        }
  }.also {
    notifyQueries(-19_556_151) { emit ->
      emit("reading_bookmark")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun persistRemoteReadingBookmark(
    remote_id: String?,
    slot: Long,
    name: String?,
    bookmark_type: String?,
    sura: Long?,
    ayah: Long?,
    page: Long?,
    mushaf_id: Long?,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(831_291_629, """
        |INSERT OR IGNORE INTO reading_bookmark (
        |    remote_id, slot, name, bookmark_type, sura, ayah, page, mushaf_id,
        |    pending_op, pending_version, created_at, modified_at
        |  ) VALUES (
        |    ?, ?, ?, ?, ?, ?, ?, ?,
        |    NULL, 0, ?, ?
        |  )
        """.trimMargin(), 10) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, slot)
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, bookmark_type)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, page)
          bindLong(parameterIndex++, mushaf_id)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(831_291_630, """
        |UPDATE reading_bookmark
        |  SET remote_id = ?,
        |    name = ?,
        |    bookmark_type = ?,
        |    sura = ?,
        |    ayah = ?,
        |    page = ?,
        |    mushaf_id = ?,
        |    pending_op = NULL,
        |    created_at = ?,
        |    modified_at = ?
        |  WHERE slot = ?
        """.trimMargin(), 10) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, name)
          bindString(parameterIndex++, bookmark_type)
          bindLong(parameterIndex++, sura)
          bindLong(parameterIndex++, ayah)
          bindLong(parameterIndex++, page)
          bindLong(parameterIndex++, mushaf_id)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, slot)
        }
  }.also {
    notifyQueries(-2_023_713_732) { emit ->
      emit("reading_bookmark")
    }
  }

  private inner class GetReadingBookmarkForSlotQuery<out T : Any>(
    public val slot: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_553_119_065, """SELECT reading_bookmark.local_id, reading_bookmark.remote_id, reading_bookmark.slot, reading_bookmark.name, reading_bookmark.bookmark_type, reading_bookmark.sura, reading_bookmark.ayah, reading_bookmark.page, reading_bookmark.mushaf_id, reading_bookmark.pending_op, reading_bookmark.pending_version, reading_bookmark.created_at, reading_bookmark.modified_at FROM reading_bookmark WHERE slot = ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, slot)
    }

    override fun toString(): String = "reading_bookmarks.sq:getReadingBookmarkForSlot"
  }

  private inner class GetReadingBookmarkByRemoteIdQuery<out T : Any>(
    public val remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT reading_bookmark.local_id, reading_bookmark.remote_id, reading_bookmark.slot, reading_bookmark.name, reading_bookmark.bookmark_type, reading_bookmark.sura, reading_bookmark.ayah, reading_bookmark.page, reading_bookmark.mushaf_id, reading_bookmark.pending_op, reading_bookmark.pending_version, reading_bookmark.created_at, reading_bookmark.modified_at FROM reading_bookmark WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, remote_id)
    }

    override fun toString(): String = "reading_bookmarks.sq:getReadingBookmarkByRemoteId"
  }

  private inner class CheckRemoteIDsExistenceQuery<out T : Any>(
    public val queried_ids: Collection<String?>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val queried_idsIndexes = createArguments(count = queried_ids.size)
      return driver.executeQuery(null, """SELECT remote_id FROM reading_bookmark WHERE remote_id IN $queried_idsIndexes""", mapper, queried_ids.size) {
            var parameterIndex = 0
            queried_ids.forEach { queried_ids_ ->
              bindString(parameterIndex++, queried_ids_)
            }
          }
    }

    override fun toString(): String = "reading_bookmarks.sq:checkRemoteIDsExistence"
  }
}
