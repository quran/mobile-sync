@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.ExecutableQuery
import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import com.quran.shared.persistence.bookmark_collections.CheckRemoteIDsExistence
import com.quran.shared.persistence.model.CollectionName
import kotlin.Any
import kotlin.Long
import kotlin.String

public class Bookmark_collectionsQueries(
  driver: SqlDriver,
  private val collectionAdapter: Collection.Adapter,
) : TransacterImpl(driver) {
  public fun countAll(): Query<Long> = Query(1_040_891_920, arrayOf("bookmark_collection"), driver, "bookmark_collections.sq", "countAll", "SELECT COUNT(*) FROM bookmark_collection") { cursor ->
    cursor.getLong(0)!!
  }

  public fun changedRowCount(): ExecutableQuery<Long> = Query(-1_381_983_637, driver, "bookmark_collections.sq", "changedRowCount", "SELECT changes()") { cursor ->
    cursor.getLong(0)!!
  }

  public fun countActiveForBookmark(bookmark_local_id: Long): Query<Long> = CountActiveForBookmarkQuery(bookmark_local_id) { cursor ->
    cursor.getLong(0)!!
  }

  public fun getActiveCollectionLocalIdsForBookmark(bookmark_local_id: Long): Query<Long> = GetActiveCollectionLocalIdsForBookmarkQuery(bookmark_local_id) { cursor ->
    cursor.getLong(0)!!
  }

  public fun countRetainedForBookmark(bookmark_local_id: Long): Query<Long> = CountRetainedForBookmarkQuery(bookmark_local_id) { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> getCollectionBookmarksWithDetails(mapper: (
    local_id: Long,
    bookmark_local_id: Long,
    collection_local_id: Long,
    is_active: Long,
    pending_op: String?,
    pending_version: Long,
    last_synced_bookmark_remote_id: String?,
    last_synced_collection_remote_id: String?,
    created_at: Long,
    modified_at: Long,
    collection_remote_id: String?,
    collection_name: CollectionName,
    bookmark_remote_id: String?,
    sura: Long,
    ayah: Long,
    bookmark_last_updated_at: Long,
    bookmark_added_at: Long,
  ) -> T): Query<T> = Query(-90_912_555, arrayOf("bookmark_collection", "collection", "bookmark"), driver, "bookmark_collections.sq", "getCollectionBookmarksWithDetails", """
  |SELECT
  |    bc.local_id,
  |    bc.bookmark_local_id,
  |    bc.collection_local_id,
  |    bc.is_active,
  |    bc.pending_op,
  |    bc.pending_version,
  |    bc.last_synced_bookmark_remote_id,
  |    bc.last_synced_collection_remote_id,
  |    bc.created_at,
  |    bc.modified_at,
  |    c.remote_id AS collection_remote_id,
  |    c.name AS collection_name,
  |    b.remote_id AS bookmark_remote_id,
  |    b.sura AS sura,
  |    b.ayah AS ayah,
  |    b.bookmark_modified_at AS bookmark_last_updated_at,
  |    b.created_at AS bookmark_added_at
  |  FROM bookmark_collection bc
  |  JOIN collection c ON c.local_id = bc.collection_local_id
  |  JOIN bookmark b ON b.local_id = bc.bookmark_local_id
  |  WHERE bc.is_active = 1
  |    AND b.deleted = 0
  |    AND c.deleted = 0
  |  ORDER BY bc.created_at DESC
  """.trimMargin()) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getString(4),
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getString(10),
      collectionAdapter.nameAdapter.decode(cursor.getString(11)!!),
      cursor.getString(12),
      cursor.getLong(13)!!,
      cursor.getLong(14)!!,
      cursor.getLong(15)!!,
      cursor.getLong(16)!!
    )
  }

  public fun getCollectionBookmarksWithDetails(): Query<GetCollectionBookmarksWithDetails> = getCollectionBookmarksWithDetails(::GetCollectionBookmarksWithDetails)

  public fun <T : Any> getCollectionBookmarksForCollectionWithDetails(collection_local_id: Long, mapper: (
    local_id: Long,
    bookmark_local_id: Long,
    collection_local_id: Long,
    is_active: Long,
    pending_op: String?,
    pending_version: Long,
    last_synced_bookmark_remote_id: String?,
    last_synced_collection_remote_id: String?,
    created_at: Long,
    modified_at: Long,
    collection_remote_id: String?,
    collection_name: CollectionName,
    bookmark_remote_id: String?,
    sura: Long,
    ayah: Long,
    bookmark_last_updated_at: Long,
    bookmark_added_at: Long,
  ) -> T): Query<T> = GetCollectionBookmarksForCollectionWithDetailsQuery(collection_local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getString(4),
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getString(10),
      collectionAdapter.nameAdapter.decode(cursor.getString(11)!!),
      cursor.getString(12),
      cursor.getLong(13)!!,
      cursor.getLong(14)!!,
      cursor.getLong(15)!!,
      cursor.getLong(16)!!
    )
  }

  public fun getCollectionBookmarksForCollectionWithDetails(collection_local_id: Long): Query<GetCollectionBookmarksForCollectionWithDetails> = getCollectionBookmarksForCollectionWithDetails(collection_local_id, ::GetCollectionBookmarksForCollectionWithDetails)

  public fun <T : Any> getUnsyncedCollectionBookmarksWithDetails(mapper: (
    local_id: Long,
    bookmark_local_id: Long,
    collection_local_id: Long,
    is_active: Long,
    pending_op: String,
    pending_version: Long,
    last_synced_bookmark_remote_id: String?,
    last_synced_collection_remote_id: String?,
    created_at: Long,
    modified_at: Long,
    collection_remote_id: String?,
    collection_name: CollectionName,
    bookmark_remote_id: String?,
    sura: Long,
    ayah: Long,
  ) -> T): Query<T> = Query(2_111_172_104, arrayOf("bookmark_collection", "collection", "bookmark"), driver, "bookmark_collections.sq", "getUnsyncedCollectionBookmarksWithDetails", """
  |SELECT
  |    bc.local_id,
  |    bc.bookmark_local_id,
  |    bc.collection_local_id,
  |    bc.is_active,
  |    bc.pending_op,
  |    bc.pending_version,
  |    bc.last_synced_bookmark_remote_id,
  |    bc.last_synced_collection_remote_id,
  |    bc.created_at,
  |    bc.modified_at,
  |    c.remote_id AS collection_remote_id,
  |    c.name AS collection_name,
  |    b.remote_id AS bookmark_remote_id,
  |    b.sura AS sura,
  |    b.ayah AS ayah
  |  FROM bookmark_collection bc
  |  JOIN collection c ON c.local_id = bc.collection_local_id
  |  JOIN bookmark b ON b.local_id = bc.bookmark_local_id
  |  WHERE bc.pending_op IS NOT NULL
  |    AND (
  |      (bc.pending_op = 'CREATED' AND bc.is_active = 1 AND c.deleted = 0 AND c.remote_id IS NOT NULL AND c.remote_id != '')
  |      OR
  |      (bc.pending_op = 'DELETED' AND bc.last_synced_collection_remote_id IS NOT NULL AND bc.last_synced_bookmark_remote_id IS NOT NULL)
  |    )
  |  ORDER BY bc.modified_at DESC
  """.trimMargin()) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getString(10),
      collectionAdapter.nameAdapter.decode(cursor.getString(11)!!),
      cursor.getString(12),
      cursor.getLong(13)!!,
      cursor.getLong(14)!!
    )
  }

  public fun getUnsyncedCollectionBookmarksWithDetails(): Query<GetUnsyncedCollectionBookmarksWithDetails> = getUnsyncedCollectionBookmarksWithDetails(::GetUnsyncedCollectionBookmarksWithDetails)

  public fun <T : Any> getCollectionBookmarkFor(
    bookmark_local_id: Long,
    collection_local_id: Long,
    mapper: (
      local_id: Long,
      bookmark_local_id: Long,
      collection_local_id: Long,
      is_active: Long,
      pending_op: String?,
      pending_version: Long,
      last_synced_bookmark_remote_id: String?,
      last_synced_collection_remote_id: String?,
      created_at: Long,
      modified_at: Long,
    ) -> T,
  ): Query<T> = GetCollectionBookmarkForQuery(bookmark_local_id, collection_local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getString(4),
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun getCollectionBookmarkFor(bookmark_local_id: Long, collection_local_id: Long): Query<Bookmark_collection> = getCollectionBookmarkFor(bookmark_local_id, collection_local_id, ::Bookmark_collection)

  public fun <T : Any> getCollectionBookmarkByLocalId(local_id: Long, mapper: (
    local_id: Long,
    bookmark_local_id: Long,
    collection_local_id: Long,
    is_active: Long,
    pending_op: String?,
    pending_version: Long,
    last_synced_bookmark_remote_id: String?,
    last_synced_collection_remote_id: String?,
    created_at: Long,
    modified_at: Long,
  ) -> T): Query<T> = GetCollectionBookmarkByLocalIdQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getString(4),
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun getCollectionBookmarkByLocalId(local_id: Long): Query<Bookmark_collection> = getCollectionBookmarkByLocalId(local_id, ::Bookmark_collection)

  public fun getBookmarkLocalIdBySnapshot(bookmark_remote_id: String?, collection_remote_id: String?): Query<Long> = GetBookmarkLocalIdBySnapshotQuery(bookmark_remote_id, collection_remote_id) { cursor ->
    cursor.getLong(0)!!
  }

  public fun getBookmarkLocalIdByCurrentRemoteIds(collection_remote_id: String?, bookmark_remote_id: String?): Query<Long> = GetBookmarkLocalIdByCurrentRemoteIdsQuery(collection_remote_id, bookmark_remote_id) { cursor ->
    cursor.getLong(0)!!
  }

  public fun getBookmarkLocalIdsForCollectionRemoteId(collection_remote_id: String?): Query<Long> = GetBookmarkLocalIdsForCollectionRemoteIdQuery(collection_remote_id) { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> getCollectionBookmarkWithDetailsByRemoteId(remote_id: String?, mapper: (
    local_id: Long,
    bookmark_local_id: Long,
    collection_local_id: Long,
    is_active: Long,
    pending_op: String?,
    pending_version: Long,
    last_synced_bookmark_remote_id: String?,
    last_synced_collection_remote_id: String?,
    created_at: Long,
    modified_at: Long,
    collection_remote_id: String?,
    collection_name: CollectionName,
    bookmark_remote_id: String?,
    sura: Long,
    ayah: Long,
  ) -> T): Query<T> = GetCollectionBookmarkWithDetailsByRemoteIdQuery(remote_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getLong(1)!!,
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getString(4),
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getString(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!,
      cursor.getString(10),
      collectionAdapter.nameAdapter.decode(cursor.getString(11)!!),
      cursor.getString(12),
      cursor.getLong(13)!!,
      cursor.getLong(14)!!
    )
  }

  public fun getCollectionBookmarkWithDetailsByRemoteId(remote_id: String?): Query<GetCollectionBookmarkWithDetailsByRemoteId> = getCollectionBookmarkWithDetailsByRemoteId(remote_id, ::GetCollectionBookmarkWithDetailsByRemoteId)

  public fun <T : Any> checkRemoteIDsExistence(queried_ids: kotlin.collections.Collection<String?>, mapper: (remote_id: String?) -> T): Query<T> = CheckRemoteIDsExistenceQuery(queried_ids) { cursor ->
    mapper(
      cursor.getString(0)
    )
  }

  public fun checkRemoteIDsExistence(queried_ids: kotlin.collections.Collection<String?>): Query<CheckRemoteIDsExistence> = checkRemoteIDsExistence(queried_ids, ::CheckRemoteIDsExistence)

  /**
   * @return The number of rows updated.
   */
  public fun bindRemoteSnapshotForCreatedAck(
    bookmark_remote_id: String?,
    collection_remote_id: String?,
    id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(197_295_077, """
        |UPDATE bookmark_collection
        |  SET last_synced_bookmark_remote_id = COALESCE(?, last_synced_bookmark_remote_id),
        |    last_synced_collection_remote_id = COALESCE(?, last_synced_collection_remote_id)
        |  WHERE local_id = ?
        |    AND is_active = 0
        |    AND pending_op = 'DELETED'
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, bookmark_remote_id)
          bindString(parameterIndex++, collection_remote_id)
          bindLong(parameterIndex++, id)
        }
    notifyQueries(197_295_077) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markBookmarkCollectionForRecreation(modified_at: Long, id: Long): QueryResult<Long> {
    val result = driver.execute(-1_493_012_900, """
        |UPDATE bookmark_collection
        |  SET pending_op = 'CREATED',
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        |  WHERE local_id = ?
        |    AND is_active = 1
        |    AND pending_op IS NULL
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, id)
        }
    notifyQueries(-1_493_012_900) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markCreatedMutationInFlight(id: Long, pending_version: Long): QueryResult<Long> {
    val result = driver.execute(166_964_859, """
        |UPDATE bookmark_collection
        |  SET pending_version = pending_version + 1
        |  WHERE local_id = ?
        |    AND pending_op = 'CREATED'
        |    AND pending_version = ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
        }
    notifyQueries(166_964_859) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun rollbackActiveCreatedMutationInFlight(
    pending_version: Long,
    id: Long,
    marked_pending_version: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-294_590_690, """
        |UPDATE bookmark_collection
        |  SET pending_version = ?
        |  WHERE local_id = ?
        |    AND is_active = 1
        |    AND pending_op = 'CREATED'
        |    AND pending_version = ?
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, marked_pending_version)
        }
    notifyQueries(-294_590_690) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteCanceledCreatedMutationInFlight(id: Long, canceled_pending_version: Long): QueryResult<Long> {
    val result = driver.execute(614_579_588, """
        |DELETE FROM bookmark_collection
        |  WHERE local_id = ?
        |    AND is_active = 0
        |    AND pending_op = 'DELETED'
        |    AND pending_version = ?
        |    AND last_synced_bookmark_remote_id IS NULL
        |    AND last_synced_collection_remote_id IS NULL
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, canceled_pending_version)
        }
    notifyQueries(614_579_588) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteBookmarkCollectionByCurrentRemoteIds(collection_remote_id: String?, bookmark_remote_id: String?): QueryResult<Long> {
    val result = driver.execute(null, """
        |DELETE FROM bookmark_collection
        |  WHERE local_id IN (
        |    SELECT bc.local_id FROM bookmark_collection bc
        |    JOIN collection c ON c.local_id = bc.collection_local_id
        |    JOIN bookmark b ON b.local_id = bc.bookmark_local_id
        |    WHERE c.remote_id ${ if (collection_remote_id == null) "IS" else "=" } ?
        |      AND b.remote_id ${ if (bookmark_remote_id == null) "IS" else "=" } ?
        |      AND bc.is_active = 1
        |  )
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, collection_remote_id)
          bindString(parameterIndex++, bookmark_remote_id)
        }
    notifyQueries(-1_090_584_595) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteUnsyncedBookmarkCollectionByLocalIds(bookmark_local_id: Long, collection_local_id: Long): QueryResult<Long> {
    val result = driver.execute(-971_548_396, """
        |DELETE FROM bookmark_collection
        |  WHERE bookmark_local_id = ?
        |    AND collection_local_id = ?
        |    AND (
        |      last_synced_bookmark_remote_id IS NULL
        |      OR last_synced_collection_remote_id IS NULL
        |    )
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
        }
    notifyQueries(-971_548_396) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markActiveLinksWithChangedSnapshots(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(-244_850_839, """
        |UPDATE bookmark_collection
        |  SET pending_op = 'CREATED',
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        |  WHERE is_active = 1
        |    AND pending_op IS NULL
        |    AND (
        |      last_synced_bookmark_remote_id IS NOT NULL
        |      OR last_synced_collection_remote_id IS NOT NULL
        |    )
        |    AND EXISTS (
        |      SELECT 1 FROM bookmark b
        |      JOIN collection c ON c.local_id = bookmark_collection.collection_local_id
        |      WHERE b.local_id = bookmark_collection.bookmark_local_id
        |        AND b.deleted = 0
        |        AND c.deleted = 0
        |        AND b.remote_id IS NOT NULL
        |        AND c.remote_id IS NOT NULL
        |        AND (
        |          bookmark_collection.last_synced_bookmark_remote_id != b.remote_id
        |          OR bookmark_collection.last_synced_collection_remote_id != c.remote_id
        |        )
        |    )
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(-244_850_839) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteInactiveClearedLinks(): QueryResult<Long> {
    val result = driver.execute(1_885_249_601, """
        |DELETE FROM bookmark_collection
        |  WHERE is_active = 0
        |    AND pending_op IS NULL
        |    AND (
        |      (
        |        last_synced_bookmark_remote_id IS NULL
        |        AND last_synced_collection_remote_id IS NULL
        |      )
        |      OR NOT EXISTS (
        |        SELECT 1 FROM bookmark b
        |        WHERE b.local_id = bookmark_collection.bookmark_local_id
        |      )
        |      OR EXISTS (
        |        SELECT 1 FROM bookmark b
        |        WHERE b.local_id = bookmark_collection.bookmark_local_id
        |          AND b.deleted = 1
        |          AND b.bookmark_pending_op IS NULL
        |      )
        |    )
        """.trimMargin(), 0)
    notifyQueries(1_885_249_601) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteRetiredInactiveClearedLinksForBookmark(bookmark_local_id: Long): QueryResult<Long> {
    val result = driver.execute(-825_026_009, """
        |DELETE FROM bookmark_collection
        |  WHERE bookmark_local_id = ?
        |    AND is_active = 0
        |    AND pending_op IS NULL
        |    AND EXISTS (
        |      SELECT 1 FROM bookmark b
        |      WHERE b.local_id = ?
        |        AND b.deleted = 1
        |        AND b.bookmark_pending_op IS NULL
        |    )
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, bookmark_local_id)
        }
    notifyQueries(-825_026_009) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteLinksForInactiveParents(): QueryResult<Long> {
    val result = driver.execute(-984_356_795, """
        |DELETE FROM bookmark_collection
        |  WHERE last_synced_bookmark_remote_id IS NULL
        |    AND last_synced_collection_remote_id IS NULL
        |    AND (pending_op IS NULL OR pending_op != 'DELETED')
        |    AND (
        |      NOT EXISTS (SELECT 1 FROM bookmark b WHERE b.local_id = bookmark_collection.bookmark_local_id AND b.deleted = 0)
        |      OR NOT EXISTS (SELECT 1 FROM collection c WHERE c.local_id = bookmark_collection.collection_local_id AND c.deleted = 0)
        |    )
        """.trimMargin(), 0)
    notifyQueries(-984_356_795) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markSyncedLinksForInactiveParents(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(-1_652_314_167, """
        |UPDATE bookmark_collection
        |  SET is_active = 0,
        |    pending_op = 'DELETED',
        |    pending_version = CASE WHEN pending_op = 'DELETED' THEN pending_version ELSE pending_version + 1 END,
        |    modified_at = CASE WHEN pending_op = 'DELETED' THEN modified_at ELSE ? END
        |  WHERE (
        |      last_synced_bookmark_remote_id IS NOT NULL
        |      OR last_synced_collection_remote_id IS NOT NULL
        |    )
        |    AND (
        |      NOT EXISTS (SELECT 1 FROM bookmark b WHERE b.local_id = bookmark_collection.bookmark_local_id AND b.deleted = 0)
        |      OR NOT EXISTS (SELECT 1 FROM collection c WHERE c.local_id = bookmark_collection.collection_local_id AND c.deleted = 0)
        |    )
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(-1_652_314_167) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markUnsyncedBookmarkCollectionsDeletedForImport(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(799_468_598, """
        |UPDATE bookmark_collection
        |  SET is_active = 0,
        |    pending_op = 'DELETED',
        |    pending_version = CASE WHEN pending_op = 'DELETED' THEN pending_version ELSE pending_version + 1 END,
        |    modified_at = ?
        |  WHERE pending_op = 'CREATED'
        |    AND last_synced_bookmark_remote_id IS NULL
        |    AND last_synced_collection_remote_id IS NULL
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(799_468_598) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markRemoteBookmarkCollectionsDeleted(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(600_028_523, """
        |UPDATE bookmark_collection
        |  SET is_active = 0,
        |    pending_op = 'DELETED',
        |    pending_version = CASE WHEN pending_op = 'DELETED' THEN pending_version ELSE pending_version + 1 END,
        |    modified_at = ?
        |  WHERE last_synced_bookmark_remote_id IS NOT NULL
        |    OR last_synced_collection_remote_id IS NOT NULL
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(600_028_523) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(492_960_184, """DELETE FROM bookmark_collection""", 0)
    notifyQueries(492_960_184) { emit ->
      emit("bookmark_collection")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun addBookmarkToCollection(
    bookmark_local_id: Long,
    collection_local_id: Long,
    timestamp: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-48_313_469, """
        |INSERT OR IGNORE INTO bookmark_collection (
        |    bookmark_local_id,
        |    collection_local_id,
        |    is_active,
        |    pending_op,
        |    pending_version,
        |    created_at,
        |    modified_at
        |  )
        |  VALUES (
        |    ?,
        |    ?,
        |    1,
        |    'CREATED',
        |    0,
        |    ?,
        |    ?
        |  )
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, timestamp)
        }
    driver.execute(-48_313_468, """
        |UPDATE bookmark_collection
        |  SET is_active = 1,
        |    pending_op = CASE
        |      WHEN last_synced_bookmark_remote_id = (
        |          SELECT remote_id FROM bookmark WHERE local_id = ?
        |        )
        |        AND last_synced_collection_remote_id = (
        |          SELECT remote_id FROM collection WHERE local_id = ?
        |        )
        |        AND (
        |          is_active = 1
        |          OR pending_op = 'DELETED'
        |        ) THEN NULL
        |      ELSE 'CREATED'
        |    END,
        |    pending_version = pending_version + 1,
        |    modified_at = ?
        |  WHERE bookmark_local_id = ?
        |    AND collection_local_id = ?
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
        }
  }.also {
    notifyQueries(2_131_790_930) { emit ->
      emit("bookmark_collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertImportedBookmarkCollection(
    bookmark_local_id: Long,
    collection_local_id: Long,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(108_350_496, """
        |INSERT OR IGNORE INTO bookmark_collection (
        |    bookmark_local_id,
        |    collection_local_id,
        |    is_active,
        |    pending_op,
        |    pending_version,
        |    created_at,
        |    modified_at
        |  )
        |  VALUES (
        |    ?,
        |    ?,
        |    1,
        |    'CREATED',
        |    1,
        |    ?,
        |    ?
        |  )
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(108_350_497, """
        |UPDATE bookmark_collection
        |  SET is_active = 1,
        |    pending_op = 'CREATED',
        |    pending_version = CASE WHEN pending_op = 'CREATED' THEN pending_version ELSE pending_version + 1 END,
        |    modified_at = ?
        |  WHERE bookmark_local_id = ?
        |    AND collection_local_id = ?
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
        }
  }.also {
    notifyQueries(978_882_607) { emit ->
      emit("bookmark_collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun markBookmarkCollectionDeleted(
    bookmark_local_id: Long,
    collection_local_id: Long,
    timestamp: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-604_822_357, """
        |DELETE FROM bookmark_collection
        |  WHERE bookmark_local_id = ?
        |    AND collection_local_id = ?
        |    AND last_synced_bookmark_remote_id IS NULL
        |    AND last_synced_collection_remote_id IS NULL
        |    AND (pending_op IS NULL OR pending_op != 'CREATED' OR pending_version <= 1)
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
        }
    driver.execute(-604_822_356, """
        |UPDATE bookmark_collection
        |  SET is_active = 0,
        |    pending_op = 'DELETED',
        |    pending_version = CASE WHEN pending_op = 'DELETED' THEN pending_version ELSE pending_version + 1 END,
        |    modified_at = ?
        |  WHERE bookmark_local_id = ?
        |    AND collection_local_id = ?
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
        }
  }.also {
    notifyQueries(1_979_256_698) { emit ->
      emit("bookmark_collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun markBookmarkCollectionsDeletedForBookmark(bookmark_local_id: Long, timestamp: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(157_137_995, """
        |DELETE FROM bookmark_collection
        |  WHERE bookmark_local_id = ?
        |    AND last_synced_bookmark_remote_id IS NULL
        |    AND last_synced_collection_remote_id IS NULL
        |    AND (pending_op IS NULL OR pending_op != 'CREATED' OR pending_version <= 1)
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
        }
    driver.execute(157_137_996, """
        |UPDATE bookmark_collection
        |  SET is_active = 0,
        |    pending_op = 'DELETED',
        |    pending_version = CASE WHEN pending_op = 'DELETED' THEN pending_version ELSE pending_version + 1 END,
        |    modified_at = ?
        |  WHERE bookmark_local_id = ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, bookmark_local_id)
        }
  }.also {
    notifyQueries(241_504_026) { emit ->
      emit("bookmark_collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearLocalMutationFor(
    bookmark_remote_id: String?,
    collection_remote_id: String?,
    modified_at: Long,
    id: Long,
    pending_op: String?,
    pending_version: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(null, """
        |UPDATE bookmark_collection
        |  SET pending_op = NULL,
        |    last_synced_bookmark_remote_id = COALESCE(?, last_synced_bookmark_remote_id),
        |    last_synced_collection_remote_id = COALESCE(?, last_synced_collection_remote_id),
        |    modified_at = ?
        |  WHERE local_id = ?
        |    AND pending_op ${ if (pending_op == null) "IS" else "=" } ?
        |    AND pending_version = ?
        """.trimMargin(), 6) {
          var parameterIndex = 0
          bindString(parameterIndex++, bookmark_remote_id)
          bindString(parameterIndex++, collection_remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, id)
          bindString(parameterIndex++, pending_op)
          bindLong(parameterIndex++, pending_version)
        }
  }.also {
    notifyQueries(-1_054_757_852) { emit ->
      emit("bookmark_collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun persistRemoteBookmarkCollection(
    bookmark_local_id: Long,
    collection_local_id: Long,
    bookmark_remote_id: String?,
    collection_remote_id: String?,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-1_144_004_287, """
        |INSERT OR IGNORE INTO bookmark_collection (
        |    bookmark_local_id,
        |    collection_local_id,
        |    is_active,
        |    pending_op,
        |    pending_version,
        |    last_synced_bookmark_remote_id,
        |    last_synced_collection_remote_id,
        |    created_at,
        |    modified_at
        |  )
        |  VALUES (
        |    ?,
        |    ?,
        |    1,
        |    NULL,
        |    0,
        |    ?,
        |    ?,
        |    ?,
        |    ?
        |  )
        """.trimMargin(), 6) {
          var parameterIndex = 0
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
          bindString(parameterIndex++, bookmark_remote_id)
          bindString(parameterIndex++, collection_remote_id)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(-1_144_004_286, """
        |UPDATE bookmark_collection
        |  SET is_active = CASE
        |      WHEN is_active = 0 AND pending_op = 'DELETED' THEN is_active
        |      ELSE 1
        |    END,
        |    last_synced_bookmark_remote_id = ?,
        |    last_synced_collection_remote_id = ?,
        |    modified_at = ?
        |  WHERE bookmark_local_id = ?
        |    AND collection_local_id = ?
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, bookmark_remote_id)
          bindString(parameterIndex++, collection_remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, bookmark_local_id)
          bindLong(parameterIndex++, collection_local_id)
        }
  }.also {
    notifyQueries(-1_779_959_408) { emit ->
      emit("bookmark_collection")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteRemoteBookmarkCollectionBySnapshot(bookmark_remote_id: String?, collection_remote_id: String?): QueryResult<Long> = transactionWithResult {
    driver.execute(null, """
        |UPDATE bookmark_collection
        |  SET last_synced_bookmark_remote_id = NULL,
        |    last_synced_collection_remote_id = NULL
        |  WHERE last_synced_bookmark_remote_id ${ if (bookmark_remote_id == null) "IS" else "=" } ?
        |    AND last_synced_collection_remote_id ${ if (collection_remote_id == null) "IS" else "=" } ?
        |    AND is_active = 1
        |    AND pending_op = 'CREATED'
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, bookmark_remote_id)
          bindString(parameterIndex++, collection_remote_id)
        }
    driver.execute(null, """
        |DELETE FROM bookmark_collection
        |  WHERE last_synced_bookmark_remote_id ${ if (bookmark_remote_id == null) "IS" else "=" } ?
        |    AND last_synced_collection_remote_id ${ if (collection_remote_id == null) "IS" else "=" } ?
        """.trimMargin(), 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, bookmark_remote_id)
          bindString(parameterIndex++, collection_remote_id)
        }
  }.also {
    notifyQueries(-867_744_962) { emit ->
      emit("bookmark_collection")
    }
  }

  private inner class CountActiveForBookmarkQuery<out T : Any>(
    public val bookmark_local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_269_088_664, """
    |SELECT COUNT(*) FROM bookmark_collection
    |  WHERE bookmark_local_id = ? AND is_active = 1
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, bookmark_local_id)
    }

    override fun toString(): String = "bookmark_collections.sq:countActiveForBookmark"
  }

  private inner class GetActiveCollectionLocalIdsForBookmarkQuery<out T : Any>(
    public val bookmark_local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-884_435_722, """
    |SELECT collection_local_id FROM bookmark_collection
    |  WHERE bookmark_local_id = ? AND is_active = 1
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, bookmark_local_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getActiveCollectionLocalIdsForBookmark"
  }

  private inner class CountRetainedForBookmarkQuery<out T : Any>(
    public val bookmark_local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", "bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", "bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-928_139_638, """
    |SELECT COUNT(*) FROM bookmark_collection
    |  WHERE bookmark_local_id = ?
    |    AND (
    |      is_active = 1
    |      OR pending_op IS NOT NULL
    |      OR (
    |        (
    |          last_synced_bookmark_remote_id IS NOT NULL
    |          OR last_synced_collection_remote_id IS NOT NULL
    |        )
    |        AND NOT EXISTS (
    |          SELECT 1 FROM bookmark b
    |          WHERE b.local_id = bookmark_collection.bookmark_local_id
    |            AND b.deleted = 1
    |            AND b.bookmark_pending_op IS NULL
    |        )
    |      )
    |    )
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, bookmark_local_id)
    }

    override fun toString(): String = "bookmark_collections.sq:countRetainedForBookmark"
  }

  private inner class GetCollectionBookmarksForCollectionWithDetailsQuery<out T : Any>(
    public val collection_local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(723_684_924, """
    |SELECT
    |    bc.local_id,
    |    bc.bookmark_local_id,
    |    bc.collection_local_id,
    |    bc.is_active,
    |    bc.pending_op,
    |    bc.pending_version,
    |    bc.last_synced_bookmark_remote_id,
    |    bc.last_synced_collection_remote_id,
    |    bc.created_at,
    |    bc.modified_at,
    |    c.remote_id AS collection_remote_id,
    |    c.name AS collection_name,
    |    b.remote_id AS bookmark_remote_id,
    |    b.sura AS sura,
    |    b.ayah AS ayah,
    |    b.bookmark_modified_at AS bookmark_last_updated_at,
    |    b.created_at AS bookmark_added_at
    |  FROM bookmark_collection bc
    |  JOIN collection c ON c.local_id = bc.collection_local_id
    |  JOIN bookmark b ON b.local_id = bc.bookmark_local_id
    |  WHERE bc.collection_local_id = ?
    |    AND bc.is_active = 1
    |    AND b.deleted = 0
    |    AND c.deleted = 0
    |  ORDER BY bc.created_at DESC
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, collection_local_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getCollectionBookmarksForCollectionWithDetails"
  }

  private inner class GetCollectionBookmarkForQuery<out T : Any>(
    public val bookmark_local_id: Long,
    public val collection_local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(392_632_957, """
    |SELECT bookmark_collection.local_id, bookmark_collection.bookmark_local_id, bookmark_collection.collection_local_id, bookmark_collection.is_active, bookmark_collection.pending_op, bookmark_collection.pending_version, bookmark_collection.last_synced_bookmark_remote_id, bookmark_collection.last_synced_collection_remote_id, bookmark_collection.created_at, bookmark_collection.modified_at FROM bookmark_collection
    |  WHERE bookmark_local_id = ? AND collection_local_id = ? LIMIT 1
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, bookmark_local_id)
      bindLong(parameterIndex++, collection_local_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getCollectionBookmarkFor"
  }

  private inner class GetCollectionBookmarkByLocalIdQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_959_887_805, """
    |SELECT bookmark_collection.local_id, bookmark_collection.bookmark_local_id, bookmark_collection.collection_local_id, bookmark_collection.is_active, bookmark_collection.pending_op, bookmark_collection.pending_version, bookmark_collection.last_synced_bookmark_remote_id, bookmark_collection.last_synced_collection_remote_id, bookmark_collection.created_at, bookmark_collection.modified_at FROM bookmark_collection
    |  WHERE local_id = ? LIMIT 1
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getCollectionBookmarkByLocalId"
  }

  private inner class GetBookmarkLocalIdBySnapshotQuery<out T : Any>(
    public val bookmark_remote_id: String?,
    public val collection_remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """
    |SELECT bookmark_local_id FROM bookmark_collection
    |  WHERE last_synced_bookmark_remote_id ${ if (bookmark_remote_id == null) "IS" else "=" } ?
    |    AND last_synced_collection_remote_id ${ if (collection_remote_id == null) "IS" else "=" } ?
    |  LIMIT 1
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindString(parameterIndex++, bookmark_remote_id)
      bindString(parameterIndex++, collection_remote_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getBookmarkLocalIdBySnapshot"
  }

  private inner class GetBookmarkLocalIdByCurrentRemoteIdsQuery<out T : Any>(
    public val collection_remote_id: String?,
    public val bookmark_remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """
    |SELECT bc.bookmark_local_id FROM bookmark_collection bc
    |  JOIN collection c ON c.local_id = bc.collection_local_id
    |  JOIN bookmark b ON b.local_id = bc.bookmark_local_id
    |  WHERE c.remote_id ${ if (collection_remote_id == null) "IS" else "=" } ?
    |    AND b.remote_id ${ if (bookmark_remote_id == null) "IS" else "=" } ?
    |    AND bc.is_active = 1
    |  LIMIT 1
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindString(parameterIndex++, collection_remote_id)
      bindString(parameterIndex++, bookmark_remote_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getBookmarkLocalIdByCurrentRemoteIds"
  }

  private inner class GetBookmarkLocalIdsForCollectionRemoteIdQuery<out T : Any>(
    public val collection_remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", "collection", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", "collection", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """
    |SELECT bc.bookmark_local_id FROM bookmark_collection bc
    |  JOIN collection c ON c.local_id = bc.collection_local_id
    |  WHERE c.remote_id ${ if (collection_remote_id == null) "IS" else "=" } ?
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, collection_remote_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getBookmarkLocalIdsForCollectionRemoteId"
  }

  private inner class GetCollectionBookmarkWithDetailsByRemoteIdQuery<out T : Any>(
    public val remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """
    |SELECT
    |    bc.local_id,
    |    bc.bookmark_local_id,
    |    bc.collection_local_id,
    |    bc.is_active,
    |    bc.pending_op,
    |    bc.pending_version,
    |    bc.last_synced_bookmark_remote_id,
    |    bc.last_synced_collection_remote_id,
    |    bc.created_at,
    |    bc.modified_at,
    |    c.remote_id AS collection_remote_id,
    |    c.name AS collection_name,
    |    b.remote_id AS bookmark_remote_id,
    |    b.sura AS sura,
    |    b.ayah AS ayah
    |  FROM bookmark_collection bc
    |  JOIN collection c ON c.local_id = bc.collection_local_id
    |  JOIN bookmark b ON b.local_id = bc.bookmark_local_id
    |  WHERE (
    |      bc.last_synced_collection_remote_id || '-' || bc.last_synced_bookmark_remote_id ${ if (remote_id == null) "IS" else "=" } ?
    |      OR (bc.is_active = 1 AND c.remote_id || '-' || b.remote_id ${ if (remote_id == null) "IS" else "=" } ?)
    |    )
    |  LIMIT 1
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindString(parameterIndex++, remote_id)
      bindString(parameterIndex++, remote_id)
    }

    override fun toString(): String = "bookmark_collections.sq:getCollectionBookmarkWithDetailsByRemoteId"
  }

  private inner class CheckRemoteIDsExistenceQuery<out T : Any>(
    public val queried_ids: kotlin.collections.Collection<String?>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("bookmark_collection", "collection", "bookmark", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val queried_idsIndexes = createArguments(count = queried_ids.size)
      return driver.executeQuery(null, """
          |SELECT remote_id FROM (
          |    SELECT last_synced_collection_remote_id || '-' || last_synced_bookmark_remote_id AS remote_id
          |    FROM bookmark_collection
          |    UNION
          |    SELECT c.remote_id || '-' || b.remote_id AS remote_id
          |    FROM bookmark_collection bc
          |    JOIN collection c ON c.local_id = bc.collection_local_id
          |    JOIN bookmark b ON b.local_id = bc.bookmark_local_id
          |    WHERE bc.is_active = 1
          |  )
          |  WHERE remote_id IN $queried_idsIndexes
          """.trimMargin(), mapper, queried_ids.size) {
            var parameterIndex = 0
            queried_ids.forEach { queried_ids_ ->
              bindString(parameterIndex++, queried_ids_)
            }
          }
    }

    override fun toString(): String = "bookmark_collections.sq:checkRemoteIDsExistence"
  }
}
