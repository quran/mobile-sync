@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import com.quran.shared.persistence.reading_sessions.CheckRemoteIDsExistence
import kotlin.Any
import kotlin.Long
import kotlin.String
import kotlin.collections.Collection

public class Reading_sessionsQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> getReadingSessions(mapper: (
    local_id: Long,
    remote_id: String?,
    chapter_number: Long,
    verse_number: Long,
    is_edited: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(2_132_314_485, arrayOf("reading_session"), driver, "reading_sessions.sq", "getReadingSessions", "SELECT reading_session.local_id, reading_session.remote_id, reading_session.chapter_number, reading_session.verse_number, reading_session.is_edited, reading_session.created_at, reading_session.modified_at, reading_session.deleted, reading_session.pending_version FROM reading_session WHERE deleted = 0 ORDER BY modified_at DESC, local_id DESC") { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!
    )
  }

  public fun getReadingSessions(): Query<Reading_session> = getReadingSessions(::Reading_session)

  public fun countAll(): Query<Long> = Query(-560_229_132, arrayOf("reading_session"), driver, "reading_sessions.sq", "countAll", "SELECT COUNT(*) FROM reading_session") { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> getReadingSessionForChapterVerse(
    chapter_number: Long,
    verse_number: Long,
    mapper: (
      local_id: Long,
      remote_id: String?,
      chapter_number: Long,
      verse_number: Long,
      is_edited: Long,
      created_at: Long,
      modified_at: Long,
      deleted: Long,
      pending_version: Long,
    ) -> T,
  ): Query<T> = GetReadingSessionForChapterVerseQuery(chapter_number, verse_number) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!
    )
  }

  public fun getReadingSessionForChapterVerse(chapter_number: Long, verse_number: Long): Query<Reading_session> = getReadingSessionForChapterVerse(chapter_number, verse_number, ::Reading_session)

  public fun <T : Any> getPendingCreatedReadingSessionsForChapterVerse(
    chapter_number: Long,
    verse_number: Long,
    mapper: (
      local_id: Long,
      remote_id: String?,
      chapter_number: Long,
      verse_number: Long,
      is_edited: Long,
      created_at: Long,
      modified_at: Long,
      deleted: Long,
      pending_version: Long,
    ) -> T,
  ): Query<T> = GetPendingCreatedReadingSessionsForChapterVerseQuery(chapter_number, verse_number) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!
    )
  }

  public fun getPendingCreatedReadingSessionsForChapterVerse(chapter_number: Long, verse_number: Long): Query<Reading_session> = getPendingCreatedReadingSessionsForChapterVerse(chapter_number, verse_number, ::Reading_session)

  public fun <T : Any> getDeletedPendingCreatedReadingSessionsForChapterVerse(
    chapter_number: Long,
    verse_number: Long,
    mapper: (
      local_id: Long,
      remote_id: String?,
      chapter_number: Long,
      verse_number: Long,
      is_edited: Long,
      created_at: Long,
      modified_at: Long,
      deleted: Long,
      pending_version: Long,
    ) -> T,
  ): Query<T> = GetDeletedPendingCreatedReadingSessionsForChapterVerseQuery(chapter_number, verse_number) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!
    )
  }

  public fun getDeletedPendingCreatedReadingSessionsForChapterVerse(chapter_number: Long, verse_number: Long): Query<Reading_session> = getDeletedPendingCreatedReadingSessionsForChapterVerse(chapter_number, verse_number, ::Reading_session)

  public fun <T : Any> getReadingSessionByLocalId(local_id: Long, mapper: (
    local_id: Long,
    remote_id: String?,
    chapter_number: Long,
    verse_number: Long,
    is_edited: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetReadingSessionByLocalIdQuery(local_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!
    )
  }

  public fun getReadingSessionByLocalId(local_id: Long): Query<Reading_session> = getReadingSessionByLocalId(local_id, ::Reading_session)

  public fun <T : Any> getReadingSessionByRemoteId(remote_id: String?, mapper: (
    local_id: Long,
    remote_id: String?,
    chapter_number: Long,
    verse_number: Long,
    is_edited: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    pending_version: Long,
  ) -> T): Query<T> = GetReadingSessionByRemoteIdQuery(remote_id) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!
    )
  }

  public fun getReadingSessionByRemoteId(remote_id: String?): Query<Reading_session> = getReadingSessionByRemoteId(remote_id, ::Reading_session)

  public fun <T : Any> getUnsyncedReadingSessions(mapper: (
    local_id: Long,
    remote_id: String?,
    chapter_number: Long,
    verse_number: Long,
    is_edited: Long,
    created_at: Long,
    modified_at: Long,
    deleted: Long,
    pending_version: Long,
  ) -> T): Query<T> = Query(-1_485_709_150, arrayOf("reading_session"), driver, "reading_sessions.sq", "getUnsyncedReadingSessions", """
  |SELECT reading_session.local_id, reading_session.remote_id, reading_session.chapter_number, reading_session.verse_number, reading_session.is_edited, reading_session.created_at, reading_session.modified_at, reading_session.deleted, reading_session.pending_version FROM reading_session
  |  WHERE (remote_id IS NULL AND deleted = 0)
  |    OR (remote_id IS NOT NULL AND deleted = 1)
  |    OR is_edited = 1
  |  ORDER BY modified_at DESC
  """.trimMargin()) { cursor ->
    mapper(
      cursor.getLong(0)!!,
      cursor.getString(1),
      cursor.getLong(2)!!,
      cursor.getLong(3)!!,
      cursor.getLong(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!
    )
  }

  public fun getUnsyncedReadingSessions(): Query<Reading_session> = getUnsyncedReadingSessions(::Reading_session)

  public fun <T : Any> checkRemoteIDsExistence(queried_ids: Collection<String?>, mapper: (remote_id: String?) -> T): Query<T> = CheckRemoteIDsExistenceQuery(queried_ids) { cursor ->
    mapper(
      cursor.getString(0)
    )
  }

  public fun checkRemoteIDsExistence(queried_ids: Collection<String?>): Query<CheckRemoteIDsExistence> = checkRemoteIDsExistence(queried_ids, ::CheckRemoteIDsExistence)

  /**
   * @return The number of rows updated.
   */
  public fun updateReadingSession(
    chapter_number: Long,
    verse_number: Long,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-1_601_636_491, """
        |UPDATE reading_session
        |  SET chapter_number = ?,
        |    verse_number = ?,
        |    is_edited = CASE WHEN remote_id IS NULL THEN 0 ELSE 1 END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE local_id = ?
        |    AND deleted = 0
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-1_601_636_491) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun attachRemoteReadingSessionIdForCreatedAck(
    remote_id: String?,
    pending_version: Long,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-568_466_632, """
        |UPDATE reading_session
        |  SET remote_id = ?,
        |    is_edited = CASE
        |      WHEN deleted = 1 THEN is_edited
        |      WHEN pending_version = ? THEN 0
        |      ELSE 1
        |    END,
        |    modified_at = CASE
        |      WHEN pending_version = ? THEN ?
        |      ELSE modified_at
        |    END
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, pending_version)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-568_466_632) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun attachRemoteReadingSessionIdForSemanticReplay(
    remote_id: String?,
    modified_at: Long,
    local_id: Long,
  ): QueryResult<Long> {
    val result = driver.execute(795_683_972, """
        |UPDATE reading_session
        |  SET remote_id = ?,
        |    is_edited = CASE
        |      WHEN deleted = 1 THEN is_edited
        |      ELSE 0
        |    END,
        |    modified_at = CASE
        |      WHEN deleted = 1 THEN modified_at
        |      ELSE ?
        |    END
        |  WHERE local_id = ?
        |    AND remote_id IS NULL
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(795_683_972) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(-1_897_152_172, """DELETE FROM reading_session""", 0)
    notifyQueries(-1_897_152_172) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markUnsyncedReadingSessionsDeletedForImport(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(-819_460_452, """
        |UPDATE reading_session
        |  SET deleted = 1,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE remote_id IS NULL
        |    AND deleted = 0
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(-819_460_452) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun markRemoteReadingSessionsDeleted(modified_at: Long): QueryResult<Long> {
    val result = driver.execute(1_499_810_501, """
        |UPDATE reading_session
        |  SET deleted = 1,
        |    is_edited = 1,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE remote_id IS NOT NULL
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
        }
    notifyQueries(1_499_810_501) { emit ->
      emit("reading_session")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun pruneLocalReadingSessions(max_sessions: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(-1_122_224_457, """
        |UPDATE reading_session
        |  SET deleted = 1,
        |    is_edited = CASE WHEN remote_id IS NULL THEN is_edited ELSE 1 END,
        |    pending_version = pending_version + 1
        |  WHERE deleted = 0
        |    AND remote_id IS NULL
        |    AND local_id NOT IN (
        |      SELECT local_id FROM reading_session
        |      WHERE deleted = 0
        |      ORDER BY modified_at DESC, local_id DESC
        |      LIMIT ?
        |    )
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, max_sessions)
        }
  }.also {
    notifyQueries(-434_686_842) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun pruneLocalReadingSessionsForRemoteApply(max_sessions: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(-369_922_346, """
        |UPDATE reading_session
        |  SET deleted = 1,
        |    is_edited = CASE WHEN remote_id IS NULL THEN is_edited ELSE 1 END
        |  WHERE deleted = 0
        |    AND remote_id IS NULL
        |    AND local_id NOT IN (
        |      SELECT local_id FROM reading_session
        |      WHERE deleted = 0
        |      ORDER BY modified_at DESC, local_id DESC
        |      LIMIT ?
        |    )
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, max_sessions)
        }
  }.also {
    notifyQueries(223_078_501) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun pruneRemoteReadingSessions(max_sessions: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(-1_893_099_540, """
        |UPDATE reading_session
        |  SET deleted = 1,
        |    is_edited = 1,
        |    pending_version = pending_version + 1
        |  WHERE deleted = 0
        |    AND remote_id IS NOT NULL
        |    AND local_id NOT IN (
        |      SELECT local_id FROM reading_session
        |      WHERE deleted = 0
        |      ORDER BY modified_at DESC, local_id DESC
        |      LIMIT ?
        |    )
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, max_sessions)
        }
  }.also {
    notifyQueries(990_207_739) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun pruneRemoteReadingSessionsForRemoteApply(max_sessions: Long): QueryResult<Long> = transactionWithResult {
    driver.execute(1_592_790_859, """
        |UPDATE reading_session
        |  SET deleted = 1,
        |    is_edited = 1
        |  WHERE deleted = 0
        |    AND remote_id IS NOT NULL
        |    AND local_id NOT IN (
        |      SELECT local_id FROM reading_session
        |      WHERE deleted = 0
        |      ORDER BY modified_at DESC, local_id DESC
        |      LIMIT ?
        |    )
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, max_sessions)
        }
  }.also {
    notifyQueries(980_427_290) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun addReadingSession(
    chapter_number: Long,
    verse_number: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-1_026_910_662, """
        |INSERT OR IGNORE INTO reading_session (remote_id, chapter_number, verse_number, is_edited, created_at, modified_at, deleted, pending_version)
        |  VALUES (NULL, ?, ?, 0, ?, ?, 0, 0)
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(-1_026_910_661, """
        |UPDATE reading_session
        |  SET deleted = 0,
        |    chapter_number = ?,
        |    verse_number = ?,
        |    is_edited = CASE WHEN remote_id IS NULL THEN 0 ELSE 1 END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE chapter_number = ? AND verse_number = ? AND deleted = 0
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
        }
  }.also {
    notifyQueries(2_144_180_425) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertImportedReadingSession(
    chapter_number: Long,
    verse_number: Long,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-582_868_998, """
        |INSERT OR IGNORE INTO reading_session (
        |    remote_id,
        |    chapter_number,
        |    verse_number,
        |    is_edited,
        |    created_at,
        |    modified_at,
        |    deleted,
        |    pending_version
        |  )
        |  VALUES (
        |    NULL,
        |    ?,
        |    ?,
        |    0,
        |    ?,
        |    ?,
        |    0,
        |    0
        |  )
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(-582_868_997, """
        |UPDATE reading_session
        |  SET deleted = 0,
        |    is_edited = CASE
        |      WHEN remote_id IS NULL THEN 0
        |      WHEN deleted = 1 THEN 0
        |      ELSE is_edited
        |    END,
        |    modified_at = CASE
        |      WHEN remote_id IS NULL THEN ?
        |      WHEN deleted = 1 THEN ?
        |      ELSE modified_at
        |    END,
        |    pending_version = CASE
        |      WHEN remote_id IS NULL OR deleted = 1 THEN pending_version + 1
        |      ELSE pending_version
        |    END
        |  WHERE chapter_number = ? AND verse_number = ? AND deleted = 0
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
        }
  }.also {
    notifyQueries(-233_008_503) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteReadingSession(
    timestamp: Long,
    chapter_number: Long,
    verse_number: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-1_670_561_080, """
        |UPDATE reading_session
        |  SET deleted = 1,
        |    is_edited = CASE WHEN remote_id IS NULL THEN is_edited ELSE 1 END,
        |    modified_at = ?,
        |    pending_version = pending_version + 1
        |  WHERE chapter_number = ? AND verse_number = ? AND deleted = 0
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestamp)
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
        }
  }.also {
    notifyQueries(-810_676_009) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun persistRemoteReadingSession(
    remote_id: String?,
    chapter_number: Long,
    verse_number: Long,
    created_at: Long,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-836_895_405, """
        |INSERT OR IGNORE INTO reading_session (remote_id, chapter_number, verse_number, is_edited, created_at, modified_at, deleted, pending_version)
        |  VALUES (?, ?, ?, 0, ?, ?, 0, 0)
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, modified_at)
        }
    driver.execute(null, """
        |UPDATE reading_session
        |  SET remote_id = ?,
        |    chapter_number = ?,
        |    verse_number = ?,
        |    is_edited = 0,
        |    modified_at = ?,
        |    deleted = 0
        |  WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ?
        |    AND deleted = 0
        |    AND is_edited = 0
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, remote_id)
          bindLong(parameterIndex++, chapter_number)
          bindLong(parameterIndex++, verse_number)
          bindLong(parameterIndex++, modified_at)
          bindString(parameterIndex++, remote_id)
        }
  }.also {
    notifyQueries(986_837_538) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun hardDeleteReadingSessionFor(remoteID: String?): QueryResult<Long> = transactionWithResult {
    driver.execute(null, """DELETE FROM reading_session WHERE remote_id ${ if (remoteID == null) "IS" else "=" } ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, remoteID)
        }
  }.also {
    notifyQueries(-1_907_400_697) { emit ->
      emit("reading_session")
    }
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearLocalMutationFor(
    id: Long,
    pending_version: Long,
    pending_op: String,
    modified_at: Long,
  ): QueryResult<Long> = transactionWithResult {
    driver.execute(-562_199_183, """
        |DELETE FROM reading_session
        |  WHERE remote_id IS NULL
        |    AND local_id = ?
        |    AND pending_version = ?
        |    AND ? = 'CREATED'
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
    driver.execute(-562_199_182, """
        |DELETE FROM reading_session
        |  WHERE local_id = ?
        |    AND remote_id IS NOT NULL
        |    AND deleted = 1
        |    AND pending_version = ?
        |    AND ? = 'DELETED'
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
    driver.execute(-562_199_181, """
        |UPDATE reading_session
        |  SET deleted = 0,
        |    is_edited = 0,
        |    modified_at = ?
        |  WHERE local_id = ?
        |    AND remote_id IS NOT NULL
        |    AND pending_version = ?
        |    AND deleted = 0
        |    AND is_edited = 1
        |    AND ? = 'MODIFIED'
        """.trimMargin(), 4) {
          var parameterIndex = 0
          bindLong(parameterIndex++, modified_at)
          bindLong(parameterIndex++, id)
          bindLong(parameterIndex++, pending_version)
          bindString(parameterIndex++, pending_op)
        }
  }.also {
    notifyQueries(1_594_943_936) { emit ->
      emit("reading_session")
    }
  }

  private inner class GetReadingSessionForChapterVerseQuery<out T : Any>(
    public val chapter_number: Long,
    public val verse_number: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_297_414_733, """SELECT reading_session.local_id, reading_session.remote_id, reading_session.chapter_number, reading_session.verse_number, reading_session.is_edited, reading_session.created_at, reading_session.modified_at, reading_session.deleted, reading_session.pending_version FROM reading_session WHERE chapter_number = ? AND verse_number = ? AND deleted = 0 LIMIT 1""", mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, chapter_number)
      bindLong(parameterIndex++, verse_number)
    }

    override fun toString(): String = "reading_sessions.sq:getReadingSessionForChapterVerse"
  }

  private inner class GetPendingCreatedReadingSessionsForChapterVerseQuery<out T : Any>(
    public val chapter_number: Long,
    public val verse_number: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(611_324_109, """
    |SELECT reading_session.local_id, reading_session.remote_id, reading_session.chapter_number, reading_session.verse_number, reading_session.is_edited, reading_session.created_at, reading_session.modified_at, reading_session.deleted, reading_session.pending_version FROM reading_session
    |  WHERE remote_id IS NULL
    |    AND chapter_number = ?
    |    AND verse_number = ?
    |    AND deleted = 0
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, chapter_number)
      bindLong(parameterIndex++, verse_number)
    }

    override fun toString(): String = "reading_sessions.sq:getPendingCreatedReadingSessionsForChapterVerse"
  }

  private inner class GetDeletedPendingCreatedReadingSessionsForChapterVerseQuery<out T : Any>(
    public val chapter_number: Long,
    public val verse_number: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_542_214_238, """
    |SELECT reading_session.local_id, reading_session.remote_id, reading_session.chapter_number, reading_session.verse_number, reading_session.is_edited, reading_session.created_at, reading_session.modified_at, reading_session.deleted, reading_session.pending_version FROM reading_session
    |  WHERE remote_id IS NULL
    |    AND chapter_number = ?
    |    AND verse_number = ?
    |    AND deleted = 1
    """.trimMargin(), mapper, 2) {
      var parameterIndex = 0
      bindLong(parameterIndex++, chapter_number)
      bindLong(parameterIndex++, verse_number)
    }

    override fun toString(): String = "reading_sessions.sq:getDeletedPendingCreatedReadingSessionsForChapterVerse"
  }

  private inner class GetReadingSessionByLocalIdQuery<out T : Any>(
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(2_038_402_161, """SELECT reading_session.local_id, reading_session.remote_id, reading_session.chapter_number, reading_session.verse_number, reading_session.is_edited, reading_session.created_at, reading_session.modified_at, reading_session.deleted, reading_session.pending_version FROM reading_session WHERE local_id = ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "reading_sessions.sq:getReadingSessionByLocalId"
  }

  private inner class GetReadingSessionByRemoteIdQuery<out T : Any>(
    public val remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT reading_session.local_id, reading_session.remote_id, reading_session.chapter_number, reading_session.verse_number, reading_session.is_edited, reading_session.created_at, reading_session.modified_at, reading_session.deleted, reading_session.pending_version FROM reading_session WHERE remote_id ${ if (remote_id == null) "IS" else "=" } ? LIMIT 1""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, remote_id)
    }

    override fun toString(): String = "reading_sessions.sq:getReadingSessionByRemoteId"
  }

  private inner class CheckRemoteIDsExistenceQuery<out T : Any>(
    public val queried_ids: Collection<String?>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("reading_session", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("reading_session", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val queried_idsIndexes = createArguments(count = queried_ids.size)
      return driver.executeQuery(null, """SELECT remote_id FROM reading_session WHERE remote_id IN $queried_idsIndexes""", mapper, queried_ids.size) {
            var parameterIndex = 0
            queried_ids.forEach { queried_ids_ ->
              bindString(parameterIndex++, queried_ids_)
            }
          }
    }

    override fun toString(): String = "reading_sessions.sq:checkRemoteIDsExistence"
  }
}
