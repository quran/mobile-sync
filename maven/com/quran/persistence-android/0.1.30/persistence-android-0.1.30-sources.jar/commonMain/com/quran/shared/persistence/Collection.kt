@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.ColumnAdapter
import com.quran.shared.persistence.model.CollectionName
import com.quran.shared.persistence.model.CollectionNameKey
import kotlin.Long
import kotlin.String

public data class Collection(
  public val local_id: Long,
  public val remote_id: String?,
  public val name: CollectionName,
  public val name_key: CollectionNameKey,
  public val created_at: Long,
  public val modified_at: Long,
  public val deleted: Long,
  public val is_edited: Long,
  public val is_default: Long,
  public val is_system: Long,
  public val pending_version: Long,
) {
  public class Adapter(
    public val nameAdapter: ColumnAdapter<CollectionName, String>,
    public val name_keyAdapter: ColumnAdapter<CollectionNameKey, String>,
  )
}
