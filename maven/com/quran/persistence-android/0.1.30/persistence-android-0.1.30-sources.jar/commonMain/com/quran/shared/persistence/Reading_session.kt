@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import kotlin.Long
import kotlin.String

public data class Reading_session(
  public val local_id: Long,
  public val remote_id: String?,
  public val chapter_number: Long,
  public val verse_number: Long,
  public val is_edited: Long,
  public val created_at: Long,
  public val modified_at: Long,
  public val deleted: Long,
  public val pending_version: Long,
)
