@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import kotlin.Long
import kotlin.String

public data class Bookmark_collection(
  public val local_id: Long,
  public val bookmark_local_id: Long,
  public val collection_local_id: Long,
  public val is_active: Long,
  public val pending_op: String?,
  public val pending_version: Long,
  public val last_synced_bookmark_remote_id: String?,
  public val last_synced_collection_remote_id: String?,
  public val created_at: Long,
  public val modified_at: Long,
)
