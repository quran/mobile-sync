package com.quran.shared.persistence.repository

import com.quran.shared.persistence.QuranDatabase
import dev.zacsweers.metro.Inject

interface PersistenceResetRepository {
    fun deleteAllData()
}

@Inject
class PersistenceResetRepositoryImpl(
    private val database: QuranDatabase
) : PersistenceResetRepository {
    override fun deleteAllData() {
        database.transaction {
            database.import_trackingQueries.clearImportHistory()
            database.bookmark_collectionsQueries.deleteAll()
            database.bookmarksQueries.deleteAll()
            database.collectionsQueries.deleteAll()
            database.collectionsQueries.seedSystemCollections()
            database.notesQueries.deleteAll()
            database.reading_bookmarksQueries.deleteAll()
            database.reading_sessionsQueries.deleteAll()
        }
    }
}
