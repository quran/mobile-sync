@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence.persistence

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.quran.shared.persistence.Bookmark_collectionsQueries
import com.quran.shared.persistence.BookmarksQueries
import com.quran.shared.persistence.Collection
import com.quran.shared.persistence.CollectionsQueries
import com.quran.shared.persistence.Import_trackingQueries
import com.quran.shared.persistence.Key_value_storeQueries
import com.quran.shared.persistence.NotesQueries
import com.quran.shared.persistence.QuranDatabase
import com.quran.shared.persistence.Reading_bookmarksQueries
import com.quran.shared.persistence.Reading_sessionsQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<QuranDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = QuranDatabaseImpl.Schema

internal fun KClass<QuranDatabase>.newInstance(driver: SqlDriver, collectionAdapter: Collection.Adapter): QuranDatabase = QuranDatabaseImpl(driver, collectionAdapter)

private class QuranDatabaseImpl(
  driver: SqlDriver,
  collectionAdapter: Collection.Adapter,
) : TransacterImpl(driver),
    QuranDatabase {
  override val bookmark_collectionsQueries: Bookmark_collectionsQueries =
      Bookmark_collectionsQueries(driver, collectionAdapter)

  override val bookmarksQueries: BookmarksQueries = BookmarksQueries(driver)

  override val collectionsQueries: CollectionsQueries =
      CollectionsQueries(driver, collectionAdapter)

  override val import_trackingQueries: Import_trackingQueries = Import_trackingQueries(driver)

  override val key_value_storeQueries: Key_value_storeQueries = Key_value_storeQueries(driver)

  override val notesQueries: NotesQueries = NotesQueries(driver)

  override val reading_bookmarksQueries: Reading_bookmarksQueries = Reading_bookmarksQueries(driver)

  override val reading_sessionsQueries: Reading_sessionsQueries = Reading_sessionsQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS bookmark_collection(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  bookmark_local_id INTEGER NOT NULL,
          |  collection_local_id INTEGER NOT NULL,
          |  is_active INTEGER NOT NULL DEFAULT 1,
          |  pending_op TEXT,
          |  pending_version INTEGER NOT NULL DEFAULT 0,
          |  last_synced_bookmark_remote_id TEXT,
          |  last_synced_collection_remote_id TEXT,
          |  created_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  modified_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  CHECK (is_active IN (0, 1)),
          |  CHECK (pending_op IS NULL OR pending_op IN ('CREATED', 'DELETED')),
          |  UNIQUE(bookmark_local_id, collection_local_id),
          |  FOREIGN KEY(bookmark_local_id) REFERENCES bookmark(local_id),
          |  FOREIGN KEY(collection_local_id) REFERENCES collection(local_id)
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS bookmark(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  remote_id TEXT,
          |  sura INTEGER NOT NULL,
          |  ayah INTEGER NOT NULL,
          |  mushaf_id INTEGER NOT NULL DEFAULT 1,
          |  deleted INTEGER NOT NULL DEFAULT 0,
          |  bookmark_pending_op TEXT,
          |  bookmark_pending_version INTEGER NOT NULL DEFAULT 0,
          |  created_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  modified_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  bookmark_modified_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  CHECK (deleted IN (0, 1)),
          |  CHECK (bookmark_pending_op IS NULL OR bookmark_pending_op IN ('CREATED', 'MODIFIED', 'DELETED'))
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS collection(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  remote_id TEXT,
          |  name TEXT NOT NULL,
          |  -- Computed in Kotlin because SQLite's lower() only folds ASCII.
          |  name_key TEXT NOT NULL,
          |  created_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  modified_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  deleted INTEGER NOT NULL DEFAULT 0,
          |  is_edited INTEGER NOT NULL DEFAULT 0,
          |  is_default INTEGER NOT NULL DEFAULT 0,
          |  is_system INTEGER NOT NULL DEFAULT 0,
          |  pending_version INTEGER NOT NULL DEFAULT 0,
          |  CHECK (deleted IN (0, 1)),
          |  CHECK (is_edited IN (0, 1)),
          |  CHECK (is_default IN (0, 1)),
          |  CHECK (is_system IN (0, 1))
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS import_history(
          |  payload_fingerprint TEXT NOT NULL PRIMARY KEY
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS key_value_store(
          |  key TEXT NOT NULL PRIMARY KEY,
          |  value TEXT NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS note(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  remote_id TEXT,
          |  note TEXT NOT NULL,
          |  start_sura INTEGER NOT NULL,
          |  start_ayah INTEGER NOT NULL,
          |  end_sura INTEGER NOT NULL,
          |  end_ayah INTEGER NOT NULL,
          |  created_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  modified_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  deleted INTEGER NOT NULL DEFAULT 0,
          |  is_edited INTEGER NOT NULL DEFAULT 0,
          |  pending_version INTEGER NOT NULL DEFAULT 0,
          |  -- Ensure deleted is either 0 or 1
          |  CHECK (deleted IN (0, 1)),
          |  CHECK (is_edited IN (0, 1))
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS reading_bookmark(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  remote_id TEXT,
          |  slot INTEGER NOT NULL,
          |  name TEXT,
          |  bookmark_type TEXT,
          |  sura INTEGER,
          |  ayah INTEGER,
          |  page INTEGER,
          |  mushaf_id INTEGER,
          |  pending_op TEXT,
          |  pending_version INTEGER NOT NULL DEFAULT 0,
          |  created_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  modified_at INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER) * 1000) NOT NULL,
          |  CHECK (slot > 0),
          |  CHECK (bookmark_type IS NULL OR bookmark_type IN ('AYAH', 'PAGE')),
          |  CHECK (
          |    (bookmark_type IS NULL AND sura IS NULL AND ayah IS NULL AND page IS NULL AND mushaf_id IS NULL)
          |    OR
          |    (bookmark_type = 'AYAH' AND sura IS NOT NULL AND ayah IS NOT NULL AND page IS NULL AND mushaf_id IS NOT NULL)
          |    OR
          |    (bookmark_type = 'PAGE' AND page IS NOT NULL AND sura IS NULL AND ayah IS NULL AND mushaf_id IS NOT NULL)
          |  ),
          |  CHECK (pending_op IS NULL OR pending_op IN ('CREATED', 'MODIFIED'))
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS reading_session(
          |  local_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          |  remote_id TEXT,
          |  chapter_number INTEGER NOT NULL,
          |  verse_number INTEGER NOT NULL,
          |  is_edited INTEGER NOT NULL DEFAULT 0,
          |  created_at INTEGER DEFAULT (CAST((julianday('now') - 2440587.5) * 86400000 AS INTEGER)) NOT NULL,
          |  modified_at INTEGER DEFAULT (CAST((julianday('now') - 2440587.5) * 86400000 AS INTEGER)) NOT NULL,
          |  deleted INTEGER NOT NULL DEFAULT 0,
          |  pending_version INTEGER NOT NULL DEFAULT 0,
          |  CHECK (is_edited IN (0, 1)),
          |  CHECK (deleted IN (0, 1))
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS bookmark_collection_active_created_idx
          |ON bookmark_collection(is_active, created_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS bookmark_collection_collection_active_created_idx
          |ON bookmark_collection(collection_local_id, is_active, created_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS bookmark_collection_pending_idx
          |ON bookmark_collection(pending_op, modified_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS bookmark_collection_snapshots_idx
          |ON bookmark_collection(last_synced_collection_remote_id, last_synced_bookmark_remote_id)
          """.trimMargin(), 0)
      driver.execute(null, "CREATE UNIQUE INDEX IF NOT EXISTS bookmark_remote_id_idx ON bookmark(remote_id)", 0)
      driver.execute(null, """
          |CREATE UNIQUE INDEX IF NOT EXISTS bookmark_ayah_identity_idx
          |ON bookmark(sura, ayah, mushaf_id)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS bookmark_active_modified_idx
          |ON bookmark(deleted, modified_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS bookmark_pending_idx
          |ON bookmark(bookmark_pending_op, modified_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, "CREATE UNIQUE INDEX IF NOT EXISTS collection_remote_id_idx ON collection(remote_id)", 0)
      driver.execute(null, """
          |CREATE UNIQUE INDEX IF NOT EXISTS collection_active_name_idx
          |ON collection(name_key)
          |WHERE deleted = 0
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE UNIQUE INDEX IF NOT EXISTS collection_active_default_idx
          |ON collection(is_default)
          |WHERE is_default = 1 AND deleted = 0
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS collection_active_created_idx
          |ON collection(deleted, created_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS collection_unsynced_created_idx
          |ON collection(created_at DESC)
          |WHERE (remote_id IS NULL AND pending_version > 0) OR is_edited = 1
          """.trimMargin(), 0)
      driver.execute(null, "CREATE INDEX IF NOT EXISTS note_start_ayah_idx ON note(start_sura, start_ayah)", 0)
      driver.execute(null, "CREATE INDEX IF NOT EXISTS note_end_ayah_idx ON note(end_sura, end_ayah)", 0)
      driver.execute(null, "CREATE UNIQUE INDEX IF NOT EXISTS note_remote_id_idx ON note(remote_id)", 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS note_active_created_idx
          |ON note(deleted, created_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS note_unsynced_created_idx
          |ON note(created_at DESC)
          |WHERE remote_id IS NULL OR deleted = 1 OR is_edited = 1
          """.trimMargin(), 0)
      driver.execute(null, "CREATE UNIQUE INDEX IF NOT EXISTS reading_bookmark_slot_idx ON reading_bookmark(slot)", 0)
      driver.execute(null, "CREATE UNIQUE INDEX IF NOT EXISTS reading_bookmark_remote_id_idx ON reading_bookmark(remote_id)", 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS reading_bookmark_pending_idx
          |ON reading_bookmark(pending_op, modified_at DESC)
          """.trimMargin(), 0)
      driver.execute(null, "CREATE UNIQUE INDEX IF NOT EXISTS reading_session_remote_id_idx ON reading_session(remote_id)", 0)
      driver.execute(null, """
          |CREATE UNIQUE INDEX IF NOT EXISTS reading_session_active_position_idx
          |ON reading_session(chapter_number, verse_number)
          |WHERE deleted = 0
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS reading_session_active_modified_idx
          |ON reading_session(deleted, modified_at DESC, local_id DESC)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE INDEX IF NOT EXISTS reading_session_unsynced_modified_idx
          |ON reading_session(modified_at DESC)
          |WHERE remote_id IS NULL OR is_edited = 1 OR deleted = 1
          """.trimMargin(), 0)
      driver.execute(null, """
          |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
          |VALUES ('Favorites', 'favorites', 1, 1)
          """.trimMargin(), 0)
      driver.execute(null, """
          |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
          |VALUES ('system:highlights:blue', 'system:highlights:blue', 0, 1)
          """.trimMargin(), 0)
      driver.execute(null, """
          |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
          |VALUES ('system:highlights:pink', 'system:highlights:pink', 0, 1)
          """.trimMargin(), 0)
      driver.execute(null, """
          |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
          |VALUES ('system:highlights:green', 'system:highlights:green', 0, 1)
          """.trimMargin(), 0)
      driver.execute(null, """
          |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
          |VALUES ('system:highlights:yellow', 'system:highlights:yellow', 0, 1)
          """.trimMargin(), 0)
      driver.execute(null, """
          |INSERT OR IGNORE INTO collection (name, name_key, is_default, is_system)
          |VALUES ('system:highlights:purple', 'system:highlights:purple', 0, 1)
          """.trimMargin(), 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
