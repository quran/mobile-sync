@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import kotlin.Long
import kotlin.String

public data class GetUnsyncedBookmarkRows(
  public val local_id: Long,
  public val remote_id: String?,
  public val sura: Long,
  public val ayah: Long,
  public val mushaf_id: Long,
  public val deleted: Long,
  public val bookmark_pending_op: String,
  public val bookmark_pending_version: Long,
  public val created_at: Long,
  public val modified_at: Long,
  public val bookmark_modified_at: Long,
)
