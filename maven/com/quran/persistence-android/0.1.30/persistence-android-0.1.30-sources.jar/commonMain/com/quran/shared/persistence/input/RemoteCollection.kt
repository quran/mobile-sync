package com.quran.shared.persistence.input

import com.quran.shared.persistence.util.PlatformDateTime

data class RemoteCollection(
    val name: String?,
    val lastUpdated: PlatformDateTime,
    val createdAt: PlatformDateTime? = null,
    val isDefault: Boolean = false,
    val isSystem: Boolean = false
)
