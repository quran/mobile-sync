@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String
import kotlin.collections.Collection

public class Import_trackingQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun getRecordedImportHistory(payload_fingerprints: Collection<String>): Query<String> = GetRecordedImportHistoryQuery(payload_fingerprints) { cursor ->
    cursor.getString(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun recordImportHistory(payload_fingerprint: String): QueryResult<Long> {
    val result = driver.execute(1_644_721_667, """INSERT OR IGNORE INTO import_history (payload_fingerprint) VALUES (?)""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, payload_fingerprint)
        }
    notifyQueries(1_644_721_667) { emit ->
      emit("import_history")
    }
    return result
  }

  private inner class GetRecordedImportHistoryQuery<out T : Any>(
    public val payload_fingerprints: Collection<String>,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("import_history", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("import_history", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> {
      val payload_fingerprintsIndexes = createArguments(count = payload_fingerprints.size)
      return driver.executeQuery(null, """
          |SELECT payload_fingerprint FROM import_history
          |  WHERE payload_fingerprint IN $payload_fingerprintsIndexes
          """.trimMargin(), mapper, payload_fingerprints.size) {
            var parameterIndex = 0
            payload_fingerprints.forEach { payload_fingerprints_ ->
              bindString(parameterIndex++, payload_fingerprints_)
            }
          }
    }

    override fun toString(): String = "import_tracking.sq:getRecordedImportHistory"
  }
}
