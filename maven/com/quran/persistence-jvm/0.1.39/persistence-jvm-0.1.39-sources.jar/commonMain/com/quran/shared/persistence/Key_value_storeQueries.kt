@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class Key_value_storeQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun getValue(key: String): Query<String> = GetValueQuery(key) { cursor ->
    cursor.getString(0)!!
  }

  public fun getKeys(): Query<String> = Query(985_958_829, arrayOf("key_value_store"), driver, "key_value_store.sq", "getKeys", "SELECT key FROM key_value_store") { cursor ->
    cursor.getString(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun putValue(key: String, `value`: String): QueryResult<Long> {
    val result = driver.execute(330_560_703, """INSERT OR REPLACE INTO key_value_store (key, value) VALUES (?, ?)""", 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, key)
          bindString(parameterIndex++, value)
        }
    notifyQueries(330_560_703) { emit ->
      emit("key_value_store")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun removeValue(key: String): QueryResult<Long> {
    val result = driver.execute(540_734_736, """DELETE FROM key_value_store WHERE key = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, key)
        }
    notifyQueries(540_734_736) { emit ->
      emit("key_value_store")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(1_693_533_817, """DELETE FROM key_value_store""", 0)
    notifyQueries(1_693_533_817) { emit ->
      emit("key_value_store")
    }
    return result
  }

  private inner class GetValueQuery<out T : Any>(
    public val key: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("key_value_store", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("key_value_store", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(509_979_864, """SELECT value FROM key_value_store WHERE key = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, key)
    }

    override fun toString(): String = "key_value_store.sq:getValue"
  }
}
