@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import kotlin.String

public data class Key_value_store(
  public val key: String,
  public val value_: String,
)
