@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.quran.shared.persistence.persistence.newInstance
import com.quran.shared.persistence.persistence.schema
import kotlin.String
import kotlin.Unit
import kotlin.collections.List

public interface QuranDatabase : Transacter {
  public val import_trackingQueries: Import_trackingQueries

  public val key_value_storeQueries: Key_value_storeQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = QuranDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): QuranDatabase = QuranDatabase::class.newInstance(driver)

    public fun allTableNames(): List<String> = listOf("import_history", "key_value_store")
  }
}
