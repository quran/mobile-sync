@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence.persistence

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.quran.shared.persistence.Import_trackingQueries
import com.quran.shared.persistence.Key_value_storeQueries
import com.quran.shared.persistence.QuranDatabase
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<QuranDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = QuranDatabaseImpl.Schema

internal fun KClass<QuranDatabase>.newInstance(driver: SqlDriver): QuranDatabase = QuranDatabaseImpl(driver)

private class QuranDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    QuranDatabase {
  override val import_trackingQueries: Import_trackingQueries = Import_trackingQueries(driver)

  override val key_value_storeQueries: Key_value_storeQueries = Key_value_storeQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS import_history(
          |  payload_fingerprint TEXT NOT NULL PRIMARY KEY
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS key_value_store(
          |  key TEXT NOT NULL PRIMARY KEY,
          |  value TEXT NOT NULL
          |)
          """.trimMargin(), 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
