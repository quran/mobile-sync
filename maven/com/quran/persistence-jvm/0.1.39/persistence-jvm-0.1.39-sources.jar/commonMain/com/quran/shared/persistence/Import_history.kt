@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.persistence

import kotlin.String

public data class Import_history(
  public val payload_fingerprint: String,
)
