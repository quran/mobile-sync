package com.quran.shared.pipeline

import co.touchlab.kermit.Logger
import com.quran.shared.auth.model.AuthState
import com.quran.shared.auth.repository.LogoutTokenCaptureException
import com.quran.shared.auth.repository.LogoutTokenMaterial
import com.quran.shared.auth.repository.RemoteLogoutFailure
import com.quran.shared.auth.repository.RemoteLogoutMode
import com.quran.shared.auth.repository.RemoteLogoutOperation
import com.quran.shared.auth.service.AuthService
import com.quran.shared.di.AppScope
import com.quran.shared.persistence.DuplicateCollectionNameException
import com.quran.shared.persistence.ReadOnlyCollectionException
import com.quran.shared.persistence.ReservedCollectionNameException
import com.quran.shared.persistence.TextLengthLimitException
import com.quran.shared.persistence.input.PersistenceImportData
import com.quran.shared.persistence.input.PersistenceImportResult
import com.quran.shared.persistence.model.AyahHighlight
import com.quran.shared.persistence.model.AyahHighlightColor
import com.quran.shared.persistence.model.BookmarkCollectionsReplacementResult
import com.quran.shared.persistence.model.Collection
import com.quran.shared.persistence.model.CollectionAyahBookmark
import com.quran.shared.persistence.model.CollectionWithAyahBookmarks
import com.quran.shared.persistence.model.Mushaf
import com.quran.shared.persistence.model.Note
import com.quran.shared.persistence.model.ReadingBookmark
import com.quran.shared.persistence.model.ReadingBookmarkSlot
import com.quran.shared.persistence.model.ReadingSession
import com.quran.shared.persistence.repository.PersistenceResetRepository
import com.quran.shared.persistence.repository.importdata.PersistenceImportRepository
import com.quran.shared.persistence.util.PlatformDateTime
import com.quran.shared.persistence.util.currentPlatformDateTime
import com.quran.shared.persistence.util.toPlatform
import com.quran.shared.pipeline.sync.AuthServiceSyncAccount
import com.quran.shared.pipeline.sync.SyncAccount
import com.quran.shared.pipeline.sync.SyncClient
import com.quran.shared.pipeline.sync.SyncLifecycleGate
import com.quran.shared.pipeline.sync.SyncRunObserver
import com.quran.shared.pipeline.sync.SyncRunObservers
import com.quran.shared.pipeline.sync.SynchronizationClient
import com.quran.shared.syncv2.db.SyncV2Database
import com.rickclephas.kmp.nativecoroutines.NativeCoroutines
import com.rickclephas.kmp.nativecoroutines.NativeCoroutinesState
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.SingleIn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.native.HiddenFromObjC
import kotlin.time.Instant

/**
 * Creates the scheduler-backed synchronization client used by [QuranDataService].
 *
 * Keeping this as a graph binding lets tests replace only the sync client creation path while
 * leaving the service and repository dependencies wired through Metro.
 */
@HiddenFromObjC
internal fun interface QuranDataServiceSynchronizationClientFactory {
    /**
     * Builds a synchronization client for the service lifecycle.
     *
     * @param environment the remote sync environment.
     * @param account the signed-in session: request headers, the account id and forced token refreshes.
     * @param syncLifecycleGate guards sync work during managed session resets.
     * @param syncRunObserver receives the start and outcome of each sync run.
     * @return the synchronization client used for app-start, local-mutation, and immediate sync triggers.
     */
    fun create(
        environment: SynchronizationEnvironment,
        account: SyncAccount,
        syncLifecycleGate: SyncLifecycleGate,
        syncRunObserver: SyncRunObserver
    ): SynchronizationClient
}

/**
 * Production sync client factory: the sync engine over the app's database.
 */
@HiddenFromObjC
@Inject
internal class DefaultQuranDataServiceSynchronizationClientFactory(
    private val database: SyncV2Database
) : QuranDataServiceSynchronizationClientFactory {
    override fun create(
        environment: SynchronizationEnvironment,
        account: SyncAccount,
        syncLifecycleGate: SyncLifecycleGate,
        syncRunObserver: SyncRunObserver
    ): SynchronizationClient = SyncClient.create(database, environment, account, syncLifecycleGate, syncRunObserver)
}

/**
 * Managed app-facing data facade for Quran user data.
 *
 * Sync-capable clients use this facade for reads and writes so local persistence mutations,
 * sync scheduling, session reset safety, and cross-resource reconciliation stay coordinated.
 * This class must be obtained from the [com.quran.shared.pipeline.di.AppGraph] DI graph via
 * [com.quran.shared.pipeline.di.SharedDependencyGraph]. Direct construction is not supported.
 */
@Inject
@SingleIn(AppScope::class)
class QuranDataService internal constructor(
    private val authService: AuthService,
    private val pipeline: SyncEnginePipeline,
    private val environment: SynchronizationEnvironment,
    private val persistenceResetRepository: PersistenceResetRepository,
    private val persistenceImportRepository: PersistenceImportRepository,
    private val sessionLifecycleCoordinator: SessionLifecycleCoordinator,
    private val syncClientFactory: QuranDataServiceSynchronizationClientFactory,
    syncDatabase: SyncV2Database
) {
    private val serviceJob: Job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + serviceJob)
    private val syncStatusTracker = SyncStatusTracker()
    private val syncHistoryRecorder = SyncHistory(syncDatabase)
    private val heldItemsReader = HeldItems(syncDatabase, scope)
    private val syncClient: SynchronizationClient
    private val initializationMutex = Mutex()
    private var initializationAttempt: Deferred<Unit>? = null
    private var initialized = false
    private var syncLifecycleStarted = false

    /** Stops the service for good: its work, and the sync client's scheduler and HTTP client. */
    fun clear() {
        serviceJob.cancel()
        syncClient.cancelSyncing()
        (syncClient as? AutoCloseable)?.close()
    }

    /** [clear], and waits until the work it stopped has ended: its own, a sync run, and a profile fetch. */
    @HiddenFromObjC
    suspend fun clearAndJoin() {
        clear()
        serviceJob.cancelAndJoin()
        syncClient.cancelSyncingAndJoin()
        syncClient.closeAndJoin()
    }

    @HiddenFromObjC
    internal suspend fun awaitInitialization() {
        val attempt = initializationMutex.withLock {
            if (initialized) {
                null
            } else {
                initializationAttempt ?: scope.async {
                    sessionLifecycleCoordinator.completePersistedResetIfNeeded {
                        syncClient.cancelSyncingAndJoin()
                        resetLocalAuthDataAndToken()
                    }
                }.also { initializationAttempt = it }
            }
        } ?: return

        try {
            attempt.await()
        } catch (failure: Throwable) {
            if (attempt.isCompleted) {
                initializationMutex.withLock {
                    if (initializationAttempt === attempt) initializationAttempt = null
                }
            }
            throw failure
        }

        val shouldStartSyncLifecycle = initializationMutex.withLock {
            initialized = true
            if (initializationAttempt === attempt) initializationAttempt = null
            if (syncLifecycleStarted || !serviceJob.isActive) {
                false
            } else {
                syncLifecycleStarted = true
                true
            }
        }
        if (shouldStartSyncLifecycle) startSyncLifecycle()
    }

    private fun startSyncLifecycle() {
        scope.launch {
            syncClient.applicationStarted()

            // Sync once per published session: a sign-in at once, and the stored session restored at launch at once
            // instead of after the app start's delay. A token refresh publishing the session again starts nothing.
            // Logged-out sync attempts no-op after fetching empty headers; managed reset owns cancellation.
            authService.sessionStart.filterNotNull().collect { start ->
                if (!sessionLifecycleCoordinator.canStartSync()) return@collect
                if (start.interactive) syncClient.signedIn() else syncClient.sessionRestored()
            }
        }
    }

    @NativeCoroutinesState
    val authState: StateFlow<AuthState> get() = authService.authState

    /**
     * The state of the latest sync run. See [SyncStatus] for how retries, sign-out, and resets
     * are reported.
     */
    @NativeCoroutinesState
    val syncStatus: StateFlow<SyncStatus> get() = syncStatusTracker.status

    /**
     * The newest sync runs first, at most 100, one entry per run (its retries included). A run is recorded when it
     * succeeds, pulls only, fails with no retries left, or is cancelled (also when the session ends after it reached
     * the server); a run that found no session before that, or that a logout or reset stopped, is not, nor is one
     * waiting for a retry when [clear] tears the service down. Logout and an account switch clear the history with the
     * rest of the data.
     */
    @NativeCoroutines
    val syncHistory: Flow<List<SyncRun>> get() = syncHistoryRecorder.runs

    /**
     * The items that don't sync: held ones, then the ones waiting on them. It changes as soon as an item is held or
     * released, without waiting for a sync: an edit that fixes a held item takes it (and what waited on it) out at
     * once. Logout and an account switch clear it with the rest of the data.
     */
    @NativeCoroutines
    val heldItems: Flow<List<HeldSyncItem>> get() = heldItemsReader.flow

    /**
     * How many items have a local state the server doesn't have yet, from one read: [UnsyncedItemCounts.pending], new,
     * edited or deleted since they last synced, which the next sync sends; and [UnsyncedItemCounts.held], the
     * [heldItems] (held items and the items waiting on them), which don't sync until they are fixed. Logout loses
     * them all (it wipes all local data), so an app can warn with these counts. An item counts once, in one of the
     * two; a change the server never sees doesn't count: one only to a field that isn't synced (such as an edit time),
     * a verse removed with its collection, or a delete the server would refuse (sync undoes it).
     *
     * It may over-count pending items before the first sync (items a sync will link to the server's equal ones count as
     * new) and while a sent batch's answer is unknown. It changes on every local write, like [heldItems]; each write
     * re-reads it, push planning included, so collect it only while it is shown.
     */
    @NativeCoroutines
    val unsyncedItems: Flow<UnsyncedItemCounts> get() = heldItemsReader.unsyncedCounts

    private val bookmarksRepository = pipeline.bookmarksRepository
    private val readingBookmarksRepository = pipeline.readingBookmarksRepository
    private val collectionsRepository = pipeline.collectionsRepository
    private val collectionBookmarksRepository = pipeline.collectionBookmarksRepository
    private val notesRepository = pipeline.notesRepository
    private val readingSessionsRepository = pipeline.readingSessionsRepository

    /**
     * Flow of ayah highlights, stored independently from app-facing bookmark collections.
     */
    @NativeCoroutines
    val highlights: Flow<List<AyahHighlight>> get() = collectionBookmarksRepository.getHighlightsFlow()

    /**
     * Flow of the three reading bookmark slots, page bookmarks as pages of [mushaf], the mushaf the app shows, mapped
     * from whichever mushaf they were set in.
     */
    @NativeCoroutines
    fun readingBookmarks(mushaf: Mushaf): Flow<List<ReadingBookmark>> = readingBookmarksRepository.getReadingBookmarksFlow(mushaf)

    /**
     * Flow of all collections with their bookmarks for the UI to observe.
     *
     * The default collection is first. Non-default system collections remain hidden from this
     * app-facing collection list.
     */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    @NativeCoroutines
    val collectionsWithBookmarks: Flow<List<CollectionWithAyahBookmarks>>
        get() =
            collectionsRepository.getCollectionsFlow().flatMapLatest { collections ->
                val collectionFlows = collections
                    .filter { it.isDefault || !it.isSystem }
                    .sortedByDescending(Collection::isDefault)
                    .map { collection ->
                        collectionBookmarksRepository.getBookmarksForCollectionFlow(collection.id)
                            .map { bookmarks: List<CollectionAyahBookmark> ->
                                CollectionWithAyahBookmarks(collection, bookmarks)
                            }
                    }
                if (collectionFlows.isEmpty()) {
                    flowOf(emptyList())
                } else {
                    combine(collectionFlows) { it.toList() }
                }
            }

    /**
     * Flow of all notes for the UI to observe. Notes archived on QuranReflect are not included.
     */
    @NativeCoroutines
    val notes: Flow<List<Note>> get() = notesRepository.getNotesFlow()

    /**
     * Flow of all reading sessions for the UI to observe.
     */
    @NativeCoroutines
    val readingSessions: Flow<List<ReadingSession>> get() = readingSessionsRepository.getReadingSessionsFlow()

    init {
        syncClient = syncClientFactory.create(
            environment = environment,
            account = AuthServiceSyncAccount(authService),
            syncLifecycleGate = sessionLifecycleCoordinator,
            // The history first, so a run is recorded before syncStatus shows its end.
            syncRunObserver = SyncRunObservers(syncHistoryRecorder, syncStatusTracker)
        )

        scope.launch {
            try {
                awaitInitialization()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Logger.e(e) { "Failed to recover persisted session reset" }
            }
        }
    }

    @NativeCoroutines
    suspend fun logout(clearLocalData: Boolean = true): LogoutResult {
        awaitInitialization()
        if (!clearLocalData) {
            throw UnsupportedOperationException("Keep-local logout is not implemented yet")
        }
        val remoteLogoutMode = RemoteLogoutMode.TOKEN_REVOCATION_ONLY
        var tokenMaterial: LogoutTokenMaterial? = null
        var tokenCaptureFailure: Throwable? = null
        try {
            sessionLifecycleCoordinator.runManagedReset(
                beforeWriteDrain = {
                    try {
                        authService.captureLogoutTokenMaterialForLogout()
                    } catch (e: LogoutTokenCaptureException) {
                        tokenCaptureFailure = e.cause ?: e
                        null
                    }.let { captured ->
                        tokenMaterial = captured
                    }
                }
            ) {
                syncClient.cancelSyncingAndJoin()
                resetLocalDataAndSyncToken()
            }
            val warnings = tokenCaptureFailure?.let { failure ->
                logoutRemoteCleanupFailureWarnings(failure, remoteLogoutMode)
            } ?: try {
                authService.attemptRemoteLogout(
                    tokenMaterial!!,
                    remoteLogoutMode
                ).let { failures ->
                    failures.map { it.toLogoutWarning() }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (failure: Throwable) {
                logoutRemoteCleanupFailureWarnings(failure, remoteLogoutMode)
            }
            return LogoutResult(warnings)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Logger.e(e) { "Logout failed" }
            throw e
        }
    }

    /**
     * Schedules a sync.
     *
     * @param immediately `false` waits a few seconds so a burst of local edits syncs once. `true`
     *   starts right away, such as for a user's "Sync now". An immediate request made while a sync
     *   is running starts another right after it; one made while a sync waits to retry starts now.
     *   Signed in, an immediate sync also fetches the user's profile at once (see [refreshProfile]), in
     *   the background: the sync never waits for it or fails because of it.
     */
    fun triggerSync(immediately: Boolean = false) {
        if (!sessionLifecycleCoordinator.canStartSync()) {
            Logger.d { "Sync trigger skipped because session is resetting" }
            return
        }
        if (immediately) {
            syncClient.triggerSyncImmediately()
        } else {
            syncClient.localDataUpdated()
        }
    }

    /**
     * Runs the sync `triggerSync(immediately = true)` runs and waits until it ends or its attempt fails and waits to
     * retry (see [SyncNowResult]). A sync already running finishes first; this waits for the one after it, which calls
     * made before it starts share. If a sign-in's run was already due, it waits for that run, with its trigger.
     * Cancelling the caller stops only the wait.
     *
     * @throws Exception when launch recovery failed.
     */
    @NativeCoroutines
    suspend fun syncNow(): SyncNowResult {
        try {
            awaitInitialization()
        } catch (e: CancellationException) {
            // Only a cancelled launch recovery (the service was cleared) becomes Unavailable.
            currentCoroutineContext().ensureActive()
            Logger.d { "Sync now skipped because the service was cleared" }
            return SyncNowResult.Unavailable
        } catch (e: Exception) {
            Logger.e(e) { "Sync now failed because launch recovery failed" }
            throw e
        }
        if (!sessionLifecycleCoordinator.canStartSync()) {
            Logger.d { "Sync now skipped because session is resetting" }
            return SyncNowResult.Unavailable
        }
        return syncClient.syncNow()
    }

    /**
     * Tells sync the app came back to the foreground, so it syncs soon; [syncHistory] records the run as
     * [SyncRunTrigger.FOREGROUND]. Call it on each return from the background, not at launch, which has its own sync.
     *
     * It is automatic, like a local change: the run starts after 2 seconds, and while pushes back off after a failure
     * (see [SyncRunResult.PULLED_ONLY]) it only pulls. It is dropped within a minute of the end of a sync that pulled
     * the server's changes ([SyncRunResult.SUCCEEDED] or [SyncRunResult.PULLED_ONLY]), unless a sync failed since; a
     * cancelled sync doesn't count either way. A run already due sooner (a pending local change) runs in its place,
     * keeping its own trigger; one due later (the periodic sync) is brought forward. During a run it runs again after
     * it; while a failed run waits to retry, it is dropped, as the retry comes sooner. Signed out, the run finds no
     * session and ends before any request, unrecorded, leaving [syncStatus] as it was.
     */
    fun syncOnForeground() {
        if (!sessionLifecycleCoordinator.canStartSync()) {
            Logger.d { "Foreground sync skipped because session is resetting" }
            return
        }
        syncClient.appForegrounded()
    }

    /**
     * Fetches the signed-in user's profile from Quran.com now, so a name or photo changed there shows in [authState]
     * (whose [AuthState.Success] republishes only when the user changed). Call it when the user may have just edited
     * their profile, such as when a Quran.com account page the app opened closes. A call while a fetch for the same
     * session runs joins it.
     *
     * The engine also fetches on its own: during the sign-in's sync, and during the first sync that starts a day or more
     * after the last fetch (an hour or more after a failed one); and at once, like this, during a manual sync
     * ([triggerSync] with `immediately`). The ID token can't bring such an edit: a token refresh
     * repeats the claims captured when the user consented, and no longer replaces a fetched name.
     *
     * Signed out, or while a logout runs, it returns without a request. The fetched profile is stored for the session's
     * account only, and dropped when it names another account or a logout or sign-in happened during the request.
     * A 401 refreshes the token and tries once more. A failure keeps the published user and the session.
     *
     * @throws Exception when the fetch failed: no network, an error status, or a response that isn't a profile.
     */
    @NativeCoroutines
    suspend fun refreshProfile() {
        awaitInitialization()
        syncClient.refreshProfile()
    }

    private suspend fun resetLocalAuthDataAndToken() {
        authService.clearLocalSession()
        resetLocalDataAndSyncToken()
    }

    /** Deletes the user's data with its sync state: the token, the account, the bases and the outbox. */
    private suspend fun resetLocalDataAndSyncToken() {
        syncStatusTracker.reset()
        persistenceResetRepository.deleteAllData()
    }

    private fun logoutRemoteCleanupFailureWarnings(
        failure: Throwable,
        mode: RemoteLogoutMode
    ): List<LogoutWarning> =
        mode.operations.map { operation ->
            LogoutWarning(
                type = operation.toLogoutWarningType(),
                message = failure.message
            )
        }

    private fun RemoteLogoutFailure.toLogoutWarning(): LogoutWarning =
        LogoutWarning(
            type = operation.toLogoutWarningType(),
            message = exception.message
        )

    private fun RemoteLogoutOperation.toLogoutWarningType(): LogoutWarningType =
        when (this) {
            RemoteLogoutOperation.REVOKE_REFRESH_TOKEN -> LogoutWarningType.REVOKE_TOKEN_FAILED
            RemoteLogoutOperation.END_SESSION -> LogoutWarningType.END_SESSION_FAILED
        }

    private suspend fun <T> mutatingCall(
        errorMessage: String,
        shouldTriggerSync: (T) -> Boolean = { true },
        block: suspend () -> T
    ): T {
        try {
            awaitInitialization()
            return sessionLifecycleCoordinator.withMutatingWrite {
                val result = block()
                if (shouldTriggerSync(result)) {
                    triggerSync()
                }
                result
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (e.isRejection()) Logger.i { "$errorMessage: ${e::class.simpleName}" } else Logger.e(e) { errorMessage }
            throw e
        }
    }

    /**
     * A write the data rules reject is an answer to the user, not a fault. Hosts forward warnings and errors to crash
     * reporting, so it logs at info, without the stack trace or the message, which may hold the user's text.
     */
    private fun Exception.isRejection(): Boolean =
        this is TextLengthLimitException ||
            this is ReservedCollectionNameException ||
            this is DuplicateCollectionNameException ||
            this is ReadOnlyCollectionException ||
            this is SessionResetInProgressException

    @NativeCoroutines
    suspend fun importData(data: PersistenceImportData): PersistenceImportResult {
        return importData(
            data = data,
            deleteExisting = false,
            trackHistory = false
        )
    }

    @NativeCoroutines
    suspend fun importData(
        data: PersistenceImportData,
        deleteExisting: Boolean
    ): PersistenceImportResult = importData(data, deleteExisting, trackHistory = false)

    @NativeCoroutines
    suspend fun importData(
        data: PersistenceImportData,
        deleteExisting: Boolean,
        trackHistory: Boolean
    ): PersistenceImportResult = mutatingCall(
        errorMessage = "Failed to import persistence data",
        shouldTriggerSync = { result -> result.changed }
    ) {
        persistenceImportRepository.importData(data, deleteExisting, trackHistory)
    }

    /**
     * Sets the highlight color for one ayah, replacing any existing highlight color.
     * Default and user collection memberships are preserved.
     */
    @NativeCoroutines
    suspend fun setHighlight(sura: Int, ayah: Int, color: AyahHighlightColor): AyahHighlight {
        return setHighlight(sura, ayah, color, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun setHighlight(
        sura: Int,
        ayah: Int,
        color: AyahHighlightColor,
        timestamp: PlatformDateTime
    ): AyahHighlight {
        return mutatingCall("Failed to set ayah highlight") {
            collectionBookmarksRepository.setHighlight(sura, ayah, color, timestamp)
        }
    }

    /**
     * Deletes the highlight from one ayah while preserving default and user collection memberships.
     *
     * @return `true` when at least one highlight membership was removed.
     */
    @NativeCoroutines
    suspend fun deleteHighlight(sura: Int, ayah: Int): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete ayah highlight",
            shouldTriggerSync = { removed -> removed }
        ) {
            collectionBookmarksRepository.deleteHighlight(sura, ayah)
        }
    }

    /**
     * Deletes every ayah's [color] highlight in one transaction and schedules sync only when one was removed.
     *
     * Other colors and default and user collection memberships are preserved, and the color's collection stays. Each
     * removed highlight syncs as [deleteHighlight] removing it would: one verse-in-collection DELETE per verse. A stored
     * verse that doesn't exist (such as 2:999) is kept and not counted, as the server would refuse its delete.
     *
     * @param color the highlight color to clear.
     * @return how many highlights were removed; `0` when no existing ayah had [color].
     */
    @NativeCoroutines
    suspend fun deleteHighlights(color: AyahHighlightColor): Int {
        return mutatingCall(
            errorMessage = "Failed to delete ayah highlights",
            shouldTriggerSync = { removed -> removed > 0 }
        ) {
            collectionBookmarksRepository.deleteHighlights(color)
        }
    }

    @NativeCoroutines
    suspend fun replaceAyahBookmarkCollections(
        sura: Int,
        ayah: Int,
        collectionIds: List<String>
    ): BookmarkCollectionsReplacementResult {
        return replaceAyahBookmarkCollections(sura, ayah, collectionIds, currentPlatformDateTime())
    }

    /**
     * Replaces an ayah bookmark's saved collection memberships with an explicit mutation timestamp
     * and schedules sync only when memberships changed.
     *
     * Non-empty memberships create the bookmark if needed. Empty memberships remove the saved
     * bookmark, or do nothing when it does not exist. Highlight collection memberships are always
     * preserved and excluded from replacement.
     */
    @NativeCoroutines
    suspend fun replaceAyahBookmarkCollections(
        sura: Int,
        ayah: Int,
        collectionIds: List<String>,
        timestamp: PlatformDateTime
    ): BookmarkCollectionsReplacementResult {
        return mutatingCall(
            errorMessage = "Failed to replace ayah bookmark collection memberships",
            shouldTriggerSync = { result -> result.changed }
        ) {
            bookmarksRepository.replaceAyahBookmarkCollections(sura, ayah, collectionIds, timestamp)
        }
    }

    @NativeCoroutines
    suspend fun setAyahReadingBookmark(
        slot: ReadingBookmarkSlot,
        sura: Int,
        ayah: Int
    ): ReadingBookmark = setAyahReadingBookmark(slot, sura, ayah, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun setAyahReadingBookmark(
        slot: ReadingBookmarkSlot,
        sura: Int,
        ayah: Int,
        timestamp: PlatformDateTime
    ): ReadingBookmark = mutatingCall("Failed to set reading ayah bookmark") {
        readingBookmarksRepository.setAyahReadingBookmark(slot, sura, ayah, timestamp)
    }

    /**
     * Sets [slot] to [page] of [mushaf], numbered the way apps number that mushaf's pages (see [Mushaf]).
     *
     * @throws IllegalArgumentException when [mushaf] has no such page.
     */
    @NativeCoroutines
    suspend fun setPageReadingBookmark(slot: ReadingBookmarkSlot, page: Int, mushaf: Mushaf): ReadingBookmark =
        setPageReadingBookmark(slot, page, mushaf, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun setPageReadingBookmark(
        slot: ReadingBookmarkSlot,
        page: Int,
        mushaf: Mushaf,
        timestamp: PlatformDateTime
    ): ReadingBookmark =
        mutatingCall("Failed to set reading page bookmark") {
            readingBookmarksRepository.setPageReadingBookmark(slot, page, mushaf, timestamp)
        }

    /** Renames [slot] and returns it read in [mushaf], like [readingBookmarks]. */
    @NativeCoroutines
    suspend fun renameReadingBookmark(slot: ReadingBookmarkSlot, name: String?, mushaf: Mushaf): ReadingBookmark =
        renameReadingBookmark(slot, name, mushaf, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun renameReadingBookmark(
        slot: ReadingBookmarkSlot,
        name: String?,
        mushaf: Mushaf,
        timestamp: PlatformDateTime
    ): ReadingBookmark =
        mutatingCall("Failed to rename reading bookmark") {
            readingBookmarksRepository.renameReadingBookmark(slot, name, mushaf, timestamp)
        }

    @NativeCoroutines
    suspend fun clearReadingBookmark(slot: ReadingBookmarkSlot): ReadingBookmark =
        clearReadingBookmark(slot, currentPlatformDateTime())

    @NativeCoroutines
    suspend fun clearReadingBookmark(slot: ReadingBookmarkSlot, timestamp: PlatformDateTime): ReadingBookmark =
        mutatingCall("Failed to clear reading bookmark") {
            readingBookmarksRepository.clearReadingBookmark(slot, timestamp)
        }

    @NativeCoroutines
    suspend fun addReadingSession(sura: Int, ayah: Int): ReadingSession {
        return addReadingSession(sura, ayah, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun addReadingSession(sura: Int, ayah: Int, timestamp: PlatformDateTime): ReadingSession {
        return mutatingCall("Failed to add reading session") {
            readingSessionsRepository.addReadingSession(sura, ayah, timestamp)
        }
    }

    /**
     * Updates a reading session, merging it into an existing destination session when needed.
     * When [id] names no session (a sync, the recent-session prune, a delete or a reset removed
     * it), a visit is recorded at the verse as [addReadingSession] does.
     *
     * The returned session is authoritative: keep its ID. A merge returns the destination's ID,
     * and when the original session no longer exists the visit's session is returned, with a
     * new ID or that of the session already at the verse.
     */
    @NativeCoroutines
    suspend fun updateReadingSession(id: String, sura: Int, ayah: Int): ReadingSession {
        return updateReadingSession(id, sura, ayah, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun updateReadingSession(
        id: String,
        sura: Int,
        ayah: Int,
        timestamp: PlatformDateTime
    ): ReadingSession {
        return mutatingCall("Failed to update reading session") {
            readingSessionsRepository.updateReadingSession(id, sura, ayah, timestamp)
        }
    }

    /**
     * Deletes the reading session at the given ayah and schedules sync only when a row was removed.
     *
     * @param sura the sura number of the reading session to delete.
     * @param ayah the ayah number of the reading session to delete.
     * @return `true` when a reading session was deleted, or `false` when no matching session existed.
     */
    @NativeCoroutines
    suspend fun deleteReadingSession(sura: Int, ayah: Int): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete reading session",
            shouldTriggerSync = { deleted -> deleted }
        ) {
            readingSessionsRepository.deleteReadingSession(sura, ayah)
        }
    }

    /**
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name].
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     * @throws TextLengthLimitException when [name] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun addCollection(name: String): Collection {
        return addCollection(name, currentPlatformDateTime())
    }

    /**
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name].
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     * @throws TextLengthLimitException when [name] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun addCollection(name: String, timestamp: PlatformDateTime): Collection {
        return mutatingCall("Failed to add collection") {
            collectionsRepository.addCollection(name, timestamp)
        }
    }

    /**
     * Updates a collection name and schedules sync for the local mutation.
     *
     * @param id the mobile-sync identifier of the collection to update.
     * @param name the new collection name.
     * @return the updated collection.
     * @throws IllegalArgumentException when [id] does not identify an active collection.
     * @throws com.quran.shared.persistence.ReadOnlyCollectionException when the collection can't be renamed.
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name].
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     * @throws TextLengthLimitException when [name] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun updateCollection(id: String, name: String): Collection {
        return updateCollection(id, name, currentPlatformDateTime())
    }

    /**
     * Updates a collection name with an explicit mutation timestamp and schedules sync.
     *
     * @param id the mobile-sync identifier of the collection to update.
     * @param name the new collection name.
     * @param timestamp the timestamp to persist for the mutation.
     * @return the updated collection.
     * @throws IllegalArgumentException when [id] does not identify an active collection.
     * @throws com.quran.shared.persistence.ReadOnlyCollectionException when the collection can't be renamed.
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name].
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     * @throws TextLengthLimitException when [name] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun updateCollection(id: String, name: String, timestamp: PlatformDateTime): Collection {
        return mutatingCall("Failed to update collection") {
            collectionsRepository.updateCollection(id, name, timestamp)
        }
    }

    /**
     * Deletes a custom collection and schedules sync when a row was removed.
     *
     * @throws com.quran.shared.persistence.ReadOnlyCollectionException when the collection can't be deleted.
     */
    @NativeCoroutines
    suspend fun deleteCollection(id: String): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete collection",
            shouldTriggerSync = { deleted -> deleted }
        ) {
            collectionsRepository.deleteCollection(id)
        }
    }

    @NativeCoroutines
    suspend fun addAyahBookmarkToCollection(
        collectionId: String,
        sura: Int,
        ayah: Int
    ): CollectionAyahBookmark {
        return addAyahBookmarkToCollection(collectionId, sura, ayah, currentPlatformDateTime())
    }

    @NativeCoroutines
    suspend fun addAyahBookmarkToCollection(
        collectionId: String,
        sura: Int,
        ayah: Int,
        timestamp: PlatformDateTime
    ): CollectionAyahBookmark {
        return mutatingCall("Failed to add ayah bookmark to collection") {
            collectionBookmarksRepository.addAyahBookmarkToCollection(collectionId, sura, ayah, timestamp)
        }
    }

    /** Removes an ayah bookmark from a collection and schedules sync when a membership was removed. */
    @NativeCoroutines
    suspend fun removeAyahBookmarkFromCollection(collectionId: String, bookmarkId: String): Boolean {
        return mutatingCall(
            errorMessage = "Failed to remove bookmark from collection",
            shouldTriggerSync = { removed -> removed }
        ) {
            collectionBookmarksRepository.removeAyahBookmarkFromCollection(collectionId, bookmarkId)
        }
    }

    /**
     * Removes every ayah bookmark from the collection [collectionId] in one transaction, keeping the collection, and
     * schedules sync only when a membership was removed. Each removal syncs as [removeAyahBookmarkFromCollection]
     * would.
     *
     * Like [removeAyahBookmarkFromCollection], it accepts read-only collections such as the default collection
     * (read-only only blocks renaming and deleting a collection). Highlight collections are rejected, as in
     * [addAyahBookmarkToCollection]: clear a color with [deleteHighlights]. The verses' memberships in other
     * collections are preserved, so a verse removed from Favorites stays in its user collections and keeps its
     * highlight. A stored verse that doesn't exist (such as 2:999) is kept and not counted, as the server would refuse
     * its delete.
     *
     * @param collectionId the mobile-sync identifier of the collection to empty.
     * @return how many memberships were removed; `0` when the collection has no existing verse or [collectionId] names
     *   none.
     * @throws IllegalArgumentException when [collectionId] is a highlight collection.
     */
    @NativeCoroutines
    suspend fun removeAllAyahBookmarksFromCollection(collectionId: String): Int {
        return mutatingCall(
            errorMessage = "Failed to remove all bookmarks from collection",
            shouldTriggerSync = { removed -> removed > 0 }
        ) {
            collectionBookmarksRepository.removeAllAyahBookmarksFromCollection(collectionId)
        }
    }

    /** @throws TextLengthLimitException when [body] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun addNote(body: String, startSura: Int, startAyah: Int, endSura: Int, endAyah: Int) {
        addNote(body, startSura, startAyah, endSura, endAyah, currentPlatformDateTime())
    }

    /** @throws TextLengthLimitException when [body] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun addNote(
        body: String,
        startSura: Int,
        startAyah: Int,
        endSura: Int,
        endAyah: Int,
        timestamp: PlatformDateTime
    ) {
        mutatingCall("Failed to add note") {
            notesRepository.addNote(body, startSura, startAyah, endSura, endAyah, timestamp)
        }
    }

    /**
     * Updates a note's body and schedules sync for the local mutation. A note's verse ranges never
     * change, as on the server.
     *
     * @param id the mobile-sync identifier of the note to update.
     * @param body the updated note body.
     * @throws IllegalArgumentException when [id] does not identify a note.
     * @throws TextLengthLimitException when a changed [body] is outside the server's length limits.
     */
    @NativeCoroutines
    suspend fun updateNote(id: String, body: String) {
        updateNote(id, body, currentPlatformDateTime())
    }

    /** @throws TextLengthLimitException when a changed [body] is outside the server's length limits. */
    @NativeCoroutines
    suspend fun updateNote(id: String, body: String, timestamp: PlatformDateTime) {
        mutatingCall("Failed to update note") {
            notesRepository.updateNote(id, body, timestamp)
        }
    }

    /** Deletes a note and schedules sync when a row was removed. */
    @NativeCoroutines
    suspend fun deleteNote(id: String): Boolean {
        return mutatingCall(
            errorMessage = "Failed to delete note",
            shouldTriggerSync = { deleted -> deleted }
        ) {
            notesRepository.deleteNote(id)
        }
    }

}
