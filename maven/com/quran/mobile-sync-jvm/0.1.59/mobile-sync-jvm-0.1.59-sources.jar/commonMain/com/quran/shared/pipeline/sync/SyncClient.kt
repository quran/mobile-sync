package com.quran.shared.pipeline.sync

import co.touchlab.kermit.Logger
import com.quran.shared.logging.installHttpLogging
import com.quran.shared.persistence.util.PlatformDateTime
import com.quran.shared.persistence.util.toPlatform
import com.quran.shared.pipeline.SyncError
import com.quran.shared.pipeline.SyncErrorKind
import com.quran.shared.pipeline.SyncNowResult
import com.quran.shared.pipeline.SyncRun
import com.quran.shared.pipeline.SyncRunResult
import com.quran.shared.pipeline.SyncRunTrigger
import com.quran.shared.pipeline.SynchronizationEnvironment
import com.quran.shared.pipeline.profile.ProfileApi
import com.quran.shared.pipeline.profile.ProfileRefresher
import com.quran.shared.syncv2.SyncApi
import com.quran.shared.syncv2.SyncEngineV2
import com.quran.shared.syncv2.SyncHttpException
import com.quran.shared.syncv2.SyncResult
import com.quran.shared.syncv2.db.SyncV2Database
import com.quran.shared.syncv2.types.syncTypes
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.header
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import kotlinx.io.IOException
import kotlin.concurrent.Volatile
import kotlin.random.Random
import kotlin.time.Clock
import kotlin.time.Duration
import kotlin.time.Instant

/** The session ended during a run: its requests have no token. */
internal class SignedOutException : IllegalStateException("No session")

/**
 * Runs [SyncEngineV2] when [SyncScheduler] says, for the signed-in account, and reports each run to [observer]:
 * [SyncRunObserver.syncStarted] once signed in (again for each retry), [SyncRunObserver.syncRetrying] after each failed
 * attempt that will be retried, then skipped (no session, a logout or reset) or ended ([SyncRun]: succeeded, pulled
 * only, failed when it won't be retried, or cancelled), as [SyncRunObserver] says. A run's record sums its attempts:
 * their count, and what each pushed and pulled.
 *
 * - A 401 forces one token refresh and runs again; a refused refresh ends the session.
 * - A failure that asks for a push backoff (a 403 that may be the token's scope) stops pushing for that long; the
 *   periodic and other automatic runs still pull. A "sync now" or a sign-in pushes anyway. A sign-in, a logout or
 *   reset, or a new access token (a refresh, by any path) ends the backoff: the 403 may have been the old token's.
 * - Each signed-in run starts [profiles]' fetch in the background, which the run never waits for: a manual sync's first
 *   attempt fetches now, and any other attempt when the fetch is due ([profileFetch]).
 * - A run's first attempt reports to its [RunWaiter]s after [observer], so `syncStatus` shows what [syncNow] returns.
 */
internal class SyncClient(
    private val engine: SyncEngineV2,
    private val account: SyncAccount,
    private val gate: SyncLifecycleGate,
    private val observer: SyncRunObserver,
    private val timings: SchedulerTimings,
    dispatcher: CoroutineDispatcher = Dispatchers.Default,
    private val now: () -> Long = { Clock.System.now().toEpochMilliseconds() },
    /** Closed with this client. */
    private val httpClient: HttpClient? = null,
    /** The retries' jitter: a uniform sample in `0 until 1` per attempt (see [SyncScheduler]); tests fix it. */
    random: () -> Double = { Random.nextDouble() },
    /** Keeps the user's profile current; closed with this client. Null fetches no profile. */
    private val profiles: ProfileRefresher? = null
) : SynchronizationClient, AutoCloseable {
    private val logger = Logger.withTag("SyncClient")
    private val scheduler = SyncScheduler(timings, dispatcher, now, ::runAttempt, random)

    @Volatile
    private var pushBackoffUntil = 0L

    /**
     * A fingerprint (the hash, so no token is kept) of the headers of the request that started the push backoff: other
     * headers mean a new token, which ends it.
     */
    @Volatile
    private var pushBackoffHeaders: Int? = null

    /** The fingerprint of the headers the latest request sent. */
    @Volatile
    private var lastRequestHeaders: Int? = null

    /** When the latest run that pulled the server's changes (succeeded or pulled only) ended; null after a failure. */
    @Volatile
    private var lastPulledAt: Long? = null

    override fun localDataUpdated() = trigger(SyncTrigger.LOCAL_CHANGE)

    /**
     * Dropped within [SchedulerTimings.foregroundSkipAfterSync] of the end of a run that pulled the server's changes
     * (succeeded, or pulled only during a push backoff): the app already has them. A run that failed since then ends
     * the skip, so returning after a failure syncs; a cancelled run neither starts nor ends it. A clock set back since
     * that run (it seems to end in the future) ends the skip too, rather than stretch it.
     */
    override fun appForegrounded() {
        val sincePulled = lastPulledAt?.let { now() - it }
        if (sincePulled != null && sincePulled in 0 until timings.foregroundSkipAfterSync.inWholeMilliseconds) {
            logger.d { "Skipping the foreground sync: a sync pulled $sincePulled ms ago" }
            return
        }
        trigger(SyncTrigger.FOREGROUND)
    }

    override fun applicationStarted() = trigger(SyncTrigger.APP_START)

    override fun triggerSyncImmediately() = trigger(SyncTrigger.IMMEDIATE)

    override suspend fun syncNow(): SyncNowResult {
        if (!gate.canStartSync()) {
            logger.d { "Sync lifecycle unavailable, skipping a sync now" }
            return SyncNowResult.Unavailable
        }
        return scheduler.triggerAndAwait(SyncTrigger.IMMEDIATE)
    }

    /** A new session: a push backoff the previous one started ends. */
    override fun signedIn() {
        endPushBackoff("a user signed in")
        trigger(SyncTrigger.SIGN_IN)
    }

    override fun sessionRestored() = trigger(SyncTrigger.SESSION_RESTORED)

    override fun cancelSyncing() = scheduler.cancel()

    /** Also forgets a run waiting for a retry: cancelled for a logout or reset, it isn't recorded. */
    override suspend fun cancelSyncingAndJoin() {
        scheduler.cancelAndJoin()
        run = null
        lastPulledAt = null
        endPushBackoff("a logout or reset")
    }

    /** Waits until the scheduler has handled the end of the attempt running now, if any (see [SyncScheduler.awaitIdle]). */
    internal suspend fun awaitSchedulerIdle() = scheduler.awaitIdle()

    /** Fetches the user's profile now, or joins the fetch in progress (see [ProfileRefresher.refresh]). */
    override suspend fun refreshProfile() {
        profiles?.refresh()
    }

    /** Stops the scheduler and the profile fetches for good and closes the HTTP client: the owning service is gone. */
    override fun close() {
        scheduler.close()
        profiles?.close()
        httpClient?.close()
    }

    /** [close], and waits until the attempt and the profile fetch that were running, if any, have stopped. */
    override suspend fun closeAndJoin() {
        close()
        scheduler.cancelAndJoin()
        profiles?.closeAndJoin()
    }

    private fun trigger(trigger: SyncTrigger) {
        if (gate.canStartSync()) scheduler.trigger(trigger) else logger.d { "Sync lifecycle unavailable, skipping $trigger" }
    }

    /**
     * Runs one attempt. A run cancelled while the sync lifecycle is open (the service is cleared) is reported
     * [SyncRunResult.CANCELLED]; one a logout or reset cancels reports nothing, as its data is wiped. An attempt that
     * throws ends its run [SyncRunResult.FAILED], without a retry, or skips it if the lifecycle closed, so `syncStatus`
     * no longer stays [com.quran.shared.pipeline.SyncStatus.Syncing].
     */
    private suspend fun runAttempt(
        attempt: SyncAttempt,
        waiters: List<RunWaiter>,
        retryDelay: (AttemptOutcome.Failed) -> Duration?
    ): AttemptOutcome = try {
        attemptOnce(attempt, waiters, retryDelay)
    } catch (cancellation: CancellationException) {
        if (gate.canStartSync()) waiters.reportEnded(end(SyncRunResult.CANCELLED)) else run = null
        throw cancellation
    } catch (error: Exception) {
        logger.e(error) { "A sync attempt failed unexpectedly" }
        if (gate.canStartSync()) {
            val failure = SyncResult.Failed(error.toString(), retryable = false, cause = error)
            waiters.reportEnded(end(SyncRunResult.FAILED, failure.toSyncError()))
        } else {
            run = null
            observer.syncSkipped()
        }
        AttemptOutcome.Done
    }

    private suspend fun attemptOnce(
        attempt: SyncAttempt,
        waiters: List<RunWaiter>,
        retryDelay: (AttemptOutcome.Failed) -> Duration?
    ): AttemptOutcome {
        val epoch = startEpoch()
            ?: return skipped("the sync lifecycle is unavailable", waiters, SyncNowResult.Unavailable)
        val (tally, replacedWaitingRun) = startRun(attempt, epoch)
        // A retry continues a failed run, and an immediate run that replaced one waiting to retry ends that wait: both
        // report syncing at once, before the headers (which may refresh the token), so syncStatus never shows the wait
        // while they run, and a retry reports it even if fetching headers fails again.
        val startReported = attempt.number > 0 || replacedWaitingRun
        if (startReported) observer.syncStarted()
        var push = false
        val result = try {
            val headers = account.authHeaders()
            if (headers.isEmpty()) return skipped("no one is signed in", waiters, SyncNowResult.SignedOut)
            val accountId = account.accountId()
                ?: return skipped("the signed-in account is unknown", waiters, SyncNowResult.SignedOut)
            if (!startReported) observer.syncStarted()
            when (attempt.profileFetch()) {
                ProfileFetch.NOW -> profiles?.refreshInBackground()
                ProfileFetch.IF_DUE -> profiles?.refreshIfDue()
            }
            // A pause that ran out is forgotten quietly; one still running ends if the token changed.
            if (pushBackoffUntil != 0L && now() >= pushBackoffUntil) endPushBackoff(why = null)
            pushBackoffHeaders?.let { if (it != headers.hashCode()) endPushBackoff("the access token changed") }
            push = attempt.trigger.isImmediate || now() >= pushBackoffUntil
            sync(accountId, push, tally)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Exception) {
            SyncResult.Failed(error.toString(), retryable = true, cause = error)
        }
        if (!epochIsCurrent(epoch)) {
            return skipped("a logout or reset began during the run", waiters, SyncNowResult.Unavailable)
        }
        return when (result) {
            is SyncResult.Success -> {
                if (push) endPushBackoff("a push succeeded")
                val ended = if (push) SyncRunResult.SUCCEEDED else SyncRunResult.PULLED_ONLY
                waiters.reportEnded(end(ended, held = result.held.size))
                AttemptOutcome.Done
            }
            is SyncResult.Failed -> failed(result, waiters, retryDelay)
        }
    }

    /**
     * One engine run; a 401 forces a token refresh and runs once more. A 401 again, with a token the authorization
     * server just issued, isn't retried in this run: the next run (periodic, or a user's) may refresh once more. So a
     * server that keeps rejecting tokens gets at most one refresh per run, never a storm.
     */
    private suspend fun sync(accountId: String, push: Boolean, tally: RunTally): SyncResult {
        val result = tally.add(engine.sync(accountId, push))
        if ((result as? SyncResult.Failed)?.httpStatus != UNAUTHORIZED) return result
        logger.i { "The server rejected the token; refreshing it" }
        if (!account.forceTokenRefresh()) {
            return SyncResult.Failed("the session ended", retryable = false, cause = SignedOutException())
        }
        val again = tally.add(engine.sync(accountId, push))
        if ((again as? SyncResult.Failed)?.httpStatus != UNAUTHORIZED) return again
        logger.w { "The server rejected a freshly refreshed token; not retrying in this run" }
        return again.copy(retryable = false)
    }

    private suspend fun failed(
        result: SyncResult.Failed,
        waiters: List<RunWaiter>,
        retryDelay: (AttemptOutcome.Failed) -> Duration?
    ): AttemptOutcome {
        when (result.cause) {
            is SignedOutException -> return skipped("the session ended", waiters, SyncNowResult.SignedOut)
            is SyncOperationInvalidatedException -> {
                return skipped("a logout or reset began during the run", waiters, SyncNowResult.Unavailable)
            }
        }
        result.retryAfterMillis?.let {
            pushBackoffUntil = now() + it
            pushBackoffHeaders = lastRequestHeaders
        }
        val outcome = AttemptOutcome.Failed(result.retryable, result.retryAfterMillis)
        val delay = retryDelay(outcome)
        if (delay == null) {
            logger.w { "Sync failed: ${result.reason}" }
            waiters.reportEnded(end(SyncRunResult.FAILED, result.toSyncError()))
        } else {
            val failedAt = now()
            val retrying = SyncNowResult.Retrying(
                failedAt.toPlatformTime(), result.toSyncError(), (failedAt + delay.inWholeMilliseconds).toPlatformTime()
            )
            observer.syncRetrying(retrying.failedAt, retrying.error, retrying.nextAttemptAt)
            waiters.report(retrying)
        }
        return outcome
    }

    /**
     * Ends the attempt without a result. A run that already sent a request (in this attempt, or in one before the
     * retry that found no session) is recorded [SyncRunResult.CANCELLED] with what it did, unless a logout or reset
     * began since; any other is forgotten. Either way it is skipped, so `syncStatus` goes back to what it was.
     */
    private suspend fun skipped(why: String, waiters: List<RunWaiter>, skip: SyncNowResult): AttemptOutcome {
        val open = run
        val cancelled = if (open != null && open.contactedServer && gate.canStartSync() && epochIsCurrent(open.epoch)) {
            logger.i { "Sync stopped: $why" }
            end(SyncRunResult.CANCELLED)
        } else {
            logger.i { "Sync skipped: $why" }
            run = null
            null
        }
        observer.syncSkipped()
        waiters.reportEnded(cancelled)
        waiters.report(skip)
        return AttemptOutcome.Done
    }

    /**
     * The run in progress, from its first attempt until it ends. Attempts run one at a time, and the scheduler's
     * cancel-and-join clears it only once none runs.
     */
    @Volatile
    private var run: RunTally? = null

    /**
     * The run [attempt] belongs to. A first attempt starts a new run; a run still open then was waiting for a retry
     * that an immediate trigger replaced, and is reported cancelled (unless a logout or reset moved the epoch since).
     */
    private fun startRun(attempt: SyncAttempt, epoch: Long): RunStart {
        val open = run
        var replacedWaitingRun = false
        val tally = if (attempt.number > 0 && open != null) open else {
            if (open != null && open.epoch == epoch) {
                end(SyncRunResult.CANCELLED)
                replacedWaitingRun = true
            }
            RunTally(attempt.trigger, now(), epoch)
        }
        tally.attempts += 1
        run = tally
        return RunStart(tally, replacedWaitingRun)
    }

    /** [tally]: the run an attempt belongs to. [replacedWaitingRun]: it ended a run that was waiting to retry. */
    private data class RunStart(val tally: RunTally, val replacedWaitingRun: Boolean)

    /** Ends the open run as [result] and reports it, with the [held] items it leaves (counted now if not given). */
    private fun end(result: SyncRunResult, error: SyncError? = null, held: Int? = null): SyncRun? {
        val tally = run ?: return null
        run = null
        when (result) {
            SyncRunResult.SUCCEEDED, SyncRunResult.PULLED_ONLY -> lastPulledAt = now()
            SyncRunResult.FAILED -> lastPulledAt = null
            SyncRunResult.CANCELLED -> Unit
        }
        return tally.toRun(result, now(), held ?: heldCount(), error).also(observer::syncEnded)
    }

    /** The items that don't sync now, for a run's record; 0 when they can't be read. */
    private fun heldCount(): Int = try {
        engine.held().size
    } catch (e: Exception) {
        logger.w(e) { "Could not count held items" }
        0
    }

    @Volatile
    private var runEpoch: Long? = null

    private suspend fun startEpoch(): Long? {
        if (!gate.canStartSync()) return null
        return try {
            gate.captureSyncEpoch().also { runEpoch = it }
        } catch (invalidated: SyncOperationInvalidatedException) {
            null
        }
    }

    private suspend fun epochIsCurrent(epoch: Long): Boolean = try {
        gate.checkSyncEpoch(epoch)
        true
    } catch (invalidated: SyncOperationInvalidatedException) {
        false
    }

    /**
     * Headers for each request of a run: none once a logout or reset began (admitted under the gate's lock, so a
     * request can't slip out after a reset started), or once the session ended. Headers given mark the run as one
     * that contacted the server.
     */
    private suspend fun requestHeaders(): Map<String, String> {
        runEpoch?.let { gate.admitSyncPost(it) }
        return account.authHeaders().ifEmpty { throw SignedOutException() }.also {
            run?.contactedServer = true
            lastRequestHeaders = it.hashCode()
        }
    }

    /** Ends the push pause, logging [why] unless it is null (the pause ran out). */
    private fun endPushBackoff(why: String?) {
        if (pushBackoffUntil == 0L && pushBackoffHeaders == null) return
        if (why != null) logger.i { "Pushing again: $why" }
        pushBackoffUntil = 0L
        pushBackoffHeaders = null
    }

    companion object {
        private const val UNAUTHORIZED = 401

        /** Holds are reviewed again when this changes (see [SyncEngineV2]). */
        private const val ENGINE_VERSION = "mobile-sync-2"

        fun create(
            database: SyncV2Database,
            environment: SynchronizationEnvironment,
            account: SyncAccount,
            gate: SyncLifecycleGate,
            observer: SyncRunObserver,
            timings: SchedulerTimings = DefaultSyncTimings,
            random: () -> Double = { Random.nextDouble() },
            /** The HTTP engine; null uses the platform's (see [createSyncHttpClient]). Tests pass a mock. */
            engine: HttpClientEngine? = null,
            dispatcher: CoroutineDispatcher = Dispatchers.Default,
            now: () -> Long = { Clock.System.now().toEpochMilliseconds() }
        ): SyncClient {
            lateinit var client: SyncClient
            val httpClient = createSyncHttpClient(engine)
            val api = SyncApi(httpClient, environment.endPointURL) { client.requestHeaders() }
            val engine = SyncEngineV2(database, api, syncTypes(database), ENGINE_VERSION)
            val profiles = ProfileRefresher(ProfileApi(httpClient, environment), account, gate, dispatcher, now)
            client = SyncClient(
                engine, account, gate, observer, timings, dispatcher, now, httpClient = httpClient, random = random,
                profiles = profiles
            )
            return client
        }

        /**
         * The client behind the sync API's GETs and POSTs. The explicit timeouts keep a request that never answers (an
         * app suspended mid-request, a stalled network, a server that stops answering) from holding the run, which
         * then fails as a network error and is retried. A request as a whole has no cap, so a large first-sync page on
         * a slow network can finish as long as data keeps coming. [engine] is for tests; null uses the platform's
         * engine (OkHttp on Android and the JVM, Darwin on iOS) from this module's dependencies.
         *
         * The engines apply them differently. OkHttp takes both: connecting gives up after 15 s, and a connection that
         * stalls mid-response after 60 s of silence (OkHttp's own default is 10 s). Ktor's Darwin engine (3.6.0)
         * ignores the connect timeout and uses the socket timeout as the request's idle timeout, so on iOS the 60 s
         * idle timeout covers connecting too.
         */
        internal fun createSyncHttpClient(engine: HttpClientEngine? = null): HttpClient {
            val configure: HttpClientConfig<*>.() -> Unit = {
                installHttpLogging(tag = "SyncHttp")
                install(HttpTimeout) {
                    connectTimeoutMillis = SYNC_CONNECT_TIMEOUT_MS
                    socketTimeoutMillis = SYNC_SOCKET_TIMEOUT_MS
                }
                defaultRequest { header(HttpHeaders.Accept, ContentType.Application.Json) }
            }
            return if (engine == null) HttpClient(configure) else HttpClient(engine, configure)
        }

        internal const val SYNC_CONNECT_TIMEOUT_MS = 15_000L
        internal const val SYNC_SOCKET_TIMEOUT_MS = 60_000L
    }
}

/** When a signed-in attempt fetches the user's profile. */
internal enum class ProfileFetch {
    /** Now, whenever the last fetches were ([ProfileRefresher.refreshInBackground]). */
    NOW,

    /** Only when it is due: a day after the last fetch, and an hour after the last attempt ([ProfileRefresher.refreshIfDue]). */
    IF_DUE
}

/**
 * A manual sync ("sync now") is the user asking for their account to be current, so its first attempt fetches the
 * profile now; its retries, and every automatic run (a sign-in, app start, local change, foreground, periodic), only
 * when it is due.
 */
internal fun SyncAttempt.profileFetch(): ProfileFetch =
    if (trigger == SyncTrigger.IMMEDIATE && number == 0) ProfileFetch.NOW else ProfileFetch.IF_DUE

private val SyncResult.Failed.httpStatus: Int? get() = (cause as? SyncHttpException)?.status

/**
 * A failed run as the app sees it: a stable category, the HTTP status and the server's error code. Never a response
 * body or user data.
 */
internal fun SyncResult.Failed.toSyncError(): SyncError {
    val cause = cause
    // A network error, also when the token refresh before a request failed on one (the OIDC library wraps it).
    if (cause != null && generateSequence<Throwable>(cause) { it.cause }.any { it is IOException }) {
        return SyncError(SyncErrorKind.NETWORK, null, null, "Could not reach the sync server")
    }
    return httpOrUnknown(cause)
}

private fun SyncResult.Failed.httpOrUnknown(cause: Throwable?): SyncError = when (cause) {
    is SyncHttpException -> {
        val code = cause.status
        val (kind, description) = when {
            code == 401 || code == 403 -> SyncErrorKind.AUTHENTICATION to "The sync server did not accept the session"
            code >= 500 || code == 408 || code == 429 -> SyncErrorKind.SERVER to "The sync server is unavailable"
            code in 400..499 -> SyncErrorKind.REJECTED to "The sync server rejected the request"
            else -> SyncErrorKind.UNKNOWN to "The sync server returned an unexpected status"
        }
        SyncError(kind, code, cause.code, "$description (HTTP $code)")
    }
    null -> SyncError(SyncErrorKind.UNKNOWN, null, null, "Sync failed unexpectedly ($reason)")
    else -> SyncError(SyncErrorKind.UNKNOWN, null, null, "Sync failed unexpectedly (${cause::class.simpleName})")
}

/**
 * A run's progress so far: its trigger, start, the gate epoch it started under, and its attempts' sums.
 * [contactedServer]: an attempt sent a request, so the run may have changed something here or on the server.
 */
private class RunTally(val trigger: SyncTrigger, val startedAt: Long, val epoch: Long) {
    var attempts = 0
    var pushed = 0
    var pulled = 0
    var contactedServer = false

    fun add(result: SyncResult): SyncResult = result.also {
        pushed += it.pushed
        pulled += it.pulled
    }

    fun toRun(result: SyncRunResult, endedAt: Long, held: Int, error: SyncError?) = SyncRun(
        startedAt = startedAt.toPlatformTime(),
        endedAt = endedAt.toPlatformTime(),
        trigger = trigger.toRunTrigger(),
        result = result,
        attempts = attempts,
        pushed = pushed,
        pulled = pulled,
        held = held,
        error = error
    )
}

private fun Long.toPlatformTime(): PlatformDateTime = Instant.fromEpochMilliseconds(this).toPlatform()

private fun SyncTrigger.toRunTrigger(): SyncRunTrigger = when (this) {
    SyncTrigger.APP_START, SyncTrigger.SESSION_RESTORED -> SyncRunTrigger.APP_START
    SyncTrigger.LOCAL_CHANGE -> SyncRunTrigger.LOCAL_CHANGE
    SyncTrigger.FOREGROUND -> SyncRunTrigger.FOREGROUND
    SyncTrigger.PERIODIC -> SyncRunTrigger.PERIODIC
    SyncTrigger.IMMEDIATE -> SyncRunTrigger.MANUAL
    SyncTrigger.SIGN_IN -> SyncRunTrigger.SIGN_IN
}
