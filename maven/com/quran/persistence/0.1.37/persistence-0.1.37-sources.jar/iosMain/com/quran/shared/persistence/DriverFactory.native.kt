package com.quran.shared.persistence

import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.native.NativeSqliteDriver
import co.touchlab.kermit.Logger
import co.touchlab.sqliter.DatabaseConfiguration
import co.touchlab.sqliter.DatabaseFileContext
import co.touchlab.sqliter.interop.SQLiteExceptionErrorCode
import co.touchlab.sqliter.interop.SqliteErrorType
import kotlin.native.HiddenFromObjC

actual class DriverFactory internal constructor(
    private val name: String,
    private val onConfiguration: (DatabaseConfiguration) -> DatabaseConfiguration = { it }
) {
    /** Opens the app database, `user_data.db`. */
    constructor() : this(DATABASE_NAME)

    /**
     * Opens the database file [name] instead of `user_data.db`, in the same directory
     * (`Library/Application Support/databases`).
     *
     * For tests: processes that share a simulator share that directory, so each test process can
     * open its own file.
     */
    constructor(name: String) : this(name, { it })

    /**
     * Opens the database. Hidden from Swift, which opens it through `SharedDependencyGraph.openDatabase`.
     *
     * @throws DatabaseStorageFullException when SQLite reports SQLITE_FULL. A full disk never deletes
     * the database. It can also surface as another error; see [DatabaseStorageFullException].
     */
    @HiddenFromObjC
    actual fun makeDriver(): SqlDriver {
        return try {
            openRecreatingCorruptDatabase()
        } catch (e: Exception) {
            if (!e.isStorageFull()) throw e
            logger.w(e) { "Not enough storage to open database $name" }
            throw DatabaseStorageFullException(e)
        }
    }

    /**
     * Opens the database, replacing it with an empty one when SQLite reports it corrupt.
     *
     * Android's default open helper deletes corrupt databases. The native driver has no such
     * handler, so a corrupt file would otherwise fail every launch. Synced data is restored by the
     * next full sync; unsynced local changes in the corrupt file are lost.
     *
     * Only SQLITE_CORRUPT and SQLITE_NOTADB trigger deletion. SQLite reports them only after a read
     * succeeded and returned bad bytes. A file locked by data protection, for example before first
     * unlock, fails to open or read instead (SQLITE_CANTOPEN or SQLITE_IOERR), so it is kept. A full
     * disk (SQLITE_FULL) is never treated as corruption.
     */
    internal actual fun deleteDatabase() {
        DatabaseFileContext.deleteDatabase(name)
    }

    private fun openRecreatingCorruptDatabase(): SqlDriver {
        return try {
            openCheckedDriver()
        } catch (e: Exception) {
            if (e.isStorageFull() || !e.isCorruption()) throw e
            logger.e(e) { "Database $name is corrupt; deleting and recreating it" }
            DatabaseFileContext.deleteDatabase(name)
            openCheckedDriver()
        }
    }

    private fun openCheckedDriver(): SqlDriver {
        val driver = NativeSqliteDriver(MobileSyncSchema, name, onConfiguration = { configuration ->
            onConfiguration(
                configuration.copy(extendedConfig = configuration.extendedConfig.copy(foreignKeyConstraints = true))
            )
        })
        try {
            // Opening is lazy; the first statement opens the file and runs schema creation.
            val problems = driver.executeQuery(
                identifier = null,
                sql = "PRAGMA quick_check",
                mapper = { cursor ->
                    val rows = mutableListOf<String>()
                    while (cursor.next().value) {
                        rows += cursor.getString(0).orEmpty()
                    }
                    QueryResult.Value(rows)
                },
                parameters = 0
            ).value.filterNot { it == QUICK_CHECK_OK }
            if (problems.isNotEmpty()) {
                throw DatabaseCorruptException(problems.joinToString("\n"))
            }
        } catch (e: Exception) {
            driver.close()
            throw e
        }
        return driver
    }

    private companion object {
        const val DATABASE_NAME = "user_data.db"
        const val QUICK_CHECK_OK = "ok"
        val logger = Logger.withTag("DriverFactory")
    }
}

private class DatabaseCorruptException(message: String) : IllegalStateException(message)

private fun Throwable.isCorruption(): Boolean =
    generateSequence(this) { it.cause }.any { error ->
        error is DatabaseCorruptException ||
            (error as? SQLiteExceptionErrorCode)?.errorType in corruptionErrorTypes
    }

private val corruptionErrorTypes = setOf(SqliteErrorType.SQLITE_CORRUPT, SqliteErrorType.SQLITE_NOTADB)

private fun Throwable.isStorageFull(): Boolean =
    generateSequence(this) { it.cause }.any { error ->
        (error as? SQLiteExceptionErrorCode)?.errorType == SqliteErrorType.SQLITE_FULL
    }
