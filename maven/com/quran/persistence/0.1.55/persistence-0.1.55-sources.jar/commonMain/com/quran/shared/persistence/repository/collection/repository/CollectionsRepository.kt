package com.quran.shared.persistence.repository.collection.repository

import com.quran.shared.persistence.model.Collection
import com.quran.shared.persistence.util.PlatformDateTime
import kotlinx.coroutines.flow.Flow

interface CollectionsRepository {
    /**
     * Fetch and returns all collections.
     *
     * @return List<Collection> the current list of collections
     */
    suspend fun getAllCollections(): List<Collection>

    /**
     * Add a collection with the provided name.
     *
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name]
     * (trimmed, case-insensitive).
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     */
    suspend fun addCollection(name: String): Collection

    /**
     * Add a collection with the provided name using an explicit mutation timestamp.
     *
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name]
     * (trimmed, case-insensitive).
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     */
    suspend fun addCollection(name: String, timestamp: PlatformDateTime): Collection

    /**
     * Update the name of a collection identified by its mobile-sync ID.
     *
     * @throws IllegalArgumentException when [id] does not identify an active collection.
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name]
     * (trimmed, case-insensitive).
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     */
    suspend fun updateCollection(id: String, name: String): Collection

    /**
     * Update the name of a collection identified by its mobile-sync ID using an explicit mutation timestamp.
     *
     * @throws IllegalArgumentException when [id] does not identify an active collection.
     * @throws com.quran.shared.persistence.DuplicateCollectionNameException when another collection has [name]
     * (trimmed, case-insensitive).
     * @throws com.quran.shared.persistence.ReservedCollectionNameException when [name] is reserved.
     */
    suspend fun updateCollection(id: String, name: String, timestamp: PlatformDateTime): Collection

    /**
     * Delete a collection identified by its mobile-sync ID.
     */
    suspend fun deleteCollection(id: String): Boolean

    /**
     * Observe the collections list as a Flow.
     */
    fun getCollectionsFlow(): Flow<List<Collection>>
}
