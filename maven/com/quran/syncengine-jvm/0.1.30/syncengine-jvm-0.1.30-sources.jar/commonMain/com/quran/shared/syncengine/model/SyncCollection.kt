package com.quran.shared.syncengine.model

import com.quran.shared.mutations.collectionNameKey
import kotlin.time.Instant

data class SyncCollection(
    val id: String,
    val name: String?,
    val lastModified: Instant,
    val createdAt: Instant? = null,
    val isDefault: Boolean = false,
    val isSystem: Boolean = false
)

internal sealed class SyncCollectionKey {
    data class Name(val name: String) : SyncCollectionKey() {
        override fun toString(): String = "name=$name"
    }

    data class LocalId(val localId: String) : SyncCollectionKey() {
        override fun toString(): String = "localId=$localId"
    }
}

internal fun SyncCollection.conflictKeyOrNull(): SyncCollectionKey? {
    return name?.let { SyncCollectionKey.Name(collectionNameKey(it)) }
}
