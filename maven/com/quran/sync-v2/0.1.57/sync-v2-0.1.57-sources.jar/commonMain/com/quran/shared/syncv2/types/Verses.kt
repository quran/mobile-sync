package com.quran.shared.syncv2.types

/**
 * Verse counts per sura, for local validation (the server rejects verses that don't exist: 422, or 500 for a note range).
 * Public for `persistence`, whose bulk removals leave alone the stored verses the server would refuse to delete.
 */
object Verses {
    private val counts = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53,
        89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 22, 24, 13, 14, 11, 11, 18, 12,
        12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17, 19, 26,
        30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6
    )

    fun exists(sura: Int, ayah: Int): Boolean = sura in 1..114 && ayah in 1..counts[sura - 1]
}
