@file:Suppress("REDUNDANT_VISIBILITY_MODIFIER", "ASSIGNED_VALUE_IS_NEVER_READ")

package com.quran.shared.syncv2.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class Sync_itemQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> all(resource: String, mapper: (
    resource: String,
    local_id: Long,
    remote_id: String?,
    base_json: String?,
    held_reason: String?,
    held_json: String?,
    held_until: Long?,
  ) -> T): Query<T> = AllQuery(resource) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2),
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getLong(6)
    )
  }

  public fun all(resource: String): Query<Sync_item> = all(resource, ::Sync_item)

  public fun <T : Any> `get`(
    resource: String,
    local_id: Long,
    mapper: (
      resource: String,
      local_id: Long,
      remote_id: String?,
      base_json: String?,
      held_reason: String?,
      held_json: String?,
      held_until: Long?,
    ) -> T,
  ): Query<T> = GetQuery(resource, local_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2),
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getLong(6)
    )
  }

  public fun `get`(resource: String, local_id: Long): Query<Sync_item> = get(resource, local_id, ::Sync_item)

  public fun <T : Any> byRemote(
    resource: String,
    remote_id: String?,
    mapper: (
      resource: String,
      local_id: Long,
      remote_id: String?,
      base_json: String?,
      held_reason: String?,
      held_json: String?,
      held_until: Long?,
    ) -> T,
  ): Query<T> = ByRemoteQuery(resource, remote_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getLong(1)!!,
      cursor.getString(2),
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getLong(6)
    )
  }

  public fun byRemote(resource: String, remote_id: String?): Query<Sync_item> = byRemote(resource, remote_id, ::Sync_item)

  public fun metaGet(key: String): Query<String> = MetaGetQuery(key) { cursor ->
    cursor.getString(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun upsert(
    resource: String,
    local_id: Long,
    remote_id: String?,
    base_json: String?,
    held_reason: String?,
    held_json: String?,
    held_until: Long?,
  ): QueryResult<Long> {
    val result = driver.execute(-414_807_898, """
        |INSERT OR REPLACE INTO sync_item(resource, local_id, remote_id, base_json, held_reason, held_json, held_until)
        |VALUES (?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 7) {
          var parameterIndex = 0
          bindString(parameterIndex++, resource)
          bindLong(parameterIndex++, local_id)
          bindString(parameterIndex++, remote_id)
          bindString(parameterIndex++, base_json)
          bindString(parameterIndex++, held_reason)
          bindString(parameterIndex++, held_json)
          bindLong(parameterIndex++, held_until)
        }
    notifyQueries(-414_807_898) { emit ->
      emit("sync_item")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun delete(resource: String, local_id: Long): QueryResult<Long> {
    val result = driver.execute(-911_870_686, """DELETE FROM sync_item WHERE resource = ? AND local_id = ?""", 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, resource)
          bindLong(parameterIndex++, local_id)
        }
    notifyQueries(-911_870_686) { emit ->
      emit("sync_item")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteByRemote(resource: String, remote_id: String?): QueryResult<Long> {
    val result = driver.execute(null, """DELETE FROM sync_item WHERE resource = ? AND remote_id ${ if (remote_id == null) "IS" else "=" } ?""", 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, resource)
          bindString(parameterIndex++, remote_id)
        }
    notifyQueries(-561_567_041) { emit ->
      emit("sync_item")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(128_606_495, """DELETE FROM sync_item""", 0)
    notifyQueries(128_606_495) { emit ->
      emit("sync_item")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun metaSet(key: String, value_: String): QueryResult<Long> {
    val result = driver.execute(1_201_615_750, """INSERT OR REPLACE INTO sync_meta(key, value) VALUES (?, ?)""", 2) {
          var parameterIndex = 0
          bindString(parameterIndex++, key)
          bindString(parameterIndex++, value_)
        }
    notifyQueries(1_201_615_750) { emit ->
      emit("sync_meta")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun metaDelete(key: String): QueryResult<Long> {
    val result = driver.execute(-1_647_178_745, """DELETE FROM sync_meta WHERE key = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, key)
        }
    notifyQueries(-1_647_178_745) { emit ->
      emit("sync_meta")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun metaDeleteAll(): QueryResult<Long> {
    val result = driver.execute(-1_100_569_574, """DELETE FROM sync_meta""", 0)
    notifyQueries(-1_100_569_574) { emit ->
      emit("sync_meta")
    }
    return result
  }

  private inner class AllQuery<out T : Any>(
    public val resource: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("sync_item", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("sync_item", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_235_359_114, """SELECT sync_item.resource, sync_item.local_id, sync_item.remote_id, sync_item.base_json, sync_item.held_reason, sync_item.held_json, sync_item.held_until FROM sync_item WHERE resource = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, resource)
    }

    override fun toString(): String = "sync_item.sq:all"
  }

  private inner class GetQuery<out T : Any>(
    public val resource: String,
    public val local_id: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("sync_item", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("sync_item", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_235_364_671, """SELECT sync_item.resource, sync_item.local_id, sync_item.remote_id, sync_item.base_json, sync_item.held_reason, sync_item.held_json, sync_item.held_until FROM sync_item WHERE resource = ? AND local_id = ?""", mapper, 2) {
      var parameterIndex = 0
      bindString(parameterIndex++, resource)
      bindLong(parameterIndex++, local_id)
    }

    override fun toString(): String = "sync_item.sq:get"
  }

  private inner class ByRemoteQuery<out T : Any>(
    public val resource: String,
    public val remote_id: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("sync_item", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("sync_item", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT sync_item.resource, sync_item.local_id, sync_item.remote_id, sync_item.base_json, sync_item.held_reason, sync_item.held_json, sync_item.held_until FROM sync_item WHERE resource = ? AND remote_id ${ if (remote_id == null) "IS" else "=" } ?""", mapper, 2) {
      var parameterIndex = 0
      bindString(parameterIndex++, resource)
      bindString(parameterIndex++, remote_id)
    }

    override fun toString(): String = "sync_item.sq:byRemote"
  }

  private inner class MetaGetQuery<out T : Any>(
    public val key: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("sync_meta", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("sync_meta", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_201_604_218, """SELECT value FROM sync_meta WHERE key = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, key)
    }

    override fun toString(): String = "sync_item.sq:metaGet"
  }
}
